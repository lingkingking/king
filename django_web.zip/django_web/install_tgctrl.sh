#!/bin/bash

# 更新系统
yum update -y

# 安装必要的工具 sqlite-devel 将在编译Python3.8时用到
yum install -y wget yum-utils sqlite-devel

# 安装 MySQL 8.0
new_password="Nkc23ScnoP!23"
echo "Checking MySQL 8.0 installation..."
if ! command -v mysql &> /dev/null
then
    echo "MySQL not found, installing..."
    rpm -Uvh https://dev.mysql.com/get/mysql80-community-release-el7-10.noarch.rpm
    yum-config-manager --enable mysql80-community

    yum install -y mysql-community-server

    # 启动并设置 MySQL 服务
    systemctl start mysqld
    systemctl enable mysqld

    # 获取临时密码
    temp_password=$(grep 'temporary password' /var/log/mysqld.log | awk '{print $NF}')
    echo "Temporary MySQL root password: $temp_password"

    # 设置 MySQL root 用户密码
    mysql -uroot -p"$temp_password" --connect-expired-password -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '$new_password';"

    echo "MySQL installed and root password set."
else
    echo "MySQL already installed."
fi

# 创建新数据库和用户
db_name="tg_control"
db_user="tg_control"
db_password="YhsbnIsk@n8x"

mysql -uroot -p"$new_password" -e "CREATE DATABASE IF NOT EXISTS ${db_name};"
mysql -uroot -p"$new_password" -e "CREATE USER IF NOT EXISTS '${db_user}'@'localhost' IDENTIFIED BY '${db_password}';"
mysql -uroot -p"$new_password" -e "GRANT ALL PRIVILEGES ON ${db_name}.* TO '${db_user}'@'localhost';"
mysql -uroot -p"$new_password" -e "FLUSH PRIVILEGES;"

echo "Database ${db_name} and user ${db_user} configured successfully."

# 安装 Redis
echo "Checking Redis installation..."
if ! command -v redis-server &> /dev/null
then
    echo "Redis not found, installing..."
    yum install -y epel-release
    yum install -y redis

    # 启动并设置 Redis 服务
    systemctl start redis
    systemctl enable redis

    echo "Redis installed and started."
else
    echo "Redis already installed."
fi

# 安装 Python 3.8.12
echo "Checking Python 3.8.12 installation..."
python_version=$(python3 --version 2>&1)
if [[ "$python_version" != "Python 3.8.12" ]]
then
    echo "Python 3.8.12 not found, installing..."
    yum install -y gcc openssl-devel bzip2-devel libffi-devel
    cd /usr/src
    wget https://www.python.org/ftp/python/3.8.12/Python-3.8.12.tgz
    tar xzf Python-3.8.12.tgz

    # 编译并安装 Python
    cd Python-3.8.12
    ./configure --enable-optimizations
    make altinstall

    # 创建 python3 链接
    if [[ -L /usr/bin/python3 ]]; then
        rm -f /usr/bin/python3
    fi
    ln -s /usr/local/bin/python3.8 /usr/bin/python3
	
    echo "Python 3.8.12 installed."
else
    echo "Python 3.8.12 already installed."
fi

# 安装 git
echo "Checking Git installation..."
if ! command -v git &> /dev/null
then
    echo "Git not found, installing..."
    yum install -y git

    echo "Git installed and started."
else
    echo "Git already installed."
fi


# 验证安装
echo "Verifying installations..."
mysql --version
redis-server --version
python3 --version

python3 -m pip install --upgrade pip
python3 -m pip install celery --upgrade

# Python 包安装
git config --global user.email "git@example.com"
git config --global user.name "Git"
git config --global core.autocrlf input
cd /usr/local/
export GIT_USERNAME=mier
export GIT_PASSWORD=Zxfloveswq520!
git clone http://${GIT_USERNAME}:${GIT_PASSWORD}@43.153.14.251/mier/telegram_xx.git Telethon
cd Telethon
python3 -m pip install .

# 安装 tg_control
cd /usr/local/
git clone http://${GIT_USERNAME}:${GIT_PASSWORD}@43.153.14.251/mier/tg_control.git tgcontrol
cd tgcontrol

# 安装依赖包
python3 -m pip install -r requirements.txt
# 初始化应用
python3 manage.py makemigrations
python3 manage.py migrate
python3 manage.py init_settings
python3 manage.py create_users
python3 manage.py collectstatic

./restart.sh

echo "安装成功，请开放端口：8888"
# 获取公网 IP 地址
public_ip=$(curl -s ifconfig.me)
# 输出服务访问地址
echo "服务访问地址: http://$public_ip:8888/"
echo "超级管理员账号：admin，密码：159Aa159"
echo "客户账号：user01，密码：user159159"
