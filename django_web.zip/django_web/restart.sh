#!/bin/bash

# django app port
export PORT=8888

# stop existing process
fuser -k $PORT/tcp
ps -aux | grep 'celery -A tg_control' | grep -v grep | awk '{print $2}' | xargs sudo kill -9
# start new one
python3 -m pip install -r requirements.txt
python3 manage.py makemigrations --merge
python3 manage.py migrate
python3 manage.py collectstatic --noinput
nohup python3 manage.py runserver 0.0.0.0:$PORT &
nohup celery -A tg_control worker --loglevel=info -f logs/tg_control.log &
