from django.contrib.admin import AdminSite
from django.shortcuts import render, redirect
from django.urls import path
from django.utils.translation import gettext_lazy as _
from .views import get_log_content
from django.contrib.auth.models import User, Group
from django.contrib.auth.admin import UserAdmin, GroupAdmin

class MyAdminSite(AdminSite):
    site_header = _("TG管理后台")
    site_title = _("TG后台管理")
    index_title = _("欢迎使用TG管理后台")
    # def get_urls(self):
    #     urls = super().get_urls()
    #     custom_urls = [
    #         path('web-console/', self.admin_view(self.web_console_view), name='web_console'),
    #     ]
    #     return custom_urls + urls

    def each_context(self, request):
        context = super().each_context(request)
        context['change_list_template'] = 'admin/change_list.html'
        return context

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('', lambda request: redirect('/admin/main/account/')),
            path('web-console/', self.admin_view(self.web_console_view), name='web_console'),
            path('get-log-content/', self.admin_view(get_log_content), name='get_log_content'),
        ]
        return custom_urls + urls

    def web_console_view(self, request):
        context = dict(
            self.each_context(request),
        )
        return render(request, "admin/web_console.html", context)

# Instantiate the custom admin site
admin_site = MyAdminSite()

# Register the User and Group models with the custom admin site
class CustomUserAdmin(UserAdmin):
    # 在列表中添加组字段
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_superuser', 'is_staff', 'get_groups')

    # 移除搜索栏
    search_fields = ()

    def get_search_fields(self, request):
        return self.search_fields

    def get_groups(self, obj):
        return ", ".join([group.name for group in obj.groups.all()])

    get_groups.short_description = '权限组'

# 注册自定义的 UserAdmin
admin_site.register(User, CustomUserAdmin)

class CustomGroupAdmin(GroupAdmin):

    # 移除搜索栏
    search_fields = ()

    def get_search_fields(self, request):
        return self.search_fields

admin_site.register(Group, CustomGroupAdmin)