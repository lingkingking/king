from django.core.management.base import BaseCommand
from main.models import Setting

class Command(BaseCommand):
    help = 'Initialize settings'

    def handle(self, *args, **kwargs):
        default_settings = [
            {'setting_key': 'region', 'value': 'US', 'notes': '地区码'},
            {'setting_key': 'proxy', 'value': '5Hj9Ks2Cv9He-res-国家大写-sid-随机数字|3Gy5Ne4Ba1Ru4Jx6Fj|z1.ipmart.io|9595', 'notes': '代理设置'},
        ]

        for setting_data in default_settings:
            setting, created = Setting.objects.get_or_create(setting_key=setting_data['setting_key'])
            if created:
                setting.value = setting_data['value']
                setting.notes = setting_data['notes']
                setting.save()
                self.stdout.write(self.style.SUCCESS(f'Successfully created setting {setting_data["setting_key"]}'))
            else:
                self.stdout.write(self.style.WARNING(f'Setting {setting_data["setting_key"]} already exists'))
