from django.core.management.base import BaseCommand
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType


class Command(BaseCommand):
    help = 'List all permissions of a specified app'

    def add_arguments(self, parser):
        parser.add_argument('app_label', type=str, help='The app label to list permissions for')

    def handle(self, *args, **kwargs):
        app_label = kwargs['app_label']
        content_type = ContentType.objects.filter(app_label=app_label)
        permissions = Permission.objects.filter(content_type__in=content_type)

        if permissions.exists():
            for perm in permissions:
                self.stdout.write(f"Name: {perm.name}, Codename: {perm.codename}")
        else:
            self.stdout.write(f"No permissions found for app '{app_label}'")
