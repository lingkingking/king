import openpyxl
import xlrd
from django.contrib import admin
from django.contrib.auth.decorators import permission_required

from .models import Account, Group, TaskStatus, Setting, TGGroup, TGGroupCollect, AccountMessaging, GroupTag, GroupTag2
from django.urls import path
from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect
from django.conf import settings
from .forms import UploadMultipleFilesForm, GroupSelectionForm, JoinGroupForm, InviteGroupForm, TGGroupForm, \
    PlatformChoiceForm, \
    ExportUsernamesForm, TelegramMessageForm, CollectMembersForm, ImportGroupForm, TagSelectionForm, TGGroupCollectForm, \
    Tag2SelectionForm, CreateTGGroupForm, UpdateGroupForm, TelegramMessageUserForm,UserForm
import os
import json
from django.contrib import messages
from django.utils.html import format_html
from .admin_views import admin_site
from datetime import datetime
from .tasks import batch_login, batch_join_group, invite_group, refresh_group_info_task, refresh_groupcollect_info_task, \
    load_recent_chats, export_usernames, stop_all_running_tasks, msg_to_group_task, collect_members_task, \
    msg_to_user_task,invite_user_list
from django.template.response import TemplateResponse
from django.utils import timezone
from .tasks import collect_members_sync
from django.http import HttpResponse, FileResponse, Http404
from django.utils.encoding import escape_uri_path

from asgiref.sync import async_to_sync, sync_to_async
from django.urls import reverse
from celery import current_app
from django.core.files.storage import FileSystemStorage
import uuid
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from django.contrib.admin.actions import delete_selected as default_delete_selected
from .utils import clean_group_id, do_telegram_account, op_check_username_availability, op_edit_group
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin
from django.http import JsonResponse
from telethon.tl import types, functions

import locale
locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')

# Register your models here.
def handle_uploaded_file(file, group_ids):
    phone_number = os.path.splitext(file.name)[0]
    today = datetime.now().strftime('%Y%m%d')
    session_dir = os.path.join(settings.BASE_DIR, 'session_files', today)
    if not os.path.exists(session_dir):
        os.makedirs(session_dir)
    session_path = os.path.join(session_dir, file.name)

    with open(session_path, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)

    account, created = Account.objects.get_or_create(
        phone=phone_number,
        defaults={'session_path': session_path}
    )
    if not created:
        account.session_path = session_path
        account.save()

    if group_ids:
        account.groups.set(group_ids)



class GroupFilter(admin.SimpleListFilter):
    title = '分组'
    parameter_name = 'groups'

    def lookups(self, request, model_admin):
        groups = Group.objects.all()
        return [(group.id, group.name) for group in groups]

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(groups__id__exact=self.value())
        return queryset

class TagFilter(admin.SimpleListFilter):
    title = '标签'
    parameter_name = 'tags'

    def lookups(self, request, model_admin):
        tags = GroupTag.objects.all()
        return [(tag.id, tag.name) for tag in tags]

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(tags__id__exact=self.value())
        return queryset

class TagFilter2(admin.SimpleListFilter):
    title = '标签'
    parameter_name = 'tags'

    def lookups(self, request, model_admin):
        tags = GroupTag2.objects.all()
        return [(tag.id, tag.name) for tag in tags]

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(tags__id__exact=self.value())
        return queryset

@admin.action(
    permissions=['delete'],
    description=_('删除账号'),
)
def delete_selected(modeladmin, request, queryset):
    return default_delete_selected(modeladmin, request, queryset)
@admin.register(Account)
class AccountAdmin(admin.ModelAdmin):
    list_display = ('phone', 'name', 'username', 'display_groups', 'colored_status', 'last_op', 'formatted_last_op_time',  \
                    'formatted_import_time', 'last_invite_ok_count', 'invite_ok_total', 'last_error', 'formatted_last_error_time')
    ordering = ('-last_op_time',)
    readonly_fields = ('import_time', 'phone', 'status', 'last_op', 'last_op_time', 'name', 'username')
    change_list_template = "admin/account_changelist.html"
    filter_horizontal = ('groups',)  # 添加这个行来启用多对多字段的选择框
    # actions = [delete_selected, 'show_add_to_group', 'batch_login_action', 'show_join_group', 'invite_to_group_action', 'show_export_usernames', 'show_export_user_ids']
    actions = [delete_selected, 'show_add_to_group', 'batch_login_action', 'show_join_group', 'invite_to_group_action','updateuser']
    list_filter = (GroupFilter, 'status')  # 添加分组过滤器
    exclude = ['last_op_time', 'session_path', 'last_op', 'last_invite_ok_count', 'invite_ok_total', 'last_error', 'last_error_time', 'logged_in_sessions', 'current_session']

    def display_logged_in_sessions(self, obj):
        session_labels = {
            0: 'PC',
            1: 'iOS',
            2: 'Android',
            3: 'AndroidX'
        }
        labels = [session_labels[int(session)] for session in obj.logged_in_sessions]
        return format_html(' '.join(f'<span class="label label-info">{label}</span>' for label in labels))

    display_logged_in_sessions.short_description = '已登录平台'
    def formatted_last_op_time(self, obj):
        if obj.last_op_time:
            local_time = timezone.localtime(obj.last_op_time)
            return format_html(
                '{}<br>{}',
                local_time.strftime('%Y年%m月%d日'),
                local_time.strftime('%H:%M')
            )
        return ''

    formatted_last_op_time.short_description = '上次操作时间'

    def formatted_import_time(self, obj):
        if obj.import_time:
            local_time = timezone.localtime(obj.import_time)
            return format_html(
                '{}<br>{}',
                local_time.strftime('%Y年%m月%d日'),
                local_time.strftime('%H:%M')
            )
        return ''

    formatted_import_time.short_description = '导入时间'

    def formatted_last_error_time(self, obj):
        if obj.last_error_time:
            local_time = timezone.localtime(obj.last_error_time)
            return format_html(
                '{}<br>{}',
                local_time.strftime('%Y年%m月%d日'),
                local_time.strftime('%H:%M')
            )
        return ''

    formatted_last_error_time.short_description = '上次报错时间'

    def display_groups(self, obj):
        return format_html(
            ' '.join([f'<span class="label label-info">{group.name}</span>' for group in obj.groups.all()])
        )

    display_groups.short_description = '分组'


    def colored_status(self, obj):
        color_dict = {
            1: 'green',
            2: 'grey',
            3: 'red',
            4: 'orange',
        }
        color_code = color_dict.get(obj.status, 'black')
        status_display = obj.get_status_display()
        return format_html('<span style="color: {};">{}</span>', color_code, status_display)

    colored_status.short_description = '状态'

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('import-accounts/', self.admin_site.admin_view(self.import_accounts), name='import_accounts'),
            path('add-to-group/', self.admin_site.admin_view(self.add_to_group), name='add_to_group'),
            path('join-group/', self.admin_site.admin_view(self.join_group), name='join_group'),
            path('invite-group/', self.admin_site.admin_view(self.invite_group), name='invite_group'),
            path('batch-login/', self.admin_site.admin_view(self.batch_login_view), name='batch_login'),
            path('export-usernames/', self.admin_site.admin_view(self.export_usernames), name='export_usernames'),
            path('msg-group/', self.admin_site.admin_view(self.send_msg_to_group), name='msg_group'),
        ]
        return custom_urls + urls


    def import_accounts(self, request):
        if request.method == 'POST':
            form = UploadMultipleFilesForm(request.POST, request.FILES)
            if form.is_valid():
                files = form.cleaned_data['files']
                group_ids = form.cleaned_data['groups']
                for file in files:
                    handle_uploaded_file(file, group_ids)
                self.message_user(request, "账号导入完成", level=messages.SUCCESS)
                return redirect('..')
        else:
            form = UploadMultipleFilesForm()
        return render(request, 'admin/import_accounts.html', {'form': form})

    def show_add_to_group(self, request, queryset):
        account_ids = list(queryset.values_list('id', flat=True))
        if request.method == 'POST':
            form = GroupSelectionForm(request.POST)
            if form.is_valid():
                group_ids = form.cleaned_data['groups']
                selected_accounts = Account.objects.filter(id__in=account_ids)
                for account in selected_accounts:
                    account.groups.add(*group_ids)
                self.message_user(request, "选中的账号已成功添加到分组")

    show_add_to_group.short_description = "分配到分组"

    def add_to_group(self, request):
        accounts = request.GET.get('accounts', '').split(',')
        if request.method == 'POST':
            form = GroupSelectionForm(request.POST)
            if form.is_valid():
                group_ids = form.cleaned_data['groups']
                selected_accounts = Account.objects.filter(id__in=accounts)
                for account in selected_accounts:
                    account.groups.add(*group_ids)
                self.message_user(request, "选中的账号已成功添加到分组")
                return redirect('..')
        else:
            form = GroupSelectionForm()

        return render(request, 'admin/add_to_group.html', {'form': form, 'accounts': accounts})

    # def batch_login_action(self, request, queryset):
    #     task = TaskStatus.objects.create(operation=2, status=1)
    #     account_ids = list(queryset.values_list('id', flat=True))
    #     print(f'account_ids: {account_ids}')
    #     batch_login.delay(task.task_id, account_ids)
    #     self.message_user(request, "批量登录任务已启动", level=messages.SUCCESS)

    def batch_login_view(self, request):
        accounts = request.GET.get('accounts', '').split(',')
        if request.method == 'POST':
            form = PlatformChoiceForm(request.POST)
            if form.is_valid():
                platform = form.cleaned_data['platform']
                print(f'登录平台：{platform}')
                task = TaskStatus.objects.create(operation=2, status=1)
                result = batch_login.delay(task.task_id, accounts, int(platform))
                task.celery_task_id = result.id
                task.save()
                self.message_user(request, "批量登录任务已启动", level=messages.SUCCESS)
                # return HttpResponseRedirect(request.get_full_path())
                return redirect('..')
        else:
            form = PlatformChoiceForm()

        return render(request, 'admin/batch_login_action.html', {'accounts': accounts, 'form': form})

    def batch_login_action(self, request, queryset):
        account_ids = list(queryset.values_list('id', flat=True))
        if request.method == 'POST':
            task = TaskStatus.objects.create(operation=2, status=1)
            # result = batch_login.delay(task.task_id, account_ids, 0)
            result = batch_login(task.task_id, account_ids, 0)
            # task.celery_task_id = result.id
            # task.save()
            self.message_user(request, "批量登录任务已启动", level=messages.SUCCESS)

        # return redirect(f'batch-login/?accounts={",".join(selected)}')

    batch_login_action.short_description = "批量登录"

    def load_chats_action(self, request, queryset):
        task = TaskStatus.objects.create(operation=1, status=1)
        account_ids = list(queryset.values_list('id', flat=True))
        print(f'account_ids: {account_ids}')
        load_recent_chats.delay(task.task_id, account_ids)
        self.message_user(request, "批量登录任务已启动", level=messages.SUCCESS)

    load_chats_action.short_description = "最近聊天记录"

    def join_group(self, request):
        accounts = request.GET.get('accounts', '').split(',')
        if request.method == 'POST':
            form = JoinGroupForm(request.POST)
            if form.is_valid():
                group_name = form.cleaned_data['group_name']
                task = TaskStatus.objects.create(operation=3, status=1)
                result = batch_join_group.delay(task.task_id, accounts, group_name)
                task.celery_task_id = result.id
                task.save()
                self.message_user(request, "批量入群任务已启动", level=messages.SUCCESS)
                return redirect('..')
        else:
            form = JoinGroupForm()
        return render(request, 'admin/join_group.html', {'form': form, 'accounts': accounts})

    def show_join_group(self, request, queryset):

        account_ids = list(queryset.values_list('id', flat=True))
        if request.method == 'POST':
            form = JoinGroupForm(request.POST)
            if form.is_valid():
                group_name = form.cleaned_data['group_name']
                task = TaskStatus.objects.create(operation=3, status=1)
                result = batch_join_group.delay(task.task_id, account_ids, group_name)
                task.celery_task_id = result.id
                task.save()
                self.message_user(request, "批量入群任务已启动", level=messages.SUCCESS)

        # return redirect(f'join-group/?accounts={",".join(selected)}')

    show_join_group.short_description = "批量入群"

    # def show_invite_to_group(self, request, queryset):
    #     account_ids = list(queryset.values_list('id', flat=True))
    #     print(f'account_ids: {account_ids}')
    #
    #     selected = request.POST.getlist('_selected_action')
    #     return redirect(f'invite-group/?accounts={",".join(selected)}')
    #
    # show_invite_to_group.short_description = "拉人入群"

    def invite_to_group_action(self, request, queryset):
        account_ids = list(queryset.values_list('id', flat=True))
        # selected = request.POST.getlist('_selected_action')
        # print(f'selected: {selected}')

        if request.method == 'POST':
            form = InviteGroupForm(request.POST, request.FILES)
            if form.is_valid():
                group_name = form.cleaned_data['group_name']
                file = request.FILES['invitees_file']
                invitees = file.read().decode('utf-8').splitlines()
                max_invitees = form.cleaned_data['max_invitees']
                interval = form.cleaned_data['interval']
                invite_by = form.cleaned_data['invite_by']
                active_only = form.cleaned_data['active_only']

                users = []
                for user in invitees:
                    user = user.strip()
                    if user:
                        users.append(user)
                task = TaskStatus.objects.create(operation=14, status=1)
                result = invite_group(task.task_id, account_ids, group_name, users, int(invite_by),int(max_invitees), int(interval), active_only)
                # task.celery_task_id = result.id
                # task.save()
                self.message_user(request, "拉人入群任务已启动", level=messages.SUCCESS)


    invite_to_group_action.short_description = "拉人入群"

    def updateuser(self, request, queryset):
        account_ids = list(queryset.values_list('id', flat=True))
        if request.method == 'POST':
            form = UserForm(request.POST, request.FILES)
            if form.is_valid():
                file = request.FILES['invitees_file']
                invitees = file.read().decode('utf-8').splitlines()
                max_invitees = form.cleaned_data['max_invitees']

                users = []
                for user in invitees:
                    user = user.strip()
                    if user:
                        users.append(user)
                task = TaskStatus.objects.create(operation=4, status=1)

                # result = invite_user_list.delay(task.task_id, account_ids, users, int(max_invitees))
                result = invite_user_list(task.task_id, account_ids, users, int(max_invitees))
                print(result)
                # task.celery_task_id = result.id
                # task.save()
                self.message_user(request, "导入用户任务已启动", level=messages.SUCCESS)

    updateuser.short_description = "导入用户"

    def invite_group(self, request):
        accounts = request.GET.get('accounts', '').split(',')
        # by_phone = request.GET.get('phone', '')
        # print(f'invite_group accounts {accounts}')
        if request.method == 'POST':
            form = InviteGroupForm(request.POST, request.FILES)
            if form.is_valid():
                group_name = form.cleaned_data['group_name']
                file = request.FILES['invitees_file']
                invitees = file.read().decode('utf-8').splitlines()
                max_invitees = form.cleaned_data['max_invitees']
                interval = form.cleaned_data['interval']
                invite_by = form.cleaned_data['invite_by']
                active_only = form.cleaned_data['active_only']
                users = []
                for user in invitees:
                    user = user.strip()
                    if user:
                        users.append(user)
                task = TaskStatus.objects.create(operation=4, status=1)
                result = invite_group.delay(task.task_id, accounts, group_name, users, int(invite_by), int(max_invitees), int(interval), active_only)
                task.celery_task_id = result.id
                task.save()
                self.message_user(request, "拉人入群任务已启动", level=messages.SUCCESS)
                return redirect('..')
        else:
            form = InviteGroupForm()
        return render(request, 'admin/invite_to_group.html', {'form': form, 'accounts': accounts})

    def changelist_view(self, request, extra_context=None):
        extra_context = extra_context or {}
        extra_context['user_form'] = UserForm()
        extra_context['invite_form'] = InviteGroupForm()
        extra_context['join_form'] = JoinGroupForm()
        extra_context['msg_form'] = TelegramMessageForm()
        extra_context['import_form'] = UploadMultipleFilesForm()
        extra_context['assign_form'] = GroupSelectionForm()
        extra_context['title'] = 'TG账号管理'

        # per_page = request.GET.get('per_page', 10)
        # self.list_per_page = int(per_page)
        return super(AccountAdmin, self).changelist_view(request, extra_context=extra_context)

    def export_usernames(self, request):
        accounts = request.GET.get('accounts', '').split(',')
        export_id = request.GET.get('export_id', '')
        if request.method == 'POST':
            form = ExportUsernamesForm(request.POST, request.FILES)
            if form.is_valid():
                file = request.FILES['invitees_file']
                invitees = file.read().decode('utf-8').splitlines()
                max_users = form.cleaned_data['max_users']

                users = []
                for user in invitees:
                    user = user.strip()
                    if user:
                        users.append(user)
                task = TaskStatus.objects.create(operation=7 if export_id == '1' else 6, status=1)
                scheme = request.scheme
                host = request.get_host()
                result = export_usernames.delay(scheme, host, task.task_id, accounts, users, export_id == '1', max_users)
                task.celery_task_id = result.id
                task.save()
                self.message_user(request, "手机号转用户名任务已启动", level=messages.SUCCESS)
                return redirect('..')
        else:
            form = ExportUsernamesForm()
        return render(request, 'admin/export_usernames.html', {'form': form, 'accounts': accounts, 'export_id': export_id})

    def show_export_usernames(self, request, queryset):
        selected = request.POST.getlist('_selected_action')
        return redirect(f'export-usernames/?accounts={",".join(selected)}')

    show_export_usernames.short_description = "手机号转用户名"

    def show_export_user_ids(self, request, queryset):
        selected = request.POST.getlist('_selected_action')
        return redirect(f'export-usernames/?accounts={",".join(selected)}&export_id=1')

    show_export_user_ids.short_description = "手机号转用户ID"

    def send_msg_to_group(self, request):
        accounts = request.GET.get('accounts', '').split(',')

        if request.method == 'POST':
            form = TelegramMessageForm(request.POST, request.FILES)
            if form.is_valid():
                file = request.FILES['group_file']
                groups = file.read().decode('utf-8').splitlines()
                cleaned_groups = [clean_group_id(group) for group in groups]
                media_file = form.cleaned_data.get('media_file')
                message_content = form.cleaned_data['message_content']
                # message_content = message_content.replace('<br />', '\n').replace('&nbsp;', ' ')
                message_content = message_content.replace('<br />', '\n')

                fss = FileSystemStorage()
                if media_file:
                    ext = os.path.splitext(media_file.name)[1]
                    unique_filename = f"{uuid.uuid4().hex}{ext}"
                    media_file_path = fss.save(unique_filename, media_file)
                    media_file_full_path = os.path.normpath(os.path.join(settings.MEDIA_ROOT, media_file_path))
                else:
                    media_file_full_path = None

                # print(f'message_content: {message_content}, media_file_full_path: {media_file_full_path}')

                task = TaskStatus.objects.create(operation=8, status=1)
                result = msg_to_group_task.delay(task.task_id, accounts, cleaned_groups, media_file_full_path, message_content)
                task.celery_task_id = result.id
                task.save()
                self.message_user(request, "发群消息任务已启动", level=messages.SUCCESS)
                return redirect('..')
        else:
            form = TelegramMessageForm()
        return render(request, 'admin/msg_to_group.html', {'form': form, 'accounts': accounts})

    def show_msg_to_group(self, request, queryset):
        account_ids = list(queryset.values_list('id', flat=True))
        if request.method == 'POST':
            form = TelegramMessageForm(request.POST, request.FILES)
            if form.is_valid():
                file = request.FILES['group_file']
                groups = file.read().decode('utf-8').splitlines()
                cleaned_groups = [clean_group_id(group) for group in groups]
                media_file = form.cleaned_data.get('media_file')
                message_content = form.cleaned_data['message_content']
                # message_content = message_content.replace('<br />', '\n').replace('&nbsp;', ' ')
                message_content = message_content.replace('<br />', '\n')

                fss = FileSystemStorage()
                if media_file:
                    ext = os.path.splitext(media_file.name)[1]
                    unique_filename = f"{uuid.uuid4().hex}{ext}"
                    media_file_path = fss.save(unique_filename, media_file)
                    media_file_full_path = os.path.normpath(os.path.join(settings.MEDIA_ROOT, media_file_path))
                else:
                    media_file_full_path = None

                # print(f'message_content: {message_content}, media_file_full_path: {media_file_full_path}')

                task = TaskStatus.objects.create(operation=8, status=1)
                result = msg_to_group_task.delay(task.task_id, account_ids, cleaned_groups, media_file_full_path, message_content)
                task.celery_task_id = result.id
                task.save()
                self.message_user(request, "发群消息任务已启动", level=messages.SUCCESS)

    show_msg_to_group.short_description = "发群消息"

admin_site.register(Account, AccountAdmin)


def is_xlsx(file):
    """Check if the file is an xlsx file based on its signature."""
    file.seek(0)
    file_header = file.read(4)
    file.seek(0)  # Reset file pointer to the beginning
    return file_header == b'PK\x03\x04'

def save_images_from_excel(sheet, images_folder):
    """Save images from the given sheet to the specified folder and return a list of image paths."""
    images = []
    for image in sheet._images:
        # Get cell reference (e.g., 'C2')
        cell_ref = image.anchor._from.cell
        # Define image path
        img_path = os.path.join(images_folder, f"{cell_ref}.jpg")
        # Save image
        image.image.save(img_path)
        images.append((cell_ref, img_path))
    return images

@admin.register(AccountMessaging)
class AccountMessagingAdmin(admin.ModelAdmin):
    list_display = ('phone', 'name', 'username', 'display_groups', 'colored_status', 'last_op', 'formatted_last_op_time',  \
                    'formatted_import_time', 'last_error', 'formatted_last_error_time')
    ordering = ('-last_op_time',)
    readonly_fields = ('import_time', 'phone', 'status', 'last_op', 'last_op_time', 'name', 'username')
    change_list_template = "admin/account_changelist.html"
    filter_horizontal = ('groups',)  # 添加这个行来启用多对多字段的选择框
    actions = [delete_selected, 'show_add_to_group', 'batch_login_action', 'show_msg_to_group', 'show_msg_to_user']
    # actions = ['show_add_to_group', 'batch_login_action', 'show_join_group', 'show_invite_to_group']
    list_filter = (GroupFilter, 'status')  # 添加分组过滤器
    exclude = ['last_op_time', 'session_path', 'last_op', 'last_invite_ok_count', 'invite_ok_total', 'last_error', 'last_error_time', 'logged_in_sessions', 'current_session']

    def formatted_last_op_time(self, obj):
        if obj.last_op_time:
            local_time = timezone.localtime(obj.last_op_time)
            return format_html(
                '{}<br>{}',
                local_time.strftime('%Y年%m月%d日'),
                local_time.strftime('%H:%M')
            )
        return ''

    formatted_last_op_time.short_description = '上次操作时间'

    def formatted_import_time(self, obj):
        if obj.import_time:
            local_time = timezone.localtime(obj.import_time)
            return format_html(
                '{}<br>{}',
                local_time.strftime('%Y年%m月%d日'),
                local_time.strftime('%H:%M')
            )
        return ''

    formatted_import_time.short_description = '导入时间'

    def formatted_last_error_time(self, obj):
        if obj.last_error_time:
            local_time = timezone.localtime(obj.last_error_time)
            return format_html(
                '{}<br>{}',
                local_time.strftime('%Y年%m月%d日'),
                local_time.strftime('%H:%M')
            )
        return ''

    formatted_last_error_time.short_description = '上次报错时间'

    def display_groups(self, obj):
        return format_html(
            ' '.join([f'<span class="label label-info">{group.name}</span>' for group in obj.groups.all()])
        )

    display_groups.short_description = '分组'

    def colored_status(self, obj):
        color_dict = {
            1: 'green',
            2: 'grey',
            3: 'red',
            4: 'orange',
        }
        color_code = color_dict.get(obj.status, 'black')
        status_display = obj.get_status_display()
        return format_html('<span style="color: {};">{}</span>', color_code, status_display)

    colored_status.short_description = '状态'

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('import-accounts/', self.admin_site.admin_view(self.import_accounts), name='import_accounts'),
            path('add-to-group/', self.admin_site.admin_view(self.add_to_group), name='add_to_group'),

            path('batch-login/', self.admin_site.admin_view(self.batch_login_view), name='batch_login'),
            path('msg-group/', self.admin_site.admin_view(self.send_msg_to_group), name='msg_group'),
        ]
        return custom_urls + urls


    def import_accounts(self, request):
        if request.method == 'POST':
            form = UploadMultipleFilesForm(request.POST, request.FILES)
            if form.is_valid():
                files = form.cleaned_data['files']
                group_ids = form.cleaned_data['groups']
                for file in files:
                    handle_uploaded_file(file, group_ids)
                self.message_user(request, "账号导入完成", level=messages.SUCCESS)
                return redirect('..')
        else:
            form = UploadMultipleFilesForm()
        return render(request, 'admin/import_accounts.html', {'form': form})

    def show_add_to_group(self, request, queryset):
        account_ids = list(queryset.values_list('id', flat=True))
        if request.method == 'POST':
            form = GroupSelectionForm(request.POST)
            if form.is_valid():
                group_ids = form.cleaned_data['groups']
                selected_accounts = Account.objects.filter(id__in=account_ids)
                for account in selected_accounts:
                    account.groups.add(*group_ids)
                self.message_user(request, "选中的账号已成功添加到分组")

    show_add_to_group.short_description = "分配到分组"

    def add_to_group(self, request):
        accounts = request.GET.get('accounts', '').split(',')
        if request.method == 'POST':
            form = GroupSelectionForm(request.POST)
            if form.is_valid():
                group_ids = form.cleaned_data['groups']
                selected_accounts = Account.objects.filter(id__in=accounts)
                for account in selected_accounts:
                    account.groups.add(*group_ids)
                self.message_user(request, "选中的账号已成功添加到分组")
                return redirect('..')
        else:
            form = GroupSelectionForm()

        return render(request, 'admin/add_to_group.html', {'form': form, 'accounts': accounts})

    # def batch_login_action(self, request, queryset):
    #     task = TaskStatus.objects.create(operation=2, status=1)
    #     account_ids = list(queryset.values_list('id', flat=True))
    #     print(f'account_ids: {account_ids}')
    #     batch_login.delay(task.task_id, account_ids)
    #     self.message_user(request, "批量登录任务已启动", level=messages.SUCCESS)

    def batch_login_view(self, request):
        accounts = request.GET.get('accounts', '').split(',')
        print()
        if request.method == 'POST':
            form = PlatformChoiceForm(request.POST)
            if form.is_valid():
                platform = form.cleaned_data['platform']
                print(f'登录平台：{platform}')
                task = TaskStatus.objects.create(operation=2, status=1)
                result = batch_login.delay(task.task_id, accounts, int(platform))
                task.celery_task_id = result.id
                task.save()
                self.message_user(request, "批量登录任务已启动", level=messages.SUCCESS)
                # return HttpResponseRedirect(request.get_full_path())
                return redirect('..')
        else:
            form = PlatformChoiceForm()

        return render(request, 'admin/batch_login_action.html', {'accounts': accounts, 'form': form})

    def batch_login_action(self, request, queryset):
        print(queryset)
        account_ids = list(queryset.values_list('id', flat=True))
        if request.method == 'POST':
            task = TaskStatus.objects.create(operation=2, status=1)
            result = batch_login.delay(task.task_id, account_ids, 0)
            task.celery_task_id = result.id
            task.save()
            self.message_user(request, "批量登录任务已启动", level=messages.SUCCESS)

        # return redirect(f'batch-login/?accounts={",".join(selected)}')

    batch_login_action.short_description = "批量登录"


    def changelist_view(self, request, extra_context=None):
        extra_context = extra_context or {}

        extra_context['msg_form'] = TelegramMessageForm()
        extra_context['msg_user_form'] = TelegramMessageUserForm()
        extra_context['import_form'] = UploadMultipleFilesForm()
        extra_context['assign_form'] = GroupSelectionForm()
        extra_context['title'] = '消息管理'

        # per_page = request.GET.get('per_page', 10)
        # self.list_per_page = int(per_page)
        return super(AccountMessagingAdmin, self).changelist_view(request, extra_context=extra_context)

    @permission_required('auth.can_access_massaging')
    def send_msg_to_group(self, request):
        accounts = request.GET.get('accounts', '').split(',')

        if request.method == 'POST':
            form = TelegramMessageForm(request.POST, request.FILES)
            if form.is_valid():
                file = request.FILES['group_file']
                groups = file.read().decode('utf-8').splitlines()
                cleaned_groups = [clean_group_id(group) for group in groups]
                media_file = form.cleaned_data.get('media_file')
                message_content = form.cleaned_data['message_content']
                # message_content = message_content.replace('<br />', '\n').replace('&nbsp;', ' ')
                message_content = message_content.replace('<br />', '\n')

                fss = FileSystemStorage()
                if media_file:
                    ext = os.path.splitext(media_file.name)[1]
                    unique_filename = f"{uuid.uuid4().hex}{ext}"
                    media_file_path = fss.save(unique_filename, media_file)
                    media_file_full_path = os.path.normpath(os.path.join(settings.MEDIA_ROOT, media_file_path))
                else:
                    media_file_full_path = None

                # print(f'message_content: {message_content}, media_file_full_path: {media_file_full_path}')

                task = TaskStatus.objects.create(operation=8, status=1)
                result = msg_to_group_task.delay(task.task_id, accounts, cleaned_groups, media_file_full_path, message_content)
                task.celery_task_id = result.id
                task.save()
                self.message_user(request, "发群消息任务已启动", level=messages.SUCCESS)
                return redirect('..')
        else:
            form = TelegramMessageForm()
        return render(request, 'admin/msg_to_group.html', {'form': form, 'accounts': accounts})

    def show_msg_to_group(self, request, queryset):
        account_ids = list(queryset.values_list('id', flat=True))
        if request.method == 'POST':
            form = TelegramMessageForm(request.POST, request.FILES)
            if form.is_valid():
                file = request.FILES['group_file']
                groups = file.read().decode('utf-8').splitlines()
                cleaned_groups = [clean_group_id(group) for group in groups]
                media_file = form.cleaned_data.get('media_file')
                message_content = form.cleaned_data['message_content']
                # message_content = message_content.replace('<br />', '\n').replace('&nbsp;', ' ')
                message_content = message_content.replace('<br />', '\n')

                fss = FileSystemStorage()
                if media_file:
                    ext = os.path.splitext(media_file.name)[1]
                    unique_filename = f"{uuid.uuid4().hex}{ext}"
                    media_file_path = fss.save(unique_filename, media_file)
                    media_file_full_path = os.path.normpath(os.path.join(settings.MEDIA_ROOT, media_file_path))
                else:
                    media_file_full_path = None

                # print(f'message_content: {message_content}, media_file_full_path: {media_file_full_path}')

                task = TaskStatus.objects.create(operation=8, status=1)
                result = msg_to_group_task.delay(task.task_id, account_ids, cleaned_groups, media_file_full_path, message_content)
                task.celery_task_id = result.id
                task.save()
                self.message_user(request, "发群消息任务已启动", level=messages.SUCCESS)

    show_msg_to_group.short_description = "发群消息"


    def show_msg_to_user(self, request, queryset):
        account_ids = list(queryset.values_list('id', flat=True))
        if request.method == 'POST':
            form = TelegramMessageUserForm(request.POST, request.FILES)
            if form.is_valid():
                file = request.FILES['msg_file']
                max_msgs_per_account = form.cleaned_data['max_msgs_per_account']

                data = []
                # wb = openpyxl.load_workbook(file)
                # sheet = wb.active
                #
                # for row in sheet.iter_rows(min_row=2, values_only=True):  # Assuming first row is the header
                #     data.append([cell for cell in row])
                images_folder = os.path.join(settings.MEDIA_ROOT, 'excel_imgs')
                try:
                    if is_xlsx(file):
                        # Process xlsx file
                        wb = openpyxl.load_workbook(file)
                        sheet = wb.active

                        # Save images and get their paths
                        # images = save_images_from_excel(sheet, images_folder)

                        for row in sheet.iter_rows(min_row=2, values_only=True):  # Assuming first row is the header
                            row_data = [cell for cell in row]
                            # Check if there's an image in this row
                            # for image in images:
                            #     if image[0].startswith(row[0]):  # Match image to the corresponding row
                            #         print(f'image: {image[0]}:{image[1]}')
                            #         row_data.append(image[1])
                            data.append(row_data)
                    else:
                        # Process xls file
                        file.seek(0)  # Ensure file pointer is at the beginning
                        wb = xlrd.open_workbook(file_contents=file.read())
                        sheet = wb.sheet_by_index(0)
                        for row_idx in range(1, sheet.nrows):  # Assuming first row is the header
                            row = sheet.row(row_idx)
                            data.append([cell.value for cell in row])
                except Exception as e:
                    print(f'文件读取失败：{e}')
                    self.message_user(request, "文件格式不支持或文件已损坏", level=messages.ERROR)
                    return

                # task = TaskStatus.objects.create(operation=13, status=1)
                # result = msg_to_user_task.delay(task.task_id, account_ids, data, int(max_msgs_per_account))
                # task.celery_task_id = result.id
                # task.save()
                self.message_user(request, "批量私信任务已启动", level=messages.SUCCESS)

    show_msg_to_user.short_description = "批量私信"

admin_site.register(AccountMessaging, AccountMessagingAdmin)

@admin.register(Group)
class GroupAdmin(admin.ModelAdmin):
    list_display = ('name',)

admin_site.register(Group, GroupAdmin)

@admin.register(TaskStatus)
class TaskStatusAdmin(admin.ModelAdmin):
    list_display = ('task_id', 'start_time', 'end_time', 'operation', 'status', 'download_link')
    change_list_template = "admin/taskstatus_changelist.html"
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('stop_all_tasks/', self.admin_site.admin_view(self.stop_all_tasks_view), name='stop_all_tasks'),
        ]
        return custom_urls + urls

    def stop_all_tasks_view(self, request):
        # 获取所有状态为“正在执行”的任务
        running_tasks = TaskStatus.objects.filter(status=2)  # 假设 2 表示“正在执行”

        for task in running_tasks:
            task.status = 3  # 停止任务
            task.end_time = timezone.now()
            task.save()

            # 使用 celery current_app.control 停止任务
            app = current_app
            if task.celery_task_id:
                print(f'正在停止 celery 任务：{task.celery_task_id}')
                messages.success(request, f'正在停止 celery 任务：{task.celery_task_id}')
                app.control.revoke(task.celery_task_id, terminate=True, signal='SIGTERM')

        messages.success(request, "所有正在执行的任务已停止。")
        return redirect('..')

    def download_link(self, obj):
        if obj.temp_file_path:
            url = reverse('download_usernames', args=[obj.task_id, obj.operation])
            return format_html('<a href="{}" target="_blank">下载</a>', url)
        return '-'

    download_link.short_description = '操作'

    def changelist_view(self, request, extra_context=None):
        extra_context = extra_context or {}
        extra_context['title'] = '任务记录'
        return super(TaskStatusAdmin, self).changelist_view(request, extra_context=extra_context)

admin_site.register(TaskStatus, TaskStatusAdmin)

@admin.register(Setting)
class SettingAdmin(admin.ModelAdmin):
    list_display = ('setting_key', 'value', 'notes', 'update_time')
    # search_fields = ('setting_key', 'value', 'notes')
    list_editable = ('value', 'notes')

    def changelist_view(self, request, extra_context=None):
        extra_context = extra_context or {}
        extra_context['title'] = '设置'
        return super(SettingAdmin, self).changelist_view(request, extra_context=extra_context)

admin_site.register(Setting, SettingAdmin)


@admin.action(description='刷新群组')
def refresh_groups(modeladmin, request, queryset):
    task = TaskStatus.objects.create(operation=5, status=1)
    group_ids = list(queryset.values_list('id', flat=True))
    result = refresh_group_info_task.delay(task.task_id, group_ids)
    modeladmin.message_user(request, "刷新群组任务开始")
    task.celery_task_id = result.id
    task.save()

@admin.action(description='刷新群组')
def refresh_groups2(modeladmin, request, queryset):
    task = TaskStatus.objects.create(operation=5, status=1)
    group_ids = list(queryset.values_list('id', flat=True))
    result = refresh_groupcollect_info_task.delay(task.task_id, group_ids)
    modeladmin.message_user(request, "刷新群组任务开始")
    task.celery_task_id = result.id
    task.save()

@admin.action(
    permissions=['delete'],
    description=_('删除群组'),
)
def delete_group_selected(modeladmin, request, queryset):
    return default_delete_selected(modeladmin, request, queryset)
@admin.register(TGGroup)
class TGGroupAdmin(admin.ModelAdmin):
    list_display = ('group_id', 'group_title', 'thumbnail', 'display_tags', 'display_admins', 'participant_count', 'online_count', 'participants_hidden', 'update_time', 'show_update_group')
    form = TGGroupForm
    change_form_template = 'admin/tggroup_change_form.html'
    change_list_template = "admin/tggroup_change_list.html"
    actions = ['show_add_to_group', refresh_groups]
    ordering = ('-update_time',)
    filter_horizontal = ('tags',)
    list_filter = (TagFilter, )

    def thumbnail(self, obj):
        if obj.photo:
            return format_html('<img src="{}" style="max-height: 50px;" />', obj.photo)
        return "-"

    thumbnail.short_description = '头像'

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('check_username/', self.admin_site.admin_view(self.check_username), name='check_username'),
        ]
        return custom_urls + urls

    def check_username(self, request):
        username = request.GET.get('username')
        id = request.GET.get('id')
        username = username.strip()
        if not username:
            return JsonResponse({'is_taken': False})
        tg_group = TGGroup.objects.get(pk=id)
        if not tg_group:
            return JsonResponse({'is_taken': False})

        is_available = async_to_sync(do_telegram_account)(tg_group.admins.first(), 11, op_check_username_availability, types.PeerChannel(channel_id=tg_group.gid), username)
        return JsonResponse({'is_available': is_available})

    def show_update_group(self, obj):
        if obj.admins and obj.admins.first():
            return format_html(
                '<button type="button" onclick="showSetGroupUsernameDialog({})">设置</button>',
                obj.pk
            )
        return '-'

    show_update_group.short_description = '操作'

    def show_add_to_group(self, request, queryset):
        tggroup_ids = list(queryset.values_list('id', flat=True))
        if request.method == 'POST':
            form = TagSelectionForm(request.POST)
            if form.is_valid():
                group_ids = form.cleaned_data['groups']
                selected_tggroups = TGGroup.objects.filter(id__in=tggroup_ids)
                for tggroup in selected_tggroups:
                    tggroup.tags.add(*group_ids)
                self.message_user(request, "选中的群组已成功添加到标签")

    show_add_to_group.short_description = "分配到标签"

    def display_tags(self, obj):
        return format_html(
            ' '.join([f'<span class="label label-info">{tag.name}</span>' for tag in obj.tags.all()])
        )

    display_tags.short_description = '标签'

    def display_admins(self, obj):
        return format_html(
            ' '.join([f'<span class="label label-info">{admin.name}</span>' for admin in obj.admins.all()])
        )

    display_admins.short_description = '管理员'

    # remove default delete_selected action
    # def get_actions(self, request):
    #     actions = super().get_actions(request)
    #     # Remove the default delete_selected action
    #     if 'delete_selected' in actions:
    #         del actions['delete_selected']
    #     return actions

    def save_model(self, request, obj, form, change):
        obj.save()

    def changelist_view(self, request, extra_context=None):
        if request.method == 'POST' and 'action' in request.POST and request.POST['action'] == 'update_group_action':
            form = UpdateGroupForm(request.POST, request.FILES)
            if form.is_valid():
                group = TGGroup.objects.get(pk=request.POST.get('_selected_action'))
                title = form.cleaned_data['title']
                about = form.cleaned_data['about']
                photo = form.clean_photo()
                admins = form.cleaned_data['admins']
                ban_send_messages = form.cleaned_data['ban_send_messages']
                username = form.cleaned_data['username']

                result = async_to_sync(do_telegram_account)(group.admins.first(), 12, op_edit_group, group, title, about, photo, admins, ban_send_messages, username)
                if result:
                    group.save()
                    self.message_user(request, "群组编辑成功")
                    return redirect('.')
            else:
                self.message_user(request, "表单提交有误", level='error')

        extra_context = extra_context or {}
        extra_context['title'] = 'TG群组管理'
        extra_context['create_form'] = TGGroupForm()
        extra_context['import_form'] = ImportGroupForm()
        extra_context['assign_form'] = TagSelectionForm()
        extra_context['new_form'] = CreateTGGroupForm()
        extra_context['update_form'] = UpdateGroupForm()
        # per_page = request.GET.get('per_page', 10)
        # self.list_per_page = int(per_page)
        return super(TGGroupAdmin, self).changelist_view(request, extra_context=extra_context)

    def get_changelist_instance(self, request):
        self.list_display_links = (None,)
        return super().get_changelist_instance(request)

admin_site.register(TGGroup, TGGroupAdmin)

@admin.register(TGGroupCollect)
class TGGroupCollectAdmin(admin.ModelAdmin):
    list_display = ('group_id', 'group_title', 'display_tags', 'participant_count', 'online_count', 'participants_hidden', 'update_time')
    form = TGGroupCollectForm
    change_form_template = 'admin/tggroup_change_form.html'
    change_list_template = "admin/tggroup2_change_list.html"
    actions = ['show_add_to_group', refresh_groups2, 'collect_action']
    ordering = ('-update_time',)
    filter_horizontal = ('tags',)
    list_filter = (TagFilter2,)

    def show_add_to_group(self, request, queryset):
        tggroup_ids = list(queryset.values_list('id', flat=True))
        if request.method == 'POST':
            form = Tag2SelectionForm(request.POST)
            if form.is_valid():
                group_ids = form.cleaned_data['groups']
                selected_tggroups = TGGroupCollect.objects.filter(id__in=tggroup_ids)
                for tggroup in selected_tggroups:
                    tggroup.tags.add(*group_ids)
                self.message_user(request, "选中的群组已成功添加到标签")

    show_add_to_group.short_description = "分配到标签"

    def display_tags(self, obj):
        return format_html(
            ' '.join([f'<span class="label label-info">{tag.name}</span>' for tag in obj.tags.all()])
        )

    display_tags.short_description = '标签'

    def collect_action(self, request, queryset):
        if not request.user.has_perm('auth.can_access_collect'):
            self.message_user(request, "你没有权限执行这个操作。", level=messages.ERROR)
            return

        group_ids = list(queryset.values_list('id', flat=True))
        if request.method == 'POST':
            form = CollectMembersForm(request.POST)
            if form.is_valid():
                account_group = form.cleaned_data.get('account_group')
                collect_data = form.cleaned_data['collect_data']
                last_seen = form.cleaned_data['last_seen']
                collect_admin = form.cleaned_data['collect_admin']
                collect_group = form.cleaned_data['collect_group']

                task = TaskStatus.objects.create(operation=9, status=1)
                result = collect_members_task.delay(task.task_id, account_group.pk, group_ids, int(collect_data), int(last_seen), collect_admin, collect_group)
                task.celery_task_id = result.id
                task.save()
                self.message_user(request, "采集任务开始")

    collect_action.short_description = "成员采集"

    def save_model(self, request, obj, form, change):
        obj.save()

    def operation_button(self, obj):
        return format_html(
            '<button id="collect-members-{0}" class="button" onclick="collectMembers({0})">收集成员列表</button>',
            obj.id
        )

    operation_button.short_description = '操作'
    operation_button.allow_tags = True

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('collect_members/<int:group_id>/', self.admin_site.admin_view(self.collect_members_view),
                 name='collect_members'),
        ]
        return custom_urls + urls

    def collect_members_view(self, request, group_id):
        from .utils import collect_members_async

        group = TGGroupCollect.objects.get(id=group_id)
        active_accounts = Account.objects.filter(status=1).order_by('last_op_time')[:3]
        for account in active_accounts:
            file_path = async_to_sync(collect_members_async)(account, group)

            if file_path:
                # 创建并返回文件下载响应
                if os.path.exists(file_path):
                    response = FileResponse(open(file_path, 'rb'), as_attachment=True,
                                            filename=os.path.basename(file_path))
                    # 将文件名添加到响应头
                    response[
                        'Content-Disposition'] = f'attachment; filename="{escape_uri_path(os.path.basename(file_path))}"'


                    return response
                else:
                    self.message_user(request, "生成的文件不存在", level=messages.ERROR)
                    return redirect("admin:main_tggroupcollect_changelist")  # 修改为实际的app名称

            pass

        self.message_user(request, "收集成员失败，请重试", level=messages.ERROR)
        return redirect("admin:main_tggroupcollect_changelist")  # 修改为实际的app名称

    def changelist_view(self, request, extra_context=None):
        extra_context = extra_context or {}
        extra_context['title'] = '用户校验'
        extra_context['create_form'] = TGGroupCollectForm()
        extra_context['collect_form'] = CollectMembersForm()
        extra_context['import_form'] = ImportGroupForm()
        extra_context['assign_form'] = Tag2SelectionForm()

        # per_page = request.GET.get('per_page', 10)
        # self.list_per_page = int(per_page)
        return super(TGGroupCollectAdmin, self).changelist_view(request, extra_context=extra_context)

admin_site.register(TGGroupCollect, TGGroupCollectAdmin)

@admin.register(GroupTag)
class GroupTagAdmin(admin.ModelAdmin):
    list_display = ('name',)

admin_site.register(GroupTag, GroupTagAdmin)

@admin.register(GroupTag2)
class GroupTag2Admin(admin.ModelAdmin):
    list_display = ('name',)

admin_site.register(GroupTag2, GroupTag2Admin)

