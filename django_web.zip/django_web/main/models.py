from django.db import models
import uuid
import asyncio
from asgiref.sync import async_to_sync, sync_to_async
import os
import glob
from django.db.models.signals import post_delete
from django.dispatch import receiver
from django.core.exceptions import ValidationError

OP_CHOICES = [
        (1, '未知'),
        (2, '登录'),
        (3, '加入群'),
        (4, '拉人入群'),
        (5, '刷新群组信息'),
        (6, '手机号转用户名'),
        (7, '手机号转用户ID'),
        (8, '发群消息'),
        (9, '采集成员'),
        (10, '创建群组'),
        (11, '检查用户名'),
        (12, '编辑群组'),
        (13, '批量私信'),
        (14, '导入用户'),
    ]

class Group(models.Model):
    name = models.CharField(max_length=255, unique=True, verbose_name='分组名')
    create_time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '账号分组'
        verbose_name_plural = '账号分组'

class GroupTag(models.Model):
    name = models.CharField(max_length=255, unique=True, verbose_name='标签名')
    create_time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '群组标签'
        verbose_name_plural = '群组标签'

class GroupTag2(models.Model):
    name = models.CharField(max_length=255, unique=True, verbose_name='标签名')
    create_time = models.DateTimeField(auto_now_add=True, blank=None)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '采集群组标签'
        verbose_name_plural = '采集群组标签'

class Account(models.Model):
    STATUS_CHOICES = [
        (1, '已登录'),
        (2, '未登录'),
        (3, '封禁'),
        (4, '未知'),
    ]

    PLATFORM_CHOICES = [
        (0, 'PC'),
        (1, 'iOS'),
        (2, 'Android'),
        (3, 'AndroidX'),
    ]

    phone = models.CharField(max_length=20, unique=True, verbose_name='手机号')
    name = models.CharField(max_length=255, null=True, blank=True, default='', verbose_name='姓名')
    username = models.CharField(max_length=255, null=True, blank=True, default='', verbose_name='用户名')
    import_time = models.DateTimeField(auto_now_add=True, verbose_name='导入时间')
    status = models.IntegerField(choices=STATUS_CHOICES, default=4, verbose_name='状态')
    last_op_time = models.DateTimeField(null=True, blank=True, verbose_name='上次操作时间')
    session_path = models.CharField(max_length=255, verbose_name='session文件路径')
    groups = models.ManyToManyField(Group, blank=True, verbose_name='分组')
    last_op = models.PositiveIntegerField(choices=OP_CHOICES, default=1, verbose_name='上次执行操作')
    last_invite_ok_count = models.PositiveIntegerField(default=0, verbose_name='上次拉人成功数')
    invite_ok_total = models.PositiveIntegerField(default=0, verbose_name='累计拉人成功数')
    last_error = models.CharField(max_length=255, null=True, blank=True, default='', verbose_name='上次报错')
    last_error_time = models.DateTimeField(null=True, blank=True, verbose_name='上次报错时间')
    logged_in_sessions = models.JSONField(default=list, verbose_name='已登录平台')  # 记录登录过的平台
    current_session = models.IntegerField(choices=PLATFORM_CHOICES, default=0, verbose_name='当前平台')  # 当前会话平台
    user_id = models.BigIntegerField(blank=True, null=True, unique=True, verbose_name='ID')
    access_hash = models.BigIntegerField(blank=True, null=True, verbose_name='Access Hash')

    def __str__(self):
        return f'{self.name} ({self.phone})'

    class Meta:
        verbose_name = 'TG账号'
        verbose_name_plural = 'TG账号'

class AccountMessaging(Account):
    class Meta:
        proxy = True
        verbose_name = '群发TG账号'
        verbose_name_plural = '群发TG账号'

@receiver(post_delete, sender=Account)
def delete_account_sessions(sender, instance, **kwargs):
    # 获取 session 文件的目录和文件名前缀
    path = str(instance.session_path)
    # print(f'deleting path: {path}')
    if path:
        session_dir = os.path.dirname(path)
        session_prefix = os.path.splitext(os.path.basename(path))[0]
        # 查找所有具有相同前缀的文件
        session_files = glob.glob(os.path.join(session_dir, session_prefix + '*'))
        # 删除所有匹配的文件
        for session_file in session_files:
            # print(f'Removing file: {session_file}')
            os.remove(session_file)

class Setting(models.Model):
    setting_key = models.CharField(max_length=255, unique=True, verbose_name='Key')
    value = models.TextField(verbose_name='Value')
    notes = models.TextField(blank=True, null=True, verbose_name='备注')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        verbose_name = '设置'
        verbose_name_plural = '设置'

    def __str__(self):
        return f"{self.setting_key}: {self.notes}"



class TaskStatus(models.Model):
    STATUS_CHOICES = [
        (1, '待开启'),
        (2, '进行中'),
        (3, '已结束'),
    ]

    task_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, verbose_name='任务ID')
    start_time = models.DateTimeField(auto_now_add=True, verbose_name='开始时间')
    end_time = models.DateTimeField(null=True, blank=True, verbose_name='结束时间')
    status = models.PositiveIntegerField(choices=STATUS_CHOICES, default=1, verbose_name='状态')
    operation = models.PositiveIntegerField(choices=OP_CHOICES, default=1, verbose_name='执行操作')
    temp_file_path = models.CharField(max_length=255, blank=True, null=True)
    celery_task_id = models.CharField(max_length=255, null=True, blank=True)  # 新增字段

    class Meta:
        verbose_name = '任务记录'
        verbose_name_plural = '任务记录'

class TGGroup(models.Model):
    gid = models.BigIntegerField(blank=True, null=True, unique=True, verbose_name='ID')
    group_id = models.CharField(max_length=255, unique=True, blank=True, null=True, verbose_name='群组用户名')
    group_title = models.CharField(max_length=255, blank=True, verbose_name='群组标题')
    group_desc = models.CharField(max_length=510, blank=True, verbose_name='群组描述')
    participant_count = models.IntegerField(blank=True, null=True, verbose_name='成员数')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    participants_hidden = models.BooleanField(verbose_name="隐藏成员", default=False, blank=True, null=True)
    online_count = models.IntegerField(blank=True, null=True, verbose_name='在线人数')
    tags = models.ManyToManyField(GroupTag, blank=True, verbose_name='标签')
    admins = models.ManyToManyField(Account, blank=True, verbose_name='管理员')
    photo = models.CharField(max_length=255, blank=True, verbose_name='头像')
    access_hash = models.BigIntegerField(blank=True, null=True, verbose_name='Access Hash')

    class Meta:
        verbose_name = 'TG群组'
        verbose_name_plural = 'TG群组'

    def __str__(self):
        return f'{self.group_title} ({self.group_id})'

    async def fetch_group_info(self):
        from .utils import do_telegram_account, op_fetch_group_info  # 同样在函数内部导入

        if self.pk and await sync_to_async(self.admins.first)():
            admin = await sync_to_async(self.admins.first)()
            accounts = [admin]
        else:
            accounts = await sync_to_async(
                lambda: list(Account.objects.filter(status=1).order_by('-last_op_time')[:6]))()
        for account in accounts:
            result = await do_telegram_account(account, 5, op_fetch_group_info, self)
            if result:
                return True
            pass

        return False

    def save(self, *args, skip_fetch=False, **kwargs):
        if not skip_fetch:
            result = async_to_sync(self.fetch_group_info)()
            if not result:
                # raise ValidationError("无法获取群组信息，保存操作已取消。")
                print(f'无法获取群组信息，保存操作已取消')
                return
        super().save(*args, **kwargs)

class TGGroupCollect(models.Model):
    group_id = models.CharField(max_length=255, unique=True, verbose_name='群组ID')
    group_title = models.CharField(max_length=255, blank=True, verbose_name='群组标题')
    participant_count = models.IntegerField(blank=True, null=True, verbose_name='成员数')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    participants_hidden = models.BooleanField(verbose_name="隐藏成员", default=False, blank=True, null=True)
    online_count = models.IntegerField(blank=True, null=True, verbose_name='在线人数')
    tags = models.ManyToManyField(GroupTag2, blank=True, verbose_name='标签')


    class Meta:
        verbose_name = '采集TG群组'
        verbose_name_plural = '采集TG群组'

    def __str__(self):
        return f'{self.group_title} ({self.group_id})'

    async def fetch_group_info(self):
        from .utils import do_telegram_account, op_fetch_group_info  # 同样在函数内部导入

        # get recent 3 available accounts
        # recent_accounts = Account.objects.filter(status=1).order_by('-last_op_time')[:3]
        # 异步执行同步的查询
        accounts = await sync_to_async(
            lambda: list(Account.objects.filter(status=1).order_by('-last_op_time')[:6]))()
        for account in accounts:
            result = await do_telegram_account(account, 5, op_fetch_group_info, self)
            if result:
                return True
            pass

        return False

    def save(self, *args, **kwargs):
        result = async_to_sync(self.fetch_group_info)()
        if not result:
            # raise ValidationError("无法获取群组信息，保存操作已取消。")
            print(f'无法获取群组信息，保存操作已取消')
            return
        super().save(*args, **kwargs)

class Tguser(models.Model):
        username = models.CharField(max_length=200, unique=True, verbose_name='标签名')
        status = models.CharField(max_length=100,null=True, verbose_name='状态')
        off_online = models.CharField(max_length=100,null=True,  verbose_name='是否在线')
        phone = models.CharField(max_length=50,null=True,  verbose_name='手机号')
        user_id = models.CharField(max_length=50,null=True,  verbose_name='用户ID')
        access_hash = models.CharField(max_length=200,null=True,  verbose_name='hash')
        type = models.CharField(max_length=10,null=True,  verbose_name='是否使用')
        create_time = models.DateTimeField(auto_now_add=True, blank=None)

        def __str__(self):
            return self.username