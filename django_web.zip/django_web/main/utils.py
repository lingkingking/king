import posixpath
import random
import re
import time
import traceback
import uuid
from io import BytesIO
from telethon.tl.functions.messages import CheckChatInviteRequest
import requests
import socks
from django.conf import settings
from django.core.cache import cache
from opentele.tl import TelegramClient
from opentele.api import API, UseCurrentSession
from telethon import errors
# from .settings import REGION, PROXY
from .settings import get_setting_value
from django.utils import timezone
from asgiref.sync import sync_to_async
from telethon.tl.types import InputPeerChannel, InputPeerUser
from telethon import events, utils, helpers
from telethon.tl import types, functions
import os
import tempfile
from datetime import datetime, timedelta
import pytz
import json
import asyncio
from telethon.tl.functions.channels import GetFullChannelRequest
LOCAL_TEST = False

async def get_proxy(region, ipproxy_name, current=0):
    region = region.upper()

    # 添加延迟
    time.sleep(random.randint(0, 10000) / 10000)
    proxy = ()
    fail_count = 0
    while 1:
        try:
            timestamp_hex = hex(int(time.time() * 1000))[2:]
            # 生成带时间戳的UUID
            uuid_with_timestamp = uuid.uuid1()
            # 拼接时间戳和UUID，并截取其中的16位作为UDID
            udid = (timestamp_hex + str(uuid_with_timestamp).replace('-', ''))[5:16]
            ran_str = "1234567890qwertyuiopasdfghjklmnbvcxzZXCVBNMLKJHGFDSAQWERTYUIOP"
            random_str = ''
            for ii in range(0, random.randint(4, 5)):
                random_str = f"{random_str}{ran_str[random.randint(0, len(ran_str) - 1)]}"

            ipproxy_name_list = ipproxy_name.split("|")
            if "国家大写" in ipproxy_name_list[0]:
                ipproxy_name_list[0] = ipproxy_name_list[0].replace("国家大写", region.upper())
            elif "国家小写" in ipproxy_name_list[0]:
                ipproxy_name_list[0] = ipproxy_name_list[0].replace("国家小写", region.lower())

            if "随机字符串" in ipproxy_name_list[0]:
                ipproxy_name_list[0] = ipproxy_name_list[0].replace("随机字符串", f"{udid}{random_str}")

            if "随机数字" in ipproxy_name_list[0]:
                ipproxy_name_list[0] = ipproxy_name_list[0].replace("随机数字", str(random.randint(1, 99999999)))

            proxy = (
                socks.SOCKS5,
                ipproxy_name_list[2],  # proxy host
                int(ipproxy_name_list[3]),  # proxy port
                True,  # flag indicating if the proxy requires authentication
                ipproxy_name_list[0],  # proxy username
                ipproxy_name_list[1]  # proxy password
            )

            if LOCAL_TEST:
                #for local testing only
                if current == 0:
                    proxy = (socks.SOCKS5, '127.0.0.1', 7890, True)
                else:
                    proxy = (socks.SOCKS5, '127.0.0.1', 4781, True)
                print(f'proxy: {proxy}')
                break

            rep = requests.get("https://ipinfo.io/json", proxies={
                'http': f'socks5://{ipproxy_name_list[0]}:{ipproxy_name_list[1]}@{ipproxy_name_list[2]}:{ipproxy_name_list[3]}',
                'https': f'socks5://{ipproxy_name_list[0]}:{ipproxy_name_list[1]}@{ipproxy_name_list[2]}:{ipproxy_name_list[3]}'
            }, timeout=10)
            if rep.status_code == 200 and rep.json().get("ip"):
                ip_real = rep.json().get("ip")
                country = rep.json().get("country")
                print(f'选择的IP地址地区：{region}, 实际IP所在地区：{country}')
                if country.lower() == region.lower():
                    print(f'使用代理IP: {ip_real}')
                    break

            else:
                fail_count += 1

            time.sleep(1)
        except Exception as e:
            print(f"获取代理异常{e}")
            fail_count += 1
            time.sleep(5)
        finally:
            if fail_count > 3:
                break
    return proxy



async def get_proxy_settings(current=0):
    # proxy = await sync_to_async(PROXY)()
    # region = await sync_to_async(REGION)()
    proxy = await get_setting_value('proxy', '')
    region = await get_setting_value('region', 'TW')
    return await get_proxy(region, proxy, current)

global_client_cache = {}

async def get_telegram_client(account, platform=0):
    client = None
    session_path = None
    if platform == 0:  # PC
        # api = API.TelegramDesktop.Generate(unique_id=account.phone)
        session_path = account.session_path
        client = TelegramClient(session_path, proxy=await get_proxy_settings())
    if platform == 1:  # iOS
        api = API.TelegramIOS.Generate(unique_id=account.phone)
        session_path = account.session_path.replace('.session', '-ios.session')
        client = TelegramClient(session_path, api=api, proxy=await get_proxy_settings())
    elif platform == 2:  # Android
        api = API.TelegramAndroid.Generate(unique_id=account.phone)
        session_path = account.session_path.replace('.session', '-android.session')
        client = TelegramClient(session_path, api=api, proxy=await get_proxy_settings())
    elif platform == 3:  # AndroidX
        api = API.TelegramAndroidX.Generate(unique_id=account.phone)
        session_path = account.session_path.replace('.session', '-androidx.session')
        client = TelegramClient(session_path, api=api, proxy=await get_proxy_settings())
        # API_ID = 559815
        # API_HASH = 'fd121358f59d764c57c55871aa0807ca'
        # client = TelegramClient(session_path, proxy=await get_proxy_settings(), api_id=API_ID, api_hash=API_HASH, device_model='Samsung Galaxy S24 Ultra', system_version='SDK 31', app_version='0.26.7.1706-arm64-v8a', system_lang_code='en', lang_code='en')

    # print(f'session_path: {session_path}')
    if client:
        try:
            await client.connect()
            print("授权状态：", await client.is_user_authorized())
            if await client.is_user_authorized():  # 已授权
                print(f'{account.phone} 登录成功')
            else:
                return None
        except (errors.AuthKeyUnregisteredError, errors.UserDeactivatedError, errors.UserDeactivatedBanError) as e:
            print(f'账号：{account.phone} 连接失败: {e}')
            account.status = 3  # 封禁
            await sync_to_async(account.save)()
            return None
        except Exception as e:
            print(f'账号：{account.phone} 连接失败: {e}')
            return None

    return client

def get_new_telegram_client(account):
    api = API.TelegramIOS.Generate(unique_id=account.phone)
    print(f'Account: {account.phone} with session: {account.session_path}')
    client = TelegramClient(account.session_path, api=api, proxy=(socks.SOCKS5, '127.0.0.1', 7890, True))
    return client

async def login_telegram_account(account, platform=0):
    client = await get_telegram_client(account, platform)
    result = False
    client2 = None
    if client:
        account.last_op = 2
        account.last_op_time = timezone.now()
        try:
            if await client.is_user_authorized():
                account.status = 1  # 已登录
                me = await client.get_me()
                account.name = utils.get_display_name(me)
                account.username = me.username
                account.current_session = platform
                account.user_id = me.id
                account.access_hash = me.access_hash
                if platform not in account.logged_in_sessions:
                    account.logged_in_sessions.append(platform)
                await sync_to_async(account.save)()

                await client.PrintSessions()
                result = True
            else:
                if platform == 0:
                    account.status = 3  # 封禁
                    await sync_to_async(account.save)()
                    result = False
                else:
                    # 其它平台，先判断是否已经登录过
                    print(f'开始登录平台 {platform}')

                    await client.disconnect()
                    try:
                        client2 = await get_telegram_client(account, 0)
                        # We can safely authorize the new client with a different API.
                        client = None
                        session_path = None
                        if platform == 1:  # iOS
                            api = API.TelegramIOS.Generate(unique_id=account.phone)
                            session_path = account.session_path.replace('.session', '-ios.session')
                            client = await client2.QRLoginToNewClient(session_path, api=api, proxy=await get_proxy_settings())
                        elif platform == 2:  # Android
                            api = API.TelegramAndroid.Generate(unique_id=account.phone)
                            session_path = account.session_path.replace('.session', '-android.session')
                            client = await client2.QRLoginToNewClient(session_path, api=api, proxy=await get_proxy_settings())
                        elif platform == 3:  # AndroidX
                            api = API.TelegramAndroidX.Generate(unique_id=account.phone)
                            session_path = account.session_path.replace('.session', '-androidx.session')
                            client = await client2.QRLoginToNewClient(session_path, api=api, proxy=await get_proxy_settings())

                        # new_api = API.TelegramAndroid.Generate(unique_id="new.session")
                        # client = await client2.QRLoginToNewClient(session="new.session", api=new_api)
                        await client.connect()
                        if await client.is_user_authorized():
                            # await client.PrintSessions()

                            print(f'{account.phone} 登录成功')
                            account.status = 1  # 已登录

                            account.current_session = platform
                            if platform not in account.logged_in_sessions:
                                account.logged_in_sessions.append(platform)
                            await sync_to_async(account.save)()

                            await asyncio.sleep(random.randrange(5, 10))
                            result = True
                        else:
                            account.status = 3  # 封禁
                            await sync_to_async(account.save)()
                            result = False
                    except errors.PhoneNumberBannedError:
                        account.status = 3  # 封禁
                        await sync_to_async(account.save)()
                        result = False
                    except Exception as e:
                        print(f'登录错误: {e}')
                        account.status = 3  # 封禁
                        await sync_to_async(account.save)()
                        result = False

                    # 开始登录
                    # 用PC session 去接码
                    # try:
                    #     phone = account.phone
                    #     if not phone.startswith('+'):
                    #         phone = f'+{phone}'
                    #     await asyncio.sleep(random.randrange(6, 10))
                    #     print(f'发送验证码到手机号: {phone}')
                    #     code_result = await client.send_code_request(phone)
                    #
                    #     # PC session to fetch code
                    #     print(f'账号：{account.phone} 开始获取验证码')
                    #     await asyncio.sleep(2)
                    #     # code = await read_login_code(account)
                    #     client2 = await get_telegram_client(account, 0)
                    #     if client2:
                    #         try:
                    #             if await client2.is_user_authorized():
                    #                 dialogs = await client2.get_dialogs()
                    #                 now = datetime.now(pytz.utc)
                    #                 i = 0
                    #                 for dialog in dialogs:
                    #                     i += 1
                    #                     if i >= 10:
                    #                         break
                    #
                    #                     entity = dialog.entity
                    #                     if isinstance(entity, types.User) and entity.first_name == "Telegram":
                    #                         # if isinstance(entity, types.User):
                    #                         #     print(f'entity: {entity.stringify()}')
                    #                         last_message = dialog.message.message if dialog.message else None
                    #                         last_date = dialog.message.date if dialog.message else None
                    #                         # print(f'last_date: {last_date.strftime("%Y-%m-%d %H:%M:%S")}')
                    #                         # print(f'now: {now.strftime("%Y-%m-%d %H:%M:%S")}')
                    #
                    #                         if last_message and last_message.startswith(
                    #                                 "Login code: ") and now - last_date <= timedelta(minutes=2):
                    #                             code = last_message.split(": ")[1][:5]  # 提取5位数字验证码
                    #
                    #                             if code:
                    #                                 print(f'账号：{account.phone} 获取到验证码：{code} ，开始登录')
                    #                                 await asynt client.sign_in(code=code)
                    #                     #
                    #                     #                                 if await client.is_user_authorized():
                    #                     #                                     print(f'{utils.get_display_name(me)} 登录成功')
                    #                     #                                     acccio.sleep(random.randrange(10, 20))
                    #                                 me = awaiount.status = 1  # 已登录
                    #
                    #                                     account.current_session = platform
                    #                                     if platform not in account.logged_in_sessions:
                    #                                         account.logged_in_sessions.append(platform)
                    #                                     await sync_to_async(account.save)()
                    #
                    #                                     await asyncio.sleep(random.randrange(8, 15))
                    #                                     # 发送消息
                    #                                     # await client.send_message('SpamBot', '/start')
                    #                                     # await asyncio.sleep(random.randrange(5, 10))
                    #                                     result = True
                    #                                     break
                    #                                 pass
                    #
                    #             else:
                    #                 account.status = 3  # 封禁
                    #                 await sync_to_async(account.save)()
                    #         except Exception as e:
                    #             print(f'账号：{account.phone} 登录异常：{e}')
                    #             account.status = 4  # 未知
                    #             await sync_to_async(account.save)()
                    #
                    # except errors.PhoneNumberBannedError:
                    #     account.status = 3  # 封禁
                    #     await sync_to_async(account.save)()
                    #     result = False
                    # except Exception as e:
                    #     print(f'登录错误: {e}')
                    #     account.status = 3  # 封禁
                    #     await sync_to_async(account.save)()
                    #     result = False


        except Exception as e:
            traceback.print_exc()
            print(f'账号：{account.phone} 登录异常：{e}')
            account.status = 4  # 未知
            await sync_to_async(account.save)()
            result = False
        finally:
            await client.disconnect()
            if client2:
                await asyncio.sleep(random.randrange(5, 10))
                await client2.disconnect()

    return result

async def do_telegram_account(account, op_code, operation, *op_params):
    client = await get_telegram_client(account, account.current_session)
    result = False
    if client:
        account.last_op = op_code
        account.last_op_time = timezone.now()
        try:
            if await client.is_user_authorized():
                account.status = 1  # 已登录
                await sync_to_async(account.save)()
                # 登录成功后，执行传递的操作
                result = await operation(client, *op_params)
            else:
                account.status = 2  # 未登录
                await sync_to_async(account.save)()
                result = False
        except errors.FloodWaitError:
            account.status = 3  # 封禁
            await sync_to_async(account.save)()
            result = False
        except Exception as e:
            account.status = 4  # 未知
            await sync_to_async(account.save)()
            print(f'操作失败：{e}')
            result = False
        finally:
            try:
                await client.disconnect()
            except Exception as e:
                print(f'disconnect failed: {e}')
    return result

async def op_validate_group(client: 'TelegramClient', group_name):
    try:
        result = await client.get_input_entity(group_name)
        if not isinstance(result, InputPeerChannel):
            print(f'{group_name} is not a channel')
            return False

        return True
    except Exception as e:
        print(f'get_input_entity failed：{e}')
        return False

async def op_validate_user(client: 'TelegramClient', username):
    try:
        result = await client.get_input_entity(username)
        if not isinstance(result, InputPeerUser):
            print(f'{username} is not a user')
            return False

        return True
    except Exception as e:
        print(f'get_input_entity failed：{e}')
        return False


async def get_channel_entity(account, group_name):
    client = await get_telegram_client(account, account.current_session)
    entity = None
    is_channel = None
    participants_count = 0
    if client:
        try:
            if await client.is_user_authorized():
                try:
                    if "https://t.me/" in group_name:
                        # 从邀请链接中提取Hash部分
                        invite_hash = group_name.split('/')[-1].split('+')[-1]
                        print(invite_hash)
                        # 解析邀请链接并获取群组信息
                        chat_invite = await client(CheckChatInviteRequest(invite_hash))
                        # 私密群组的ID
                        if chat_invite.chat:
                            group_id = chat_invite.chat.id
                            print(f'Group ID: {group_id}')
                        else:
                            print('Invalid or expired invite link')
                            # 获取群组实体
                        entity = await client.get_entity(group_id)
                        is_channel = True
                    else:
                        result = await client.get_entity(group_name)
                        if isinstance(result, types.Channel):
                            entity = result
                            is_channel = True

                            full_channel = await client(functions.channels.GetFullChannelRequest(
                                types.InputChannel(channel_id=entity.id, access_hash=entity.access_hash)))
                            channel_info = full_channel.full_chat

                            participants_count = channel_info.participants_count
                        else:
                            print(f'{group_name} is not a group')
                            is_channel = False

                except Exception as e:
                    traceback.print_exc()
                    print(f'get_input_entity failed: {e}')
            else:
                account.status = 3  # 封禁
                await sync_to_async(account.save)()

        except errors.FloodWaitError:
            account.status = 3  # 封禁
            await sync_to_async(account.save)()
        except Exception as e:
            account.status = 4  # 未知
            await sync_to_async(account.save)()
        finally:
            await client.disconnect()

    return is_channel, entity, participants_count

async def get_channel_participants_count(account, input_channel: types.InputChannel):
    client = await get_telegram_client(account, account.current_session)
    participants_count = 0
    if client:
        try:
            if await client.is_user_authorized():
                try:
                    full_channel = await client(functions.channels.GetFullChannelRequest(input_channel))
                    channel_info = full_channel.full_chat
                    participants_count = channel_info.participants_count
                except Exception as e:
                    traceback.print_exc()
                    print(f'GetFullChannelRequest failed: {e}')
            else:
                account.status = 3  # 封禁
                await sync_to_async(account.save)()

        except errors.FloodWaitError:
            account.status = 3  # 封禁
            await sync_to_async(account.save)()
        except Exception as e:
            account.status = 4  # 未知
            await sync_to_async(account.save)()
        finally:
            await client.disconnect()

    return participants_count

async def op_fetch_group_info(client: 'TelegramClient', group):
    try:
        if group.group_id:
            if "https://t.me/" in group.group_id:
                # 从邀请链接中提取Hash部分
                invite_hash = group.group_id.split('/')[-1].split('+')[-1]
                # 解析邀请链接并获取群组信息
                chat_invite = await client(CheckChatInviteRequest(invite_hash))
                try:
                    # 私密群组的ID
                    if chat_invite:
                        group_id = chat_invite.chat.id
                    else:
                        print('Invalid or expired invite link')
                except Exception as e:
                        chat_invite = await client(CheckChatInviteRequest(invite_hash))
                        group_id = chat_invite.chat.id

                # 获取群组实体
                entity = await client.get_entity(group_id)

            else:
                entity = await client.get_input_entity(group.group_id)
        elif group.gid:
            entity = types.InputChannel(channel_id=group.gid, access_hash=group.access_hash)
        else:
            return False

        ty = helpers._entity_type(entity)
        if ty == helpers._EntityType.CHANNEL:

            full_channel = await client(functions.channels.GetFullChannelRequest(entity))
            channel_info = full_channel.full_chat

            if not channel_info.can_view_participants:
                print(f'{group.group_id} 是频道')
                return False

            print(f'{group.group_id} 是群组')
            channel = full_channel.chats[0]
            group.group_title = channel.title
            group.participant_count = channel_info.participants_count
            group.participants_hidden = channel_info.participants_hidden
            group.online_count = channel_info.online_count
            group.gip = channel.id
            group.access_hash = channel.access_hash
            group.group_id = channel.username

            if not isinstance(channel.photo, types.ChatPhotoEmpty):
                photo = await client.download_profile_photo(channel, file=bytes, download_big=False)
                if photo:
                    # Use settings.MEDIA_ROOT to construct the file path for saving
                    file_path = os.path.join(settings.MEDIA_ROOT, 'channel_avatars', f'{channel.id}.jpg')
                    os.makedirs(os.path.dirname(file_path), exist_ok=True)
                    with open(file_path, 'wb') as f:
                        f.write(photo)

                    # Use settings.MEDIA_URL to create a URL for the saved file
                    file_url = posixpath.join(settings.MEDIA_URL, 'channel_avatars', f'{channel.id}.jpg')

                    # Assuming 'group' is a TGGroup instance that you're updating
                    group.photo = file_url
                    print(f'Avatar saved to {file_url}')
                else:
                    print(f'No avatar found for this channel: {group.group_id}')
            else:
                print(f'This channel: {group.group_id} does not have a photo.')
        # elif ty == helpers._EntityType.CHAT:
        #     print(f'{group.group_id} is a chat')
        #     full = await client(functions.messages.GetFullChatRequest(entity.chat_id))
        #     chat_info = full.full_chat
        #     chat = full.chats[0]
        #     group.group_title = chat.title
        #     if not isinstance(
        #             full.full_chat.participants, types.ChatParticipants):
        #         # ChatParticipantsForbidden won't have ``.participants``
        #         group.participant_count.total = 0
        #     else:
        #         group.participant_count = len(chat_info.participants.participants)
        else:
            print(f'{group.group_id} is not a CHANNEL type, not supported')
            return False

        return True
    except Exception as e:
        print(f'op_fetch_group_info failed：{e}')
        return False


async def collect_members_async(account, group):
    client = await get_telegram_client(account, account.current_session)
    result = False
    if client:
        try:
            if await client.is_user_authorized():
                account.status = 1  # 已登录
                await sync_to_async(account.save)()

                try:
                    full_group = await client(functions.channels.GetFullChannelRequest(group.group_id))

                    # 获取成员列表
                    members = await client.get_participants(full_group.full_chat.id, aggressive=True)

                    usernames = []
                    one_month_ago = datetime.now(pytz.utc) - timedelta(days=30)

                    for member in members:
                        if not member.deleted and member.username and isinstance(member.status,
                                                             (types.UserStatusOffline, types.UserStatusRecently,
                                                              types.UserStatusOnline)):
                            if isinstance(member.status,
                                          types.UserStatusOffline) and member.status.was_online < one_month_ago:
                                continue
                            usernames.append(member.username)

                    # 生成文件
                    file_name = f"{group.group_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                    temp_dir = tempfile.gettempdir()
                    file_path = os.path.join(temp_dir, file_name)

                    with open(file_path, 'w', encoding='utf-8') as file:
                        for username in usernames:
                            file.write(f"{username}\n")

                    print(f'共收集到活跃用户数：{len(usernames)}')
                    # print(f"文件生成成功，路径为：{file_path}")

                    # 保存文件路径到数据库
                    # group.member_list_file = file_path
                    # group.save()

                    result = file_path

                except Exception as e:
                    print(f'{e}')

            else:
                account.status = 3  # 封禁
                await sync_to_async(account.save)()
                result = False
        except errors.FloodWaitError:
            account.status = 3  # 封禁
            await sync_to_async(account.save)()
            result = False
        except Exception as e:
            print(f'账号：{account.phone} 登录异常：{e}')
            account.status = 4  # 未知
            await sync_to_async(account.save)()
            result = False
        finally:
            await client.disconnect()

    return result

async def load_chats(account):
    client = await get_telegram_client(account, account.current_session)
    result = False
    if client:

        try:
            if await client.is_user_authorized():
                account.status = 1  # 已登录

                dialogs = await client.get_dialogs()
                i = 0
                for dialog in dialogs:
                    i += 1
                    if i >= 10:
                        break

                    entity = dialog.entity
                    if isinstance(entity, types.User):
                        first_name = entity.first_name or ''
                        last_name = entity.last_name or ''
                        name = (first_name + ' ' + last_name).strip()
                        if not name:
                            name = "Unknown"

                    elif isinstance(entity, types.Chat):
                        print(f'{entity.title} is a Chat')
                        name = entity.title
                        # await self.display_chat_members(entity)
                    elif isinstance(entity, types.Channel):
                        print(f'{entity.title} is a Channel with ID: {entity.id}')
                        name = entity.title
                        # await self.display_chat_members(entity)
                    else:
                        name = "Unknown"

                    last_message = dialog.message.message if dialog.message else "No messages yet"
                    last_date = dialog.message.date.strftime("%Y-%m-%d %H:%M:%S") if dialog.message else "Unknown date"

                    # 只展示前面100个字符，后面省略
                    if last_message:
                        last_message_short = (last_message[:100] + '...') if len(last_message) > 100 else last_message
                    else:
                        last_message_short = "No messages yet"

                    chat_info = f"{name}\n{last_message_short}\n{last_date}\n-----------------------\n\n"
                    print(chat_info)

                result = True
            else:
                account.status = 3  # 封禁
                await sync_to_async(account.save)()
                result = False
        except errors.FloodWaitError:
            account.status = 3  # 封禁
            await sync_to_async(account.save)()
            result = False
        except Exception as e:
            print(f'账号：{account.phone} 登录异常：{e}')
            account.status = 4  # 未知
            await sync_to_async(account.save)()
            result = False
        finally:
            await client.disconnect()

    return result

async def read_login_code(account):
    client = await get_telegram_client(account, 0)
    result = False
    if client:

        try:
            if await client.is_user_authorized():
                account.status = 1  # 已登录

                for _ in range(3):  # 最多尝试3次
                    dialogs = await client.get_dialogs()
                    now = datetime.now(pytz.utc)
                    i = 0
                    for dialog in dialogs:
                        i += 1
                        if i >= 10:
                            break

                        entity = dialog.entity
                        if isinstance(entity, types.User) and entity.first_name == "Telegram":
                        # if isinstance(entity, types.User):
                        #     print(f'entity: {entity.stringify()}')
                            last_message = dialog.message.message if dialog.message else None
                            last_date = dialog.message.date if dialog.message else None
                            print(f'last_date: {last_date.strftime("%Y-%m-%d %H:%M:%S")}')
                            print(f'now: {now.strftime("%Y-%m-%d %H:%M:%S")}')

                            print(f'last_message: {(last_message[:100] + "...") if len(last_message) > 100 else last_message}')
                            if last_message and last_message.startswith(
                                    "Login code: ") and now - last_date <= timedelta(minutes=2):
                                code = last_message.split(": ")[1][:5]  # 提取5位数字验证码
                                await asyncio.sleep(3)
                                return code

                    await asyncio.sleep(1)  # 等待1秒再重试

            else:
                account.status = 3  # 封禁
                await sync_to_async(account.save)()
                result = False
        except errors.FloodWaitError:
            account.status = 3  # 封禁
            await sync_to_async(account.save)()
            result = False
        except Exception as e:
            print(f'账号：{account.phone} 登录异常：{e}')
            account.status = 4  # 未知
            await sync_to_async(account.save)()
            result = False
        finally:
            await client.disconnect()
            pass

    return result


class TGAccountAPI:
    def __init__(self):
        self.base_url = "http://43.153.109.145:7666"

    def save_account_data(self, username, account_info, allow_invite, remark=''):
        url = f"{self.base_url}/accountData/save"
        payload = {
            "account": account_info,
            "uniqueString": username,
            "typeId": '21111',
            "remark": remark,
            "uploader": 'Hood',
            "allowInvite": allow_invite
        }
        headers = {
            'Content-Type': 'application/json'
        }
        response = requests.post(url, json=payload, headers=headers)
        return response.json() if response else {}

    def get_account_info(self, username):
        url = f"{self.base_url}/accountData/getAccountInfo"
        payload = {
            "typeId": '21111',
            "uniqueString": username
        }
        headers = {
            'Content-Type': 'application/json'
        }
        response = requests.post(url, json=payload, headers=headers)
        return response.json() if response else {}

def clean_group_id(group_id):
    group_id = group_id.strip()
    if group_id.startswith('http://') or group_id.startswith('https://'):
        group_id = group_id.split('/')[-1]
    return group_id

async def op_create_public_group(client: 'TelegramClient', title, desc=''):
    try:
        updates = await client(
            functions.channels.CreateChannelRequest(title=title, about=desc, megagroup=True))
        channel = updates.chats[0]

        return channel.id, channel.access_hash
    except Exception as e:
        print(f'CreateChannelRequest failed：{e}')
        return None, None

async def op_check_username_availability(client: 'TelegramClient', channel, username):
    try:
        is_available = await client(functions.channels.CheckUsernameRequest(
            channel=channel,
            username=username
        ))
        return is_available
    except Exception as e:
        print(f'CheckUsernameRequest failed：{e}')
        return False

async def update_group_photo(client: 'TelegramClient', entity, photo):
    # Upload the photo
    file = await client.upload_file(photo)
    input_photo = types.InputChatUploadedPhoto(file=file)
    await client(functions.channels.EditPhotoRequest(
        channel=entity,
        photo=input_photo
    ))
async def op_edit_group(client: 'TelegramClient', group, title, about, photo, admins, ban_send_messages, username):
    if not group:
        return False
    channel = types.InputChannel(channel_id=group.gid, access_hash=group.access_hash)
    peer_channel = types.PeerChannel(channel_id=group.gid)
    try:
        if title:
            await client(functions.channels.EditTitleRequest(
                channel=channel,
                title=title
            ))
        if about:
            pass
        if photo:
            # photo_data = BytesIO(photo.read())
            # photo_data = f'{settings.MEDIA_ROOT}/1bc298d072e34295b1ffb811f0dd7253.jpg'
            # Save the resized image to the local file system
            try:
                file_path = os.path.join(settings.MEDIA_ROOT, 'channel_avatars', f'{channel.channel_id}.jpg')
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                with open(file_path, 'wb') as f:
                    for chunk in photo.chunks():
                        f.write(chunk)

                await update_group_photo(client, channel, file_path)

                # Use settings.MEDIA_URL to create a URL for the saved file
                file_url = posixpath.join(settings.MEDIA_URL, 'channel_avatars', f'{channel.channel_id}.jpg')
                group.photo = file_url
            except Exception as e:
                print(f'头像更新错误：{e}')

        if admins:
            for admin in admins:
                # Get the user entity
                user = await client.get_entity(admin.user_id or admin.username)
                input_user = types.InputUser(user_id=user.id, access_hash=user.access_hash)

                # Check if the user is a member of the channel
                is_member = False
                async for participant in client.iter_participants(peer_channel,
                                                                  filter=types.ChannelParticipantsSearch(user.username)):
                    if participant.id == user.id:
                        is_member = True
                        break

                if not is_member:
                    # Invite the user to the channel if not already a member
                    await client(functions.channels.InviteToChannelRequest(
                        channel=channel,
                        users=[input_user]
                    ))

                await client.edit_admin(peer_channel, user, is_admin=True, change_info=True, \
                                        post_messages=True, edit_messages=True, delete_messages=True, \
                                        invite_users=True, add_admins=True, ban_users=True, pin_messages=True)
            pass
        if ban_send_messages:
            # can invite members
            await client.edit_permissions(peer_channel, send_messages=False, send_gifs=False,\
                                          send_games=False, send_stickers=False, send_media=False, \
                                          send_polls=False, send_inline=False, pin_messages=False, change_info=False)

        if username:
            await client(functions.channels.UpdateUsernameRequest(
                channel=channel,
                username=username
            ))
    except Exception as e:
        print(f'op_edit_group failed：{e}')
        return False
    return True