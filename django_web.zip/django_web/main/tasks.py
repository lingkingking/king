import json
import random
from telethon.tl.functions.messages import CheckChatInviteRequest
from telethon.tl.types import UserStatusOnline, UserStatusOffline, UserStatusRecently
from typing import List, Union
from telethon.tl.functions.contacts import ResolveUsernameRequest
from celery import shared_task, current_app, current_task
from opentele.tl import TelegramClient
from opentele.api import API, UseCurrentSession
from telethon import errors
from datetime import datetime, timedelta
from .models import Account, TaskStatus, TGGroup, TGGroupCollect , Tguser
from .utils import get_telegram_client, login_telegram_account, get_new_telegram_client, do_telegram_account, \
    load_chats, op_validate_user, get_channel_entity, get_channel_participants_count
from asgiref.sync import async_to_sync, sync_to_async
from concurrent.futures import ThreadPoolExecutor, as_completed
from django.utils import timezone
from telethon.tl.functions.contacts import ImportContactsRequest
import asyncio
from telethon.tl.types import InputPeerChannel, InputPeerUser, InputUser, User
from telethon.tl import types, functions
from telethon import events, utils
import os
import tempfile
from .utils import TGAccountAPI
import re
import traceback
import pytz
import openpyxl
from openpyxl.styles import Font
import zipfile
from .settings import get_setting_value
from .tg_client import Telegram_Thread
from telethon.tl.functions.messages import AddChatUserRequest
from telethon.tl.types import InputPhoneContact
from telethon.tl.functions.channels import GetParticipantsRequest
from telethon.tl.types import ChannelParticipantsRecent
from telethon.errors import UserPrivacyRestrictedError, UserNotMutualContactError

@shared_task
def batch_login(task_id, account_ids, platform=0):
    task = TaskStatus.objects.get(task_id=task_id)
    task.status = 2
    task.save()
    def login_account(account_id, platform2):
        account = Account.objects.get(id=account_id)
        account.last_op = 3
        account.last_op_time = timezone.now()
        is_logged_in = async_to_sync(login_telegram_account)(account, platform2)
        return account.phone, is_logged_in

    # 获取 CPU 核数
    cpu_count = os.cpu_count()
    # 根据 CPU 核数设置线程池大小
    max_workers = cpu_count * 2  # 这里可以根据需求调整乘数
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(login_account, account_id, platform): account_id for account_id in account_ids}
        for future in as_completed(futures):
            account_id = futures[future]
            print(f'future: {future}')
            try:
                phone, is_logged_in = future.result()
                print(f'账号: {phone} 是否登录: {is_logged_in}')
            except Exception as exc:
                print(f'Account {account_id} generated an exception: {exc}')

    task.status = 3
    task.end_time = timezone.now()
    task.save()

@shared_task
def load_recent_chats(task_id, account_ids):
    task = TaskStatus.objects.get(task_id=task_id)
    task.status = 2
    task.save()

    for account_id in account_ids:
        account = Account.objects.get(id=account_id)
        async_to_sync(load_chats)(account)
        pass

    task.status = 3
    task.end_time = timezone.now()
    task.save()

async def op_join_group(client, group_name):
    try:
        # result = await client.join_channel(group_name)
        # print(f'op_join_group: \n{result.stringify()}')
        # 解析群组用户名
        result = await client(ResolveUsernameRequest(group_name))
        # 使用群组的 ID 加入群组
        await client(JoinChannelRequest(result.chats[0].id))
        print("成功加入群组")
        return True
    except Exception as e:
        print(f'op_join_group failed：{e}')
        return False

def join_group(account_id, group_name):
    account = Account.objects.get(id=account_id)

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    client = get_new_telegram_client(account)
    result = (account.phone, False)

    try:

        loop.run_until_complete(client.connect())
        if loop.run_until_complete(client.is_user_authorized()):
            account.last_op = 3
            account.last_op_time = timezone.now()
            res = loop.run_until_complete(client.join_channel(group_name))
            print(f'join_channel:\n{res.stringify()}')
            account.save()
            result = (account.phone, True)
        else:
            account.status = 2  # 未登录
            account.save()

    except Exception as e:
        print(f'账号：{account.phone} 入群失败：{e}')
        account.save()
    finally:
        loop.run_until_complete(client.disconnect())
        return result


@shared_task
def batch_join_group(task_id, account_ids, group_name):
    task = TaskStatus.objects.get(task_id=task_id)
    task.status = 2
    task.save()

    def do_join_group(account_id, group_name):
        account = Account.objects.get(id=account_id)
        result = async_to_sync(do_telegram_account)(account, 3, op_join_group, group_name)
        return account.phone, result


    # def join_group(account_id, group_name):
    #     account = Account.objects.get(id=account_id)
    #     client = async_to_sync(get_telegram_client)(account)
    #     if client:
    #         account.last_op = 3
    #         account.last_op_time = timezone.now()
    #         try:
    #             # async_to_sync(client.join_channel, force_new_loop=True)(group_name)
    #             # client.loop.run_until_complete(client.join_channel(group_name))
    #             # event_loop_thread.run_coroutine(client.join_channel(group_name)).result()
    #
    #             # 创建一个新的事件循环，并在该事件循环中运行任务
    #             loop = asyncio.new_event_loop()
    #             asyncio.set_event_loop(loop)
    #             loop.run_until_complete(client.join_channel(group_name))
    #             loop.close()
    #
    #             account.save()
    #             return account.phone, True
    #         except errors.FloodWaitError:
    #             account.status = 3  # 封禁
    #             account.save()
    #             return account.phone, False
    #         except Exception as e:
    #             print(f'账号：{account.phone} 入群失败：{e}')
    #             account.save()
    #             return account.phone, False
    #     else:
    #         return account.phone, False

    # 获取 CPU 核数
    cpu_count = os.cpu_count()
    # 根据 CPU 核数设置线程池大小
    max_workers = cpu_count * 2  # 这里可以根据需求调整乘数
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(do_join_group, account_id, group_name): account_id for account_id in account_ids}
        for future in as_completed(futures):
            account_id = futures[future]
            try:
                phone, is_joined = future.result()
                print(f'账号: {phone} 入群结果: {is_joined}')
            except Exception as exc:
                traceback.print_exc()
                print(f'账号 {account_id} 出现异常: {exc}')

    task.status = 3
    task.end_time = timezone.now()
    task.save()

async def validate_user(client, user):
    try:
        result = await client(ResolveUsernameRequest(user))
        user_entity = result.users[0]
        # user_entity = await client.get_entity(user)
        if not isinstance(user_entity, User):
            print(f'{user} 不是用户')
            return None
        return user_entity
    except UserNotMutualContactError:
        print(f"User {user} 用户不是互相联系的联系人.")
        return None
    except UserPrivacyRestrictedError:
        print(f"User {user} 用户有隐私限制，不能被添加到群组.")
        return None
    except Exception as e:
        print(f'get_entity failed：{e}')
        return None

async def invite_users_to_channel(client, group_name, batch_users: List[Union[types.User, types.InputUser]], me, map):
    count = 0
    invited_users = []
    is_continue = True
    invite_result = {}
    for usr in batch_users:
        if isinstance(usr, types.User):
            invite_result[usr.id] = {"account": me.phone, "invite_ok": False, 'missing': False, 'phone': usr.phone,\
                                     'username': usr.username, 'name': utils.get_display_name(usr)}
    try:

        if "https://t.me/" in group_name:
            # 从邀请链接中提取Hash部分
            invite_hash = group_name.split('/')[-1].split('+')[-1]
            print(invite_hash)
            # 解析邀请链接并获取群组信息
            chat_invite = await client(CheckChatInviteRequest(invite_hash))
            # 私密群组的ID
            if chat_invite.chat:
                group_id = chat_invite.chat.id
                print(f'Group ID: {group_id}')
            else:
                print('Invalid or expired invite link')
            for user in batch_users:
                # # 添加陌生号为联系人
                # contacts = [
                #     InputPhoneContact(client_id=0, phone='+' + str(user), first_name=str(user),
                #                       last_name=str(user) + '_fans'),
                # ]
                # # 添加联系人
                # result = await client(ImportContactsRequest(contacts))

                # 获取群组实体
                chat = await client.get_entity(group_id)
                # 获取联系人实体
                contact = await client.get_entity(user.username)
                try:
                    # 邀请联系人加入群组
                    invited_users = await client(AddChatUserRequest(chat_id=chat.id, user_id=contact.id, fwd_limit=0))
                except Exception as e:
                    print(e)
                    continue

                if  invited_users:
                    if invited_users.missing_invitees:
                        if user.id == invited_users.missing_invitees[0].user_id:
                            invite_result[user.id].update({'missing': True})
                            print(f'用户: {user.id}, 有设权限不让拉入群')

                    if invited_users.updates.updates:
                        # 遍历 updates 列表，查找 UpdateNewMessage
                        for update in invited_users.updates.updates:
                            if isinstance(update, types.UpdateNewMessage):
                                # 遍历被邀请的用户 ID
                                if  user.id in update.message.action.users:
                                    count += 1
                                    invite_result[user.id].update({"invite_ok": True})
                                    print(f'账号：{utils.get_display_name(me)}, 邀请用户: {user.id} ({user.username}) 成功')
                else:
                    print("拉群失败。")
                    return 0, False, []

        else:
            if all(isinstance(user, types.User) for user in batch_users):
                batch_users = [types.InputUser(user_id=u.id, access_hash=u.access_hash) for u in batch_users]
            invited_users = await client(functions.channels.InviteToChannelRequest(
                channel=group_name,
                users=batch_users
            ))
        if "https://t.me/" not in group_name:
            # 获取所有的用户信息
            user_dict = {user.id: user for user in invited_users.updates.users}

            # 遍历 updates 列表，查找 UpdateNewChannelMessage
            for update in invited_users.updates.updates:
                if isinstance(update, types.UpdateNewChannelMessage):
                    if isinstance(update.message.action, types.MessageActionChatAddUser):
                        # 遍历被邀请的用户 ID
                        for user_id in update.message.action.users:
                            update_user = user_dict.get(user_id)
                            if update_user:
                                username = update_user.username or ''
                                phone = update_user.phone or ''
                                print(
                                    f'账号：{utils.get_display_name(me)}, 邀请用户: {utils.get_display_name(update_user)} ({username} {phone}) 成功')
                                count += 1
                                invite_result[user_id].update({"invite_ok": True})

            if len(invited_users.missing_invitees) > 0:
                missing_invitees_user_ids = [invitee.user_id for invitee in invited_users.missing_invitees]
                for missing_invitees_user_id in missing_invitees_user_ids:
                    user_info = map[missing_invitees_user_id]
                    if user_info:
                        try:
                            identifier = user_info.get('username') or user_info.get('phone') or user_info.get('user_id')
                            print(f'用户: {identifier}, 有设权限不让拉入群')
                            invite_result[missing_invitees_user_id].update({'missing': True})
                        except:
                            traceback.print_exc()
                            pass

    except errors.PeerFloodError:
        error = "发送过多请求，需要等待"
        print(f'账号：{utils.get_display_name(me)}, {error}')
        account = await sync_to_async(Account.objects.get)(phone=me.phone)
        account.last_error = error
        account.last_error_time = timezone.now()
        await sync_to_async(account.save)()
        is_continue = False
    except errors.FloodWaitError as e:
        error = f"请求频率过高，请等待 {e.seconds} 秒"
        print(f'账号：{utils.get_display_name(me)}, {error}')
        account = await sync_to_async(Account.objects.get)(phone=me.phone)
        account.last_error = error
        account.last_error_time = timezone.now()
        await sync_to_async(account.save)()
        is_continue = False
    # except errors.ChatAdminRequiredError:
    #     print(f"邀请 {user.username} 需要管理员权限")
    except errors.ChannelPrivateError:
        print(f"群组 {group_name} 是私有的，无法邀请")
        is_continue = False
    except errors.UserBannedInChannelError:
        print(f'账号：{utils.get_display_name(me)}, 已被封禁')
        account = await sync_to_async(Account.objects.get)(phone=me.phone)
        account.status = 3  # 封禁
        await sync_to_async(account.save)()
        is_continue = False
    except errors.ChatWriteForbiddenError:
        print(f'群组：{group_name} 权限设置无法拉人')
        is_continue = False
    except errors.RpcCallFailError as e:
        print(f"发生 RPC 错误: {e}")
    except Exception as e:
        traceback.print_exc()
        print(f'账号：{utils.get_display_name(me)}, 尝试邀请用户时发生未知错误：{e}')

    return count, is_continue, invite_result

async def add_contacts_from_file(client: 'TelegramClient', phone_numbers, me):
    print(f'Read contact number from file: {len(phone_numbers)}')
    added_count = 0
    for phone in phone_numbers:
        phone = phone.strip()
        if phone:
            contact = types.InputPhoneContact(client_id=0, phone=phone, first_name='', last_name='')
            try:
                result = await client(functions.contacts.ImportContactsRequest([contact]))
                print(f'ImportContactsRequest result: \n{result.stringify()}')
                added_count += len(result.imported)

                print('.', end='', flush=True)
                await asyncio.sleep(5)
            except errors.PeerFloodError:
                error = "发送过多请求，需要等待"
                print(f'账号：{utils.get_display_name(me)}, {error}')
                account = await sync_to_async(Account.objects.get)(phone=me.phone)
                account.last_error = error
                account.last_error_time = timezone.now()
                await sync_to_async(account.save)()
                return False
            except errors.FloodWaitError as e:
                error = f"请求频率过高，请等待 {e.seconds} 秒"
                print(f'账号：{utils.get_display_name(me)}, {error}')
                account = await sync_to_async(Account.objects.get)(phone=me.phone)
                account.last_error = error
                account.last_error_time = timezone.now()
                await sync_to_async(account.save)()
                return False
            except errors.UserBannedInChannelError:
                print(f'账号：{utils.get_display_name(me)}, 已被封禁')
                account = await sync_to_async(Account.objects.get)(phone=me.phone)
                account.status = 3  # 封禁
                await sync_to_async(account.save)()
                return False
            except Exception as e:
                print(f"Failed to add contacts: {e}")
                break

    print('')
    return added_count

async def op_invite_group(client: 'TelegramClient', group_name, users, interval, task_id, active_only):
    invite_ok_count = 0
    invite_tried = 0
    invite_res = {}
    try:
        me = await client.get_me()
        # print(f'本账号信息：\n{me.stringify()}')
        # if user is not a participant in this group, join first
        try:
            await client.get_permissions(group_name, me)
        except errors.UserNotParticipantError:
            # need to join this group first
            print(f'账号：{utils.get_display_name(me)} 不是群: {group_name} 的成员，开始加入...')
            try:
                await client.join_channel(group_name)
            except Exception as e:
                print(f'账号：{utils.get_display_name(me)} 加入群: {group_name} 失败，原因：{e}')
                return False, invite_tried
            print(f'账号：{utils.get_display_name(me)} 成功加入群: {group_name}')

        print(f'账号：{utils.get_display_name(me)}, 开始尝试邀请用户数: {len(users)}')

        batch_users = []
        batch_users_map = {}

        for user in users:
            # 手动检查任务是否被撤销
            task = await sync_to_async(TaskStatus.objects.get)(task_id=task_id)
            if task.status == 3:
                print(f'任务 {task_id} 被撤销')
                break

            # 判断用户是否是真实用户
            user_entity = await validate_user(client, user)
            if not user_entity:
                await asyncio.sleep(2)
                continue
            days_ago = datetime.now(pytz.utc) - timedelta(days=7)
            # Only invite active user
            if active_only and isinstance(user_entity.status, types.UserStatusOffline) and user_entity.status.was_online < days_ago:
                continue

            await asyncio.sleep(3)

            # if "https://t.me/" not  in group_name:
            #     # 查数据库，该用于是否允许被邀请入群
            #     try:
            #         api = TGAccountAPI()
            #         api_result = api.get_account_info(user)
            #         if api_result and api_result.get('code') == 200 and not api_result.get('data').get('allowInvite', True):
            #             print(f'数据库查到用户：{user} 设置权限不允许拉入群，跳过！')
            #             continue
            #     except:
            #         print(f'查询用户数据库失败')
            #         pass

            batch_users.append(user_entity)
            batch_users_map[user_entity.id] = {'username': user, 'phone': user_entity.phone, 'user_id': user_entity.id, 'access_hash': user_entity.access_hash}

            if len(batch_users) == 5:
                invite_tried += 1
                result, is_continue, invite_result = await invite_users_to_channel(client, group_name, batch_users, me, batch_users_map)
                batch_users = []
                batch_users_map = {}
                invite_ok_count += result
                invite_res.update(invite_result)

                if is_continue is False:
                    break

                await asyncio.sleep(interval)

        # Invite remaining users in batch_users if any
        if batch_users:
            invite_tried += 1
            result, is_continue, invite_result = await invite_users_to_channel(client, group_name, batch_users, me, batch_users_map)
            invite_ok_count += result
            invite_res.update(invite_result)

        print(f'账号：{utils.get_display_name(me)}, 成功邀请用户数: {invite_ok_count}, 共尝试邀请次数：{invite_tried}')

    except Exception as e:
        print(f'op_invite_group failed：{e}')

    return invite_ok_count, invite_tried, invite_res

def create_excel_file(data, group_title, group_name, days):
    # 创建一个工作簿和工作表
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "群组成员"

    # 设置表头
    headers = ['用户ID', '用户名', '手机号', '姓名', '会员用户', '最后在线时间', '所在群', '群组管理员']
    for col_num, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_num, value=header)
        cell.font = Font(bold=True)

    # 插入数据
    for row_num, row_data in enumerate(data, 2):
        for col_num, cell_value in enumerate(row_data, 1):
            ws.cell(row=row_num, column=col_num, value=cell_value)

    # 生成文件
    # 截取 group_title 至多 20 个字符
    truncated_group_title = group_title[:20]
    file_name = f"{truncated_group_title}_{group_name}_{days}天_{len(data)}名_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    temp_dir = tempfile.gettempdir()
    file_path = os.path.join(temp_dir, file_name)

    # 将工作簿保存到临时文件
    wb.save(file_path)
    return file_path

async def extract_groups(client: 'TelegramClient', text: str):
    if not text:
        return []
    usernames = re.findall(r'@([A-Za-z0-9_]{5,})|https://t.me/([A-Za-z0-9_]{5,})', text)
    if not usernames:
        return []
    groups = []
    for uname in usernames:
        uname = uname[0] if uname[0] else uname[1]
        try:
            entity = await client.get_entity(uname)
            if isinstance(entity, types.Channel) and not entity.broadcast:
                groups.append(entity)
        except Exception as e:
            print(f"Failed to get entity for username {uname}: {e}")

    return groups
async def op_collect_members(client: 'TelegramClient', group_ids, collect_data, last_seen, collect_admin, collect_group):
    result = []
    groups = []
    try:
        me = await client.get_me()

        print(f'账号：{utils.get_display_name(me)} 需要采集的群组ID: {list(group_ids)}')

        for group_id in group_ids:
            tg_group = await sync_to_async(TGGroupCollect.objects.get)(pk=group_id)
            group_name = tg_group.group_id
            if not group_name:
                continue

            print(f'账号：{utils.get_display_name(me)} 开始采集群组：{group_name}')
            full_group = await client(functions.channels.GetFullChannelRequest(group_name))

            if not full_group.full_chat.can_view_participants:
                print(f'{group_name} 是频道，无法获取成员')
                continue

            # get admins
            admin_ids = []
            members = []
            channel = full_group.chats[0]

            if full_group.full_chat.participants_hidden:
                print(f'群组：{group_name} 隐藏了成员，尝试暴力拉取成员，干干干...')
                peer_users = set()  # 使用集合来确保唯一性
                it = client.iter_messages(channel, limit=10000)
                async for msg in it:
                    if isinstance(msg.from_id, types.PeerUser):
                        peer_users.add(msg.from_id.user_id)
                        if collect_group:
                            groups.extend(await extract_groups(client, msg.message))

                peer_user_array = [types.PeerUser(user_id=user_id) for user_id in peer_users]
                for peer_user in peer_user_array:
                    user = await client.get_entity(peer_user)
                    members.append(user)
            else:
                if collect_admin:
                    admins = await client.get_participants(full_group.full_chat.id, filter=types.ChannelParticipantsAdmins())
                    admin_ids = [admin.id for admin in admins]

                # 获取成员列表
                members = await client.get_participants(full_group.full_chat.id, aggressive=True)

            if last_seen == 0:
                days = 3
            elif last_seen == 1:
                days = 7
            elif last_seen == 2:
                days = 30
            elif last_seen == 3:
                days = 90
            else:
                continue

            days_ago = datetime.now(pytz.utc) - timedelta(days=days)

            data = []
            print(f'群组：{group_name} 总共成员数: {len(members)}')
            for member in members:
                if member.deleted or member.bot:
                    continue

                # 获取用户bio信息，提取群组
                if collect_group:
                    full = await client(functions.users.GetFullUserRequest(types.InputUser(user_id=member.id, access_hash=member.access_hash)))
                    bio = full.full_user.about
                    groups.extend(await extract_groups(client, bio))

                if not isinstance(member.status,
                           (types.UserStatusOffline,
                            types.UserStatusRecently,
                            types.UserStatusOnline)):
                    continue

                # 过滤收集成员在线时间
                if isinstance(member.status,
                              types.UserStatusOffline) and member.status.was_online < days_ago:
                    continue

                if not collect_admin and member.id in admin_ids:
                    continue

                was_online_str = ""
                if isinstance(member.status,
                              types.UserStatusOffline):
                    was_online_str = member.status.was_online.strftime('%Y-%m-%d %H:%M:%S %Z%z')

                id = member.id
                username = member.username if (collect_data == 0 or collect_data == 2) and member.username else ""
                phone = member.phone if (collect_data == 1 or collect_data == 2) and member.phone else ""
                name = utils.get_display_name(member)
                premium = '是' if member.premium else '否'
                is_admin = '是' if member.id in admin_ids else '否'

                data.append([id, username, phone, name, premium, was_online_str, group_name, is_admin])

            if not data:
                print(f'群组: {group_name} 没有收集到成员')
                continue

            # 使用 run_in_threadpool 异步调用同步的 create_excel_file 函数
            file_path = await sync_to_async(create_excel_file)(data, tg_group.group_title, group_name, days)

            print(f'群组：{group_name} 共收集到活跃用户数：{len(data)}')
            result.append(file_path)
            await asyncio.sleep(random.randrange(5, 9))

        # show collected groups
        if collect_group and groups:
            print(f'账号：{utils.get_display_name(me)} 收集到群组数：{len(groups)}')


    except Exception as e:
        traceback.print_exc()
        print(f'op_collect_members failed：{e}')
        return False, groups

    return result, groups

def is_valid_phone_number(phone_number):
    # 定义一个匹配手机号的正则表达式
    phone_pattern = re.compile(r'^\+?\d{10,15}$')

    # 使用正则表达式进行匹配
    return phone_pattern.match(phone_number) is not None
async def op_invite_group_by_phone(client: 'TelegramClient', group_name, users, interval, task_id, active_only):
    invite_ok_count = 0
    invite_tried = 0
    invite_res = {}
    try:
        me = await client.get_me()
        # print(f'本账号信息：\n{me.stringify()}')
        # if user is not a participant in this group, join first
        try:
            await client.get_permissions(group_name, me)
        except errors.UserNotParticipantError:
            # need to join this group first
            print(f'账号：{utils.get_display_name(me)} 不是群: {group_name} 的成员，开始加入...')
            try:
                await client.join_channel(group_name)
            except Exception as e:
                print(f'账号：{utils.get_display_name(me)} 加入群: {group_name} 失败，原因：{e}')
                return False, invite_tried
            print(f'账号：{utils.get_display_name(me)} 成功加入群: {group_name}')

        print(
            f'账号：{utils.get_display_name(me)}, 开始尝试邀请用户数: {len(users)}')

        batch_users = []
        batch_users_map = {}

        import_contact_failed = 0
        for user in users:
            # 手动检查任务是否被撤销
            task = await sync_to_async(TaskStatus.objects.get)(task_id=task_id)
            if task.status == 3:
                print(f'任务 {task_id} 被撤销')
                break

            # 判断是否为手机号
            if not is_valid_phone_number(user):
                print(f'{user} 不是手机号格式')
                continue

            # 查数据库，该用于是否允许被邀请入群
            try:
                api = TGAccountAPI()
                api_result = api.get_account_info(user)
                if api_result and api_result.get('code') == 200 and not api_result.get('data').get('allowInvite', True):
                    print(f'数据库查到用户：{user} 设置权限不允许拉入群，跳过！')
                    continue
            except:
                traceback.print_exc()
                pass

            # 先导入该用户
            contact = types.InputPhoneContact(client_id=0, phone=user, first_name=user, last_name='')
            try:
                print(f'开始导入手机号: {user} 为联系人')
                result = await client(functions.contacts.ImportContactsRequest([contact]))
                if not result.users:
                    print(f'导入手机号: {user} 为联系人失败！！')
                    import_contact_failed += 1
                    if import_contact_failed > 9:
                        break
                    await asyncio.sleep(2)
                    continue

                print(f'导入手机号: {user} 为联系人成功')
                import_contact_failed = 0
                await asyncio.sleep(2)

                added_user = result.users[0]
                days_ago = datetime.now(pytz.utc) - timedelta(days=7)
                # Only invite active user
                if active_only and isinstance(added_user.status,
                                              types.UserStatusOffline) and added_user.status.was_online < days_ago:
                    continue

                # batch_users.append(result.imported[0].user_id)
                # user_entity = InputPeerUser(added_user.id, added_user.access_hash)
                batch_users.append(added_user)
                batch_users_map[added_user.id] = {'username': added_user.username, 'phone': user, 'user_id': added_user.id,
                                                        'access_hash': added_user.access_hash}

                if len(batch_users) == 3:
                    invite_tried += 1
                    result, is_continue, invite_result = await invite_users_to_channel(client, group_name, batch_users, me, batch_users_map)
                    batch_users = []
                    batch_users_map = {}
                    invite_ok_count += result
                    invite_res.update(invite_result)
                    if is_continue is False:
                        break

                    await asyncio.sleep(interval)

            except errors.PeerFloodError:
                error = "发送过多请求，需要等待"
                print(f'账号：{utils.get_display_name(me)}, {error}')
                account = await sync_to_async(Account.objects.get)(phone=me.phone)
                account.last_error = error
                account.last_error_time = timezone.now()
                await sync_to_async(account.save)()
                break
            except errors.FloodWaitError as e:
                error = f"请求频率过高，请等待 {e.seconds} 秒"
                print(f'账号：{utils.get_display_name(me)}, {error}')
                account = await sync_to_async(Account.objects.get)(phone=me.phone)
                account.last_error = error
                account.last_error_time = timezone.now()
                await sync_to_async(account.save)()
                break
            except errors.UserBannedInChannelError:
                print(f'账号：{utils.get_display_name(me)}, 已被封禁')
                account = await sync_to_async(Account.objects.get)(phone=me.phone)
                account.status = 3  # 封禁
                await sync_to_async(account.save)()
                break
            except Exception as e:
                traceback.print_exc()
                print(f"Failed to add contacts: {e}")
                break

            await asyncio.sleep(1)

        # Invite remaining users in batch_users if any
        if batch_users:
            invite_tried += 1
            result, is_continue, invite_result = await invite_users_to_channel(client, group_name, batch_users, me, batch_users_map)
            invite_ok_count += result
            invite_res.update(invite_result)

        print(
            f'账号：{utils.get_display_name(me)}, 成功邀请用户数: {invite_ok_count}, 共尝试邀请次数：{invite_tried}')

    except Exception as e:
        print(f'op_invite_group failed：{e}')

    return invite_ok_count, invite_tried, invite_res

async def op_invite_group_by_id(client: 'TelegramClient', group_name, users, interval, task_id, active_only):
    invite_ok_count = 0
    invite_tried = 0
    try:
        me = await client.get_me()
        # print(f'本账号信息：\n{me.stringify()}')
        # if user is not a participant in this group, join first
        try:
            await client.get_permissions(group_name, me)
        except errors.UserNotParticipantError:
            # need to join this group first
            print(f'账号：{utils.get_display_name(me)} 不是群: {group_name} 的成员，开始加入...')
            try:
                await client.join_channel(group_name)
            except Exception as e:
                print(f'账号：{utils.get_display_name(me)} 加入群: {group_name} 失败，原因：{e}')
                return False, invite_tried
            print(f'账号：{utils.get_display_name(me)} 成功加入群: {group_name}')

        print(
            f'账号：{utils.get_display_name(me)}, 开始尝试邀请用户数: {len(users)}')

        batch_users = []
        batch_users_map = {}

        for user in users:
            # 手动检查任务是否被撤销
            task = await sync_to_async(TaskStatus.objects.get)(task_id=task_id)
            if task.status == 3:
                print(f'任务 {task_id} 被撤销')
                break

            user = user.strip()
            # 查数据库，该用于是否允许被邀请入群
            try:
                api = TGAccountAPI()
                api_result = api.get_account_info(user)
                if api_result and api_result.get('code') == 200 and not api_result.get('data').get('allowInvite', True):
                    print(f'数据库查到用户：{user} 设置权限不允许拉入群，跳过！')
                    continue
            except:
                traceback.print_exc()
                pass

            try:
                numbers = user.split(',')
                user_id = int(numbers[0])
                user_access_hash = int(numbers[1])
                peer_user = InputPeerUser(user_id, user_access_hash)
            except:
                continue

            batch_users.append(peer_user)
            batch_users_map[peer_user.user_id] = {'username': None, 'phone': None, 'user_id': peer_user.user_id, 'access_hash': peer_user.access_hash}

            if len(batch_users) == 3:
                invite_tried += 1
                result, is_continue, invite_result = await invite_users_to_channel(client, group_name, batch_users, me, batch_users_map)
                batch_users = []
                batch_users_map = {}
                invite_ok_count += result
                if is_continue is False:
                    break

                await asyncio.sleep(interval)

        # Invite remaining users in batch_users if any
        if batch_users:
            invite_tried += 1
            result, is_continue, invite_result = await invite_users_to_channel(client, group_name, batch_users, me, batch_users_map)
            invite_ok_count += result

        print(
            f'账号：{utils.get_display_name(me)}, 成功邀请用户数: {invite_ok_count}, 共尝试邀请次数：{invite_tried}')

    except Exception as e:
        print(f'op_invite_group failed：{e}')

    return invite_ok_count, invite_tried, None

async def op_export_username_by_phone(client: 'TelegramClient', users, export_id, task_id):
    try:
        me = await client.get_me()
        usernames = []
        import_contact_failed = 0
        for user in users:
            # 手动检查任务是否被撤销
            task = await sync_to_async(TaskStatus.objects.get)(task_id=task_id)
            if task.status == 3:
                print(f'任务 {task_id} 被撤销')
                break

            # 判断是否为手机号
            if not is_valid_phone_number(user):
                print(f'{user} 不是手机号格式')
                continue

            try:
                entity = await client.get_entity(user)
                if not entity.deleted and not export_id and entity.username:
                    usernames.append(entity.username)

                if not entity.deleted and export_id:
                    usernames.append(f"{entity.id},{entity.access_hash}")

            except ValueError:
                contact = types.InputPhoneContact(client_id=0, phone=user, first_name=user, last_name='')
                try:
                    print(f'账号：{utils.get_display_name(me)} 开始添加手机号: {user} 为联系人')
                    result = await client(functions.contacts.ImportContactsRequest([contact]))
                    if not result.users:
                        print(f'账号：{utils.get_display_name(me)} 添加手机号: {user} 为联系人失败！！')
                        import_contact_failed += 1
                    else:
                        import_contact_failed = 0
                        print(f'账号：{utils.get_display_name(me)} 添加手机号: {user} 为联系人成功')
                        added_user = result.users[0]
                        if not added_user.deleted and not export_id and added_user.username:
                            usernames.append(added_user.username)

                        if not added_user.deleted and export_id:
                            usernames.append(f"{added_user.id},{added_user.access_hash}")
                except Exception as e:
                    import_contact_failed += 1
                    print(f'账号：{utils.get_display_name(me)} 添加手机号: {user} 为联系人失败: {e}')
                finally:
                    if import_contact_failed > 9:
                        print(f'账号：{utils.get_display_name(me)} 添加手机号连续失败超过9次，退出！')
                        break
                    await asyncio.sleep(random.randrange(5, 9))

        return usernames
    except Exception as e:
        print(f'op_export_username_by_phone failed：{e}')
        return False

@shared_task
def invite_user_list(task_id, account_ids, invitees,max_invitees_per_account):
    task = TaskStatus.objects.get(task_id=task_id)
    task.status = 2
    task.save()

    if not account_ids:
        print("Empty account_ids received.")
        return

        # 平均分配 invitees
    chunk_size = (len(invitees) + len(account_ids) - 1) // len(account_ids)
    if chunk_size > max_invitees_per_account:
            chunk_size = max_invitees_per_account
    invitees_chunks = [invitees[i:i + chunk_size] for i in range(0, len(invitees), chunk_size)]
    # print(invitees_chunks)
    def do_save(account_id,invitees):
        account = Account.objects.get(id=account_id)
        temp_list = asyncio.run(client_task(account,invitees))
        for i in temp_list:
            account = Tguser.objects.filter(username=i["username"]).first()
            if account:
                continue
            print(i)
            if str(i["phone"]) == "None":
                i["phone"] = "空"
            tguser_obj = Tguser.objects.create(username=i["username"], status=i["status"], off_online=i["off_online"],
                                               phone=i["phone"], user_id=i["user_id"], access_hash=i["access_hash"],
                                               type="0")
            tguser_obj.save()

    # 获取 CPU 核数
    cpu_count = os.cpu_count()
    #根据 CPU 核数设置线程池大小
    max_workers = cpu_count * 2  # 这里可以根据需求调整乘数
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {}
        for account_id, chunk in zip(account_ids, invitees_chunks):
            futures[executor.submit(do_save, account_id, chunk)] = account_id
        for future in as_completed(futures):
            account_id = futures[future]
            result = future.result
            print(result)
            try:
               result = future.result
               print(result)

            except Exception as exc:
                print(f'up Account false: {exc}')


async def client_task(account,users_list):
    days_ago = datetime.now(pytz.utc) - timedelta(days=7)
    user_dict_list = []
    client = await get_telegram_client(account, account.current_session)
    # print(client)
    for temp_user_i in users_list:
        tasks = [asyncio.create_task(client(ResolveUsernameRequest(temp_user_i)))]
        done, pending = await asyncio.wait(tasks)
        for task in done:
            try:
                user_dict =task.result().users
            except:
                print("用户存在但受限制")
                user_dict_list.append({'username': temp_user_i,
                                       "status": "",
                                       "off_online": "",
                                       'phone': "",
                                       'user_id': "",
                                       'access_hash': ""})

                continue
            temp_user = user_dict[0]
            # print(temp_user)
            if isinstance(temp_user.status, UserStatusOnline):
                # print(f"User is online. Last seen: {temp_user.status.expires}")
                temp_data = temp_user.status.expires
                temp_status = "online"

            elif isinstance(temp_user.status, UserStatusOffline):
                # print(f"User is offline. Last seen: {temp_user.status.was_online}")
                if temp_user.status.was_online < days_ago:
                    continue
                temp_data = temp_user.status.was_online
                temp_status = "offline"

            elif isinstance(temp_user.status, UserStatusRecently):
                # print("User was recently online.")
                continue

            else:
                # print("User status is unknown.")
                continue
            user_dict_list.append({'username': temp_user.username,
                                   "status": temp_status,
                                   "off_online": temp_data.strftime("%Y-%m-%d %H:%M:%S"),
                                   'phone': temp_user.phone,
                                   'user_id': temp_user.id,
                                   'access_hash': temp_user.access_hash})
    return user_dict_list

@shared_task
def invite_group(task_id, account_ids, group_name, invitees, invite_by=0, max_invitees_per_account=50, interval=30, active_only=True):
    task = TaskStatus.objects.get(task_id=task_id)
    task.status = 2
    task.save()

    def do_invite_to_group(account_id, group_name, users, interval2, task_id, active_only):
        account2 = Account.objects.get(id=account_id)
        print(f'邀请方式：{invite_by}')
        result2 = None
        tried = 0
        invite_result = None
        if invite_by == 0:
            result2, tried, invite_result = async_to_sync(do_telegram_account)(account2, 4, op_invite_group, group_name, users, interval2, task_id, active_only)
        elif invite_by == 1:
            result2, tried, invite_result = async_to_sync(do_telegram_account)(account2, 4, op_invite_group_by_phone, group_name, users, interval2, task_id, active_only)
        elif invite_by == 2:
            result2, tried, invite_result = async_to_sync(do_telegram_account)(account2, 4, op_invite_group_by_id, group_name, users,
                                                     interval2, task_id, active_only)
        return account2.phone, result2, tried, invite_result

    if not account_ids:
        print("Empty account_ids received.")
        return

    # validate group here
    group_name = group_name.strip()
    if not group_name:
        print("Empty group name")
        return
    is_valid_group = False
    channel_entity = None
    participants_count_before = 0
    for account_id in account_ids:
        account = Account.objects.get(id=account_id)
        is_channel, channel_entity, participants_count_before = async_to_sync(get_channel_entity)(account, group_name)
        if is_channel is False:
            # not a group
            print(f'{group_name} 不是一个群组')
            task.status = 3
            task.end_time = timezone.now()
            task.save()
            return
        elif is_channel is True:
            is_valid_group = True
            break

    if not is_valid_group:
        print(f'账号无法验证群组：{group_name} 的合法性')
        return

    print(f'本任务需要拉入的群名为：{group_name}, 拉人前群组成员数：{participants_count_before}')

    # 平均分配 invitees
    chunk_size = (len(invitees) + len(account_ids) - 1) // len(account_ids)
    if chunk_size > max_invitees_per_account:
        chunk_size = max_invitees_per_account
    invitees_chunks = [invitees[i:i + chunk_size] for i in range(0, len(invitees), chunk_size)]
    print(invitees_chunks)

    invite_ok_total = 0
    tried_total = 0
    results_collection = []
    # 获取 CPU 核数
    cpu_count = os.cpu_count()
    # 根据 CPU 核数设置线程池大小
    max_workers = cpu_count * 2  # 这里可以根据需求调整乘数
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {}
        for account_id, chunk in zip(account_ids, invitees_chunks):
            futures[executor.submit(do_invite_to_group, account_id, group_name, chunk, interval, task_id, active_only)] = account_id
        for future in as_completed(futures):
            account_id = futures[future]
            try:
                phone, result, tried, invite_result = future.result()
                count = result

                print(f'账号: {phone} 共成功拉入人数: {count}')
                account = Account.objects.get(id=account_id)
                account.last_invite_ok_count = count
                account.invite_ok_total += count
                invite_ok_total += count
                tried_total += tried
                account.save()

                results_collection.append((phone, count, tried, invite_result))
            except Exception as exc:
                print(f'Account {account_id} generated an exception: {exc}')

        if invite_ok_total > 0:
            # 使用 get_or_create 方法检查 group_id 是否存在
            tg_group, created = TGGroup.objects.get_or_create(group_id=group_name)
            if created:
                # 如果是新创建的记录
                print(f'新建了TG群组: {group_name}')
            else:
                # 如果记录已经存在
                tg_group.save()
                print(f'刷新TG群组: {group_name}')

        print('------------------任务完成--------------------')
        table_data = []
        for phone, ok_count, tried, invite_result in results_collection:
            print(f'账号: {phone}, 成功拉人数: {ok_count}, 共尝试拉人次数: {tried}')
            if invite_result:
                for key, res in invite_result.items():
                    temp_group_name = ''
                    if "https://t.me/" not  in group_name:
                        temp_group_name = 'https://t.me/'
                    table_data.append([phone, res.get('phone', ''), res.get('username', ''), res.get('name', ''),\
                                       f'{temp_group_name}{group_name}', channel_entity.title, \
                                       '是' if res.get('invite_ok', False) else '否', '是' if res.get('missing', False) else '否', \
                                      datetime.now().strftime('%Y-%m-%d %H:%M:%S')])

        participants_count_after = participants_count_before

        for account_id in account_ids:
            account = Account.objects.get(id=account_id)
            print(account)
            if "https://t.me/" in group_name:
                for phone, ok_count, tried, invite_result in results_collection:
                    if account_id == account.phone:
                        participants_count_after = participants_count_before + ok_count
            else:
                    participants_count_after = async_to_sync(get_channel_participants_count)(account, types.InputChannel(channel_id=channel_entity.id, access_hash=channel_entity.access_hash))
            if participants_count_after != 0:
                participants_count_after = 0
                break

        # print(f'本次任务总共成功拉人数：{invite_ok_total}，共尝试拉人次数：{tried_total}，每次尝试拉3个人')
        print(f'群组：{group_name}, 拉人前成员数：{participants_count_before}， 拉人后成员数：{participants_count_after}')
        print(f'本次任务总共成功拉人数：{participants_count_after - participants_count_before}，共尝试拉人次数：{tried_total}，每次尝试拉3个人')

        if table_data:
            if 'https://t.me' in group_name:
                summary_data = [
                    [f'{group_name}', channel_entity.title, invite_ok_total]
                ]
            else:
                summary_data = [
                    [f'https://t.me/{group_name}', channel_entity.title, invite_ok_total]
                ]
            file_path = create_excel_file_invite(table_data, summary_data, channel_entity.title, group_name)
            task.temp_file_path = file_path
            print('请前往【任务记录】下载拉人结果明细')

    task.status = 3
    task.end_time = timezone.now()
    task.save()

async def get_group_members_count(account, group_name):
    # 从邀请链接中提取Hash部分
    invite_hash = group_name.split('/')[-1].split('+')[-1]
    print(invite_hash)
    client = await get_telegram_client(account, account.current_session)
    # 解析邀请链接并获取群组信息
    chat_invite = await client(CheckChatInviteRequest(invite_hash))
    # 私密群组的ID
    if chat_invite.chat:
        group_id = chat_invite.chat.id
        print(f'Group ID: {group_id}')
    else:
        print('Invalid or expired invite link')
    from telethon.tl.types import ChannelParticipantsSearch
    group = await client.get_entity(group_id)
    # 获取群组成员列表
    participants = await client(GetParticipantsRequest(
        channel=group,
        filter=ChannelParticipantsSearch(''),
        offset=0,
        limit=0,
        hash=0
    ))
    # 返回成员数量
    return len(participants.users)

def create_excel_file_invite(data1, data2, group_title, group_name):
    # 创建一个工作簿
    wb = openpyxl.Workbook()

    # 创建第一个工作表
    ws1 = wb.active
    ws1.title = "拉人明细"

    # 设置第一个工作表的表头
    headers1 = ['拉人账号手机号', '手机号码', '用户名', '姓名', '群组链接', '群标题', '是否拉入', '是否禁止拉入', '时间']
    for col_num, header in enumerate(headers1, 1):
        cell = ws1.cell(row=1, column=col_num, value=header)
        cell.font = Font(bold=True)

    # 插入第一个工作表的数据
    for row_num, row_data in enumerate(data1, 2):
        for col_num, cell_value in enumerate(row_data, 1):
            ws1.cell(row=row_num, column=col_num, value=cell_value)

    # 创建第二个工作表
    ws2 = wb.create_sheet(title="总计")

    # 设置第二个工作表的表头
    headers2 = ['群组链接', '群组名称', '拉成功人数']  # 根据第二个数据表的结构设置表头
    for col_num, header in enumerate(headers2, 1):
        cell = ws2.cell(row=1, column=col_num, value=header)
        cell.font = Font(bold=True)

    # 插入第二个工作表的数据
    for row_num, row_data in enumerate(data2, 2):
        for col_num, cell_value in enumerate(row_data, 1):
            ws2.cell(row=row_num, column=col_num, value=cell_value)

    # 生成文件
    # 截取 group_title 至多 20 个字符
    truncated_group_title = group_title[:20]
    if 'https://t.me' in group_name:
        group_name =  group_name.split('/')[-1].split('+')[-1]
    file_name = f"拉群结果_{truncated_group_title}_{group_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    temp_dir = tempfile.gettempdir()
    file_path = os.path.join(temp_dir, file_name)

    # 将工作簿保存到临时文件
    wb.save(file_path)
    return file_path
@shared_task
def export_usernames(scheme, host, task_id, account_ids, invitees, export_id=False, max_users_per_account=50):
    task = TaskStatus.objects.get(task_id=task_id)
    task.status = 2
    task.save()

    def do_export_usernames(account_id, users, task_id):
        account2 = Account.objects.get(id=account_id)
        result2 = async_to_sync(do_telegram_account)(account2, 5, op_export_username_by_phone, users, export_id, task_id)
        return account2.phone, result2

    if not account_ids:
        print("Empty account_ids received.")
        return


    # 平均分配 invitees
    chunk_size = (len(invitees) + len(account_ids) - 1) // len(account_ids)
    if chunk_size > max_users_per_account:
        chunk_size = max_users_per_account
    invitees_chunks = [invitees[i:i + chunk_size] for i in range(0, len(invitees), chunk_size)]

    # 获取 CPU 核数
    cpu_count = os.cpu_count()
    # 根据 CPU 核数设置线程池大小
    max_workers = cpu_count * 2  # 这里可以根据需求调整乘数
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {}
        usernames = []
        for account_id, chunk in zip(account_ids, invitees_chunks):
            futures[executor.submit(do_export_usernames, account_id, chunk, task_id)] = account_id
        for future in as_completed(futures):
            account_id = futures[future]
            try:
                phone, result = future.result()
                if result:
                    usernames.extend(result)
            except Exception as exc:
                print(f'Account {account_id} generated an exception: {exc}')

        print(f'本次任务总共导出用户名数：{len(usernames)}')

        # 创建临时文件
        with tempfile.NamedTemporaryFile(delete=False, mode='w', encoding='utf-8', suffix='.txt') as tmp_file:
            for username in usernames:
                tmp_file.write(str(username) + '\n')
            tmp_file_path = tmp_file.name

        # 保存临时文件路径到任务状态
        task.temp_file_path = tmp_file_path
        task.save()
        # relative_url = reverse('download_usernames', args=[str(task_id)])  # Convert task_id to string
        # download_url = f"{scheme}://{host}{relative_url}"
        # task.temp_file_path = tmp_file_path
        # print(f'用户名或ID下载链接: {download_url}')

    task.status = 3
    task.end_time = timezone.now()
    task.save()

@shared_task
def refresh_group_info_task(task_id, group_ids):
    task = TaskStatus.objects.get(task_id=task_id)
    task.status = 2
    task.save()

    for group_id in group_ids:
        tg_group = TGGroup.objects.get(pk=group_id)
        tg_group.save()  # 这将调用 tg_group 的 save 方法，并执行 fetch_group_info

    task.status = 3
    task.end_time = timezone.now()
    task.save()

@shared_task
def refresh_groupcollect_info_task(task_id, group_ids):
    task = TaskStatus.objects.get(task_id=task_id)
    task.status = 2
    task.save()

    for group_id in group_ids:
        tg_group = TGGroupCollect.objects.get(pk=group_id)
        tg_group.save()  # 这将调用 tg_group 的 save 方法，并执行 fetch_group_info

    task.status = 3
    task.end_time = timezone.now()
    task.save()

# @shared_task
# def collect_members(task_id, group_id):
#     task = TaskStatus.objects.get(task_id=task_id)
#     task.status = 2
#     task.save()
#
#     active_accounts = Account.objects.filter(status=1).order_by('last_op_time')[:3]
#     for account in active_accounts:
#
#         pass
#
#     # 获取群组信息
#     group = TGGroup.objects.get(group_id=group_id)
#     try:
#         full_group = client(functions.channels.GetFullChannelRequest(group_id))
#
#         # 获取成员列表
#         members = client.get_participants(full_group.full_chat.id, aggressive=True)
#
#         usernames = []
#         one_month_ago = datetime.now() - timedelta(days=30)
#
#         for member in members:
#             if not member.deleted and isinstance(member.status, (types.UserStatusOffline, types.UserStatusRecently)):
#                 if isinstance(member.status, types.UserStatusOffline) and member.status.was_online < one_month_ago:
#                     continue
#                 usernames.append(member.username)
#
#         # 生成文件
#         file_name = f"{group.group_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
#         temp_dir = tempfile.mkdtemp()
#         file_path = os.path.join(temp_dir, file_name)
#
#         with open(file_path, 'w', encoding='utf-8') as file:
#             for username in usernames:
#                 file.write(f"{username}\n")
#
#         # 将文件路径记录在数据库或者日志中
#         # 此处为日志示例
#         print(f"文件生成成功，路径为：{file_path}")
#
#         # 保存文件路径到数据库，确保文件一天内可以下载
#         group.member_list_file = file_path
#         group.save()
#
#         # 启动删除文件的定时任务，确保文件一天后删除
#         delete_file.apply_async((file_path,), countdown=86400)
#
#     except errors.FloodWaitError as e:
#         print(f'Flood wait error: wait for {e.seconds} seconds')
#     finally:
#         client.disconnect()
#
#     task.status = 3
#     task.end_time = timezone.now()
#     task.save()

@shared_task
def delete_file(file_path):
    if os.path.exists(file_path):
        os.remove(file_path)

def collect_members_sync(group_id):
    group = TGGroup.objects.get(id=group_id)
    active_accounts = Account.objects.filter(status=1).order_by('last_op_time')[:3]
    for account in active_accounts:
        client = async_to_sync(get_telegram_client)(account, account.current_session)

        try:
            full_group = async_to_sync(client)(functions.channels.GetFullChannelRequest(group_id))

            # 获取成员列表
            members = async_to_sync(client.get_participants)(full_group.full_chat.id, aggressive=True)

            usernames = []
            one_month_ago = datetime.now(pytz.utc) - timedelta(days=90)

            for member in members:
                if not member.deleted and member.username and isinstance(member.status,
                                                     (types.UserStatusOffline, types.UserStatusRecently, types.UserStatusOnline)):
                    # if isinstance(member.status, types.UserStatusOffline) and member.status.was_online < one_month_ago:
                    #     continue
                    usernames.append(member.username)

            # 生成文件
            file_name = f"{group.group_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            temp_dir = tempfile.gettempdir()
            file_path = os.path.join(temp_dir, file_name)

            with open(file_path, 'w', encoding='utf-8') as file:
                for username in usernames:
                    file.write(f"{username}\n")

            print(f'共收集到活跃用户数：{len(usernames)}')
            print(f"文件生成成功，路径为：{file_path}")

            # 保存文件路径到数据库
            # group.member_list_file = file_path
            # group.save()

            return file_path

        except errors.FloodWaitError as e:
            print(f'Flood wait error: wait for {e.seconds} seconds')
        finally:
            client.disconnect()

        pass

@shared_task
def stop_celery_task(task_id):
    print(f'正在停止任务：{task_id}')
    task = TaskStatus.objects.get(task_id=task_id)
    task.status = 3
    task.end_time = timezone.now()
    task.save()

    # 使用 celery current_app.control 停止任务
    app = current_app
    app.control.revoke(task_id, terminate=True, signal='SIGTERM')

@shared_task
def stop_all_running_tasks():
    # app = current_app
    # inspector = app.control.inspect()
    # active_tasks = inspector.active()
    #
    # if not active_tasks:
    #     print("没有正在运行的任务。")
    #     return
    #
    # for worker, tasks in active_tasks.items():
    #     for task in tasks:
    #         celery_task_id = task['id']
    #         print(f'正在停止任务：{celery_task_id}')
    #         try:
    #             task_status = TaskStatus.objects.get(celery_task_id=celery_task_id)
    #             task_status.status = 3  # 停止任务
    #             task_status.end_time = timezone.now()
    #             task_status.save()
    #         except TaskStatus.DoesNotExist:
    #             print(f"任务 {celery_task_id} 在 TaskStatus 表中不存在。")
    #
    #         # 使用 celery current_app.control 停止任务
    #         app.control.revoke(celery_task_id, terminate=True, signal='SIGTERM')

    # 获取所有状态为“正在执行”的任务
    running_tasks = TaskStatus.objects.filter(status=2)  # 假设 2 表示“正在执行”

    for task in running_tasks:
        task.status = 3  # 停止任务
        task.end_time = timezone.now()
        task.save()

        # 使用 celery current_app.control 停止任务
        # app = current_app
        # if task.celery_task_id:
        #     print(f'正在停止 celery 任务：{task.celery_task_id}')
        #     # app.control.revoke(task.celery_task_id, terminate=True, signal='SIGTERM')
        #     task = AsyncResult(task.celery_task_id)
        #     task.revoke()

async def op_msg_to_group(client: 'TelegramClient', groups, media_file, content, task_id):
    try:
        me = await client.get_me()

        print(
            f'账号：{utils.get_display_name(me)}, 开始尝试发送群消息条数: {len(groups)}')

        msg_ok_count = 0
        msg_tried = 0
        fail_count = 0
        max_fail_count = 3

        for group_name in groups:
            # 手动检查任务是否被撤销
            task = await sync_to_async(TaskStatus.objects.get)(task_id=task_id)
            if task.status == 3:
                print(f'任务 {task_id} 被撤销')
                break

            # if user is not a participant in this group, join first
            try:
                await client.get_permissions(group_name, me)
            except errors.UserNotParticipantError:
                # need to join this group first
                print(f'账号：{utils.get_display_name(me)} 不是群: {group_name} 的成员，开始加入...')
                try:
                    await client.join_channel(group_name)
                except Exception as e:
                    print(f'账号：{utils.get_display_name(me)} 加入群: {group_name} 失败，原因：{e}')
                    return False
                print(f'账号：{utils.get_display_name(me)} 成功加入群: {group_name}')
            except Exception as e:
                print(f'账号：{utils.get_display_name(me)} 获取群: {group_name} 权限失败，原因：{e}')
                continue

            msg_tried += 1
            try:
                if media_file:
                    await client.send_message(group_name, content, file=media_file, parse_mode='html')
                else:
                    await client.send_message(group_name, content, parse_mode='html')

                print(f'账号：{utils.get_display_name(me)} 发送群: {group_name} 消息成功')
                fail_count = 0
                msg_ok_count += 1
            except errors.PeerFloodError:
                error = "发送过多请求，需要等待"
                print(f'账号：{utils.get_display_name(me)}, {error}')
                account = await sync_to_async(Account.objects.get)(phone=me.phone)
                account.last_error = error
                account.last_error_time = timezone.now()
                await sync_to_async(account.save)()
                break
            except errors.FloodWaitError as e:
                error = f"请求频率过高，请等待 {e.seconds} 秒"
                print(f'账号：{utils.get_display_name(me)}, {error}')
                account = await sync_to_async(Account.objects.get)(phone=me.phone)
                account.last_error = error
                account.last_error_time = timezone.now()
                await sync_to_async(account.save)()
                break
            except errors.RpcCallFailError as e:
                print(f"发生 RPC 错误: {e}")
                break
            except Exception as e:
                print(f'账号：{utils.get_display_name(me)} 发送群: {group_name} 消息失败，原因：{e}')
                fail_count += 1
            finally:
                if fail_count > max_fail_count:
                    break
                await asyncio.sleep(random.randrange(5, 10))

        print(
            f'账号：{utils.get_display_name(me)}, 成功发送消息: {msg_ok_count}, 共尝试发送次数：{msg_tried}')

        return msg_ok_count
    except Exception as e:
        print(f'op_msg_to_group failed：{e}')
        return False

async def op_msg_to_user(client: 'TelegramClient', msgs, task_id):
    msg_ok_count = 0
    msg_tried = 0
    try:
        me = await client.get_me()

        print(
            f'账号：{utils.get_display_name(me)}, 开始尝试发送群消息条数: {len(msgs)}')


        fail_count = 0
        max_fail_count = 3

        for username, content in msgs:
            # 手动检查任务是否被撤销
            task = await sync_to_async(TaskStatus.objects.get)(task_id=task_id)
            if task.status == 3:
                print(f'任务 {task_id} 被撤销')
                break

            # validate content and target
            if username:
                username = username.strip()
            if content:
                content = content.strip()
            if not username or not content:
                continue

            msg_tried += 1
            try:
                await client.send_message(username, content, parse_mode='html')

                print(f'账号：{utils.get_display_name(me)} 发送消息给用户: {username} 成功')
                fail_count = 0
                msg_ok_count += 1
            except errors.PeerFloodError:
                error = "发送过多请求，需要等待"
                print(f'账号：{utils.get_display_name(me)}, {error}')
                account = await sync_to_async(Account.objects.get)(phone=me.phone)
                account.last_error = error
                account.last_error_time = timezone.now()
                await sync_to_async(account.save)()
                break
            except errors.FloodWaitError as e:
                error = f"请求频率过高，请等待 {e.seconds} 秒"
                print(f'账号：{utils.get_display_name(me)}, {error}')
                account = await sync_to_async(Account.objects.get)(phone=me.phone)
                account.last_error = error
                account.last_error_time = timezone.now()
                await sync_to_async(account.save)()
                break
            except errors.RpcCallFailError as e:
                print(f"发生 RPC 错误: {e}")
                break
            except Exception as e:
                print(f'账号：{utils.get_display_name(me)} 发送消息给用户: {username} 失败，原因：{e}')
                fail_count += 1
            finally:
                if fail_count > max_fail_count:
                    break
                await asyncio.sleep(random.randrange(5, 10))

        print(
            f'账号：{utils.get_display_name(me)}, 成功发送消息: {msg_ok_count}, 共尝试发送次数：{msg_tried}')

    except Exception as e:
        print(f'op_msg_to_user failed：{e}')

    return msg_ok_count, msg_tried
@shared_task
def msg_to_group_task(task_id, account_ids, group_names, media_file, content):
    task = TaskStatus.objects.get(task_id=task_id)
    task.status = 2
    task.save()

    def do_msg_to_group(account_id, groups, media_file, content, task_id):
        account2 = Account.objects.get(id=account_id)
        result2 = async_to_sync(do_telegram_account)(account2, 8, op_msg_to_group, groups, media_file,
                                                     content, task_id)
        return account2.phone, result2

    if not account_ids or not content:
        print("Empty account_ids or content received.")
        return


    # 平均分配 invitees
    chunk_size = (len(group_names) + len(account_ids) - 1) // len(account_ids)
    group_chunks = [group_names[i:i + chunk_size] for i in range(0, len(group_names), chunk_size)]

    invite_ok_total = 0
    # 获取 CPU 核数
    cpu_count = os.cpu_count()
    # 根据 CPU 核数设置线程池大小
    max_workers = cpu_count * 2  # 这里可以根据需求调整乘数
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {}
        for account_id, chunk in zip(account_ids, group_chunks):
            futures[executor.submit(do_msg_to_group, account_id, chunk, media_file, content, task_id)] = account_id
        for future in as_completed(futures):
            account_id = futures[future]
            try:
                phone, result = future.result()
                count = 0
                try:
                    count = int(result)
                except:
                    pass
                print(f'账号: {phone} 共成功发送消息条数: {count}')
                invite_ok_total += count
            except Exception as exc:
                print(f'Account {account_id} generated an exception: {exc}')

        print(f'本次任务总共成功发送消息条数：{invite_ok_total}')
        # delete media file after use
        if media_file and os.path.exists(media_file):
            os.remove(media_file)

    task.status = 3
    task.end_time = timezone.now()
    task.save()

@shared_task
def msg_to_user_task(task_id, account_ids, msg_data, max_msgs_per_account):
    task = TaskStatus.objects.get(task_id=task_id)
    task.status = 2
    task.save()

    def do_msg_to_user(account_id, msgs, task_id):
        account2 = Account.objects.get(id=account_id)
        result2, tried = async_to_sync(do_telegram_account)(account2, 13, op_msg_to_user, msgs, task_id)
        return account2.phone, result2, tried

    if not account_ids or not msg_data:
        print("Empty account_ids or content received.")
        return


    # 平均分配 invitees
    chunk_size = (len(msg_data) + len(account_ids) - 1) // len(account_ids)
    if chunk_size > max_msgs_per_account:
        chunk_size = max_msgs_per_account
    msg_chunks = [msg_data[i:i + chunk_size] for i in range(0, len(msg_data), chunk_size)]

    msg_ok_total = 0
    msg_tried = 0
    details = []
    # 获取 CPU 核数
    cpu_count = os.cpu_count()
    # 根据 CPU 核数设置线程池大小
    max_workers = cpu_count * 2  # 这里可以根据需求调整乘数
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {}
        for account_id, chunk in zip(account_ids, msg_chunks):
            futures[executor.submit(do_msg_to_user, account_id, chunk, task_id)] = account_id
        for future in as_completed(futures):
            account_id = futures[future]
            try:
                phone, result, tried = future.result()
                count = 0
                try:
                    count = int(result)
                except:
                    pass

                details.append((phone, count, tried))
                msg_ok_total += count
                msg_tried += tried
            except Exception as exc:
                print(f'Account {account_id} generated an exception: {exc}')

        print(f'------------任务完成--------------')
        for account, count, tried in details:
            print(f'账号: {account} 共成功发送消息条数: {count}，尝试次数：{tried}')
        print(f'本次任务总共成功发送消息条数：{msg_ok_total}，共尝试发送次数：{msg_tried}')

    task.status = 3
    task.end_time = timezone.now()
    task.save()

def create_zip(file_paths):
    temp_dir = tempfile.gettempdir()
    zip_filename = os.path.join(temp_dir, f"成员采集全集_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip")
    with zipfile.ZipFile(zip_filename, 'w') as zipf:
        for file_path in file_paths:
            zipf.write(file_path, os.path.basename(file_path))

    # 删除已压缩的文件
    for file_path in file_paths:
        try:
            os.remove(file_path)
        except OSError as e:
            print(f"Error deleting file {file_path}: {e}")

    return zip_filename

def process_files(file_paths):
    if len(file_paths) == 1:
        return file_paths[0]
    else:
        return create_zip(file_paths)

@shared_task
def collect_members_task(task_id, account_group, group_ids, collect_data, last_seen, collect_admin, collect_group):
    task = TaskStatus.objects.get(task_id=task_id)
    task.status = 2
    task.save()

    def do_collect_members(account_id, group_ids, collect_data, last_seen, collect_admin, collect_group):
        account2 = Account.objects.get(id=account_id)
        result2, groups = async_to_sync(do_telegram_account)(account2, 9, op_collect_members, group_ids, collect_data, last_seen, collect_admin, collect_group)
        return account2.phone, result2, groups

    if not account_group or not group_ids:
        print("Empty tg_group, group_ids received.")
        task.status = 3
        task.end_time = timezone.now()
        task.save()
        return

    account_ids = [account.pk for account in Account.objects.filter(status=1, groups__id=account_group).distinct()]
    if not account_ids:
        print("无可用账号")
        task.status = 3
        task.end_time = timezone.now()
        task.save()
        return

    # 平均分配 invitees
    chunk_size = (len(group_ids) + len(account_ids) - 1) // len(account_ids)
    groups_chunks = [group_ids[i:i + chunk_size] for i in range(0, len(group_ids), chunk_size)]

    collect_ok_total = 0
    collected_files = []
    collected_groups = []
    # 获取 CPU 核数
    cpu_count = os.cpu_count()
    # 根据 CPU 核数设置线程池大小
    max_workers = cpu_count * 2  # 这里可以根据需求调整乘数
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {}
        for account_id, chunk in zip(account_ids, groups_chunks):
            futures[executor.submit(do_collect_members, account_id, chunk, collect_data, last_seen, collect_admin, collect_group)] = account_id
        for future in as_completed(futures):
            account_id = futures[future]
            try:
                phone, result, groups = future.result()
                if result and len(result):
                    collect_ok_total += len(result)
                    collected_files.extend(result)

                if groups:
                    collected_groups.extend(groups)

            except Exception as exc:
                print(f'Account {account_id} generated an exception: {exc}')

        # 将采集的群组存入文件
        if collect_group and collected_groups:
            temp_dir = tempfile.gettempdir()
            temp_file_path = os.path.join(temp_dir,
                                          f"采集到的群组列表_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
            with open(temp_file_path, 'w', encoding='utf-8') as file:
                for group in collected_groups:
                    file.write(f"https://t.me/{group.username}\n")
            collected_files.append(temp_file_path)

        print(f'本次任务总共收集到成员列表数：{collect_ok_total}')

        # 处理文件路径列表
        if collect_ok_total:
            final_file_path = process_files(collected_files)
            task.temp_file_path = final_file_path
            print(f'请前往【任务记录】中下载采集到的成员列表')

    task.status = 3
    task.end_time = timezone.now()
    task.save()