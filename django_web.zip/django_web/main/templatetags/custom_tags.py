from django import template

register = template.Library()

@register.simple_tag
def has_permissions(user, *perms):
    if not perms:
        return False
    # 展开传入的单个权限列表
    if len(perms) == 1 and isinstance(perms[0], list):
        perms = perms[0]
    return all(user.has_perm(perm) for perm in perms)
