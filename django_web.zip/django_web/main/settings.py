from .models import Setting
from django.utils.functional import lazy
from asgiref.sync import sync_to_async

async def get_setting_value(setting_key, default=None):
    try:
        setting = await sync_to_async(Setting.objects.get)(setting_key=setting_key)
        return setting.value
    except Setting.DoesNotExist:
        return default


# REGION = lazy(lambda:  get_setting_value('region', 'TW'), str)
# PROXY = lazy(lambda: get_setting_value('proxy', ''), str)