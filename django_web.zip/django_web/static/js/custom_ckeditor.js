CKEDITOR.plugins.add('customstyles', {
    init: function(editor) {
        editor.on('instanceReady', function() {
            editor.dataProcessor.htmlFilter.addRules({
                elements: {
                    strong: function(element) {
                        element.name = 'b';
                    },
                    em: function(element) {
                        element.name = 'i';
                    }
                }
            });

            editor.dataProcessor.writer.setRules('br', {
                indent: false,
                breakBeforeOpen: false,
                breakAfterOpen: false,
                breakBeforeClose: false,
                breakAfterClose: false
            });

//            editor.on('beforeGetData', function(evt) {
//                evt.data.dataValue = evt.data.dataValue.replace(/<br\s*\/?>/g, '\\n');
//            });

        });
    }
});
