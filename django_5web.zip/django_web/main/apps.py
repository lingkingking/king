from django.apps import AppConfig
from django.db.models.signals import post_migrate

def create_custom_permissions(sender, **kwargs):
    from django.contrib.auth.models import Group, Permission
    from django.contrib.contenttypes.models import ContentType

    content_type = ContentType.objects.get_for_model(Permission)
    Permission.objects.get_or_create(codename='basic', name='拉群基础功能',
                                     content_type=content_type)
    Permission.objects.get_or_create(codename='can_access_collect', name='能访问收集管理模块',
                                     content_type=content_type)
    Permission.objects.get_or_create(codename='can_access_messaging', name='能访问群发管理模块',
                                     content_type=content_type)

    groups_permissions = {
        '基础功能': [
            'auth.basic',
            'main.add_account',
            'main.change_account',
            'main.delete_account',
            'main.view_account',
            'main.add_group',
            'main.change_group',
            'main.delete_group',
            'main.view_group',
            'main.add_grouptag',
            'main.change_grouptag',
            'main.delete_grouptag',
            'main.view_grouptag',
            'main.add_setting',
            'main.change_setting',
            'main.delete_setting',
            'main.view_setting',
            'main.add_taskstatus',
            'main.change_taskstatus',
            'main.delete_taskstatus',
            'main.view_taskstatus',
            'main.add_tggroup',
            'main.change_tggroup',
            'main.delete_tggroup',
            'main.view_tggroup',
        ],
        '私信群发模块': [
            'auth.can_access_messaging',
            'main.add_accountmessaging',
            'main.change_accountmessaging',
            'main.delete_accountmessaging',
            'main.view_accountmessaging',
        ],
        '采集模块': [
            'auth.can_access_collect',
            'main.add_grouptag2',
            'main.change_grouptag2',
            'main.delete_grouptag2',
            'main.view_grouptag2',
            'main.add_tggroupcollect',
            'main.change_tggroupcollect',
            'main.delete_tggroupcollect',
            'main.view_tggroupcollect',
        ]
    }

    for group_name, perms in groups_permissions.items():
        group, created = Group.objects.get_or_create(name=group_name)
        for perm_codename in perms:
            try:
                app_label, codename = perm_codename.split('.')
                # 尝试通过 app_label 和 codename 获取 ContentType
                content_type = ContentType.objects.get(app_label=app_label, permission__codename=codename)
                perm = Permission.objects.get(codename=codename, content_type=content_type)
                group.permissions.add(perm)
            except ContentType.DoesNotExist:
                print(f"ContentType for app_label '{app_label}' and codename '{codename}' not found.")
            except Permission.DoesNotExist:
                print(f"Permission '{perm_codename}' not found.")
            except Exception as e:
                print(f"An error occurred: {e}")

class MainConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'main'

    def ready(self):
        # 创建自定义权限
        post_migrate.connect(create_custom_permissions, sender=self)



