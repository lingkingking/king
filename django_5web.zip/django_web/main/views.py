import os
import asyncio
from asgiref.sync import async_to_sync
from django.http import HttpResponse, JsonResponse, HttpResponseServerError
from django.views.decorators.http import require_http_methods
from django.shortcuts import render, redirect
from django.conf import settings
from .models import Account, Group, TaskStatus, TGGroup, GroupTag, GroupTag2, TGGroupCollect
from .forms import UploadMultipleFilesForm, GroupSelectionForm, MyForm, CollectMembersForm, TGGroupForm, \
    ImportGroupForm, TGGroupCollectForm, CreateTGGroupForm
from django.shortcuts import get_object_or_404
from django.http import FileResponse, HttpResponseNotFound
from django.contrib import messages
from celery import current_app
from telethon.tl.functions.contacts import ResolveUsernameRequest
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from telethon.tl.types import UserStatusOnline, UserStatusOffline, UserStatusRecently
from .utils import clean_group_id, do_telegram_account, op_create_public_group
from django.http import JsonResponse, HttpResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
from .models import Group,Tguser
import json
from .tg_client import Telegram_Thread
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QAction, QMenu, QMessageBox
import requests
import time
from time import sleep
from concurrent.futures import ThreadPoolExecutor
import json
import os
import uuid
import random
import socks
import threading
import pytz
import traceback
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from opentele.tl import TelegramClient
from opentele.api import API, UseCurrentSession
from telethon import errors
from telethon import events, utils
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl import types, functions
from asgiref.sync import async_to_sync, sync_to_async
from django.core.paginator import Paginator

@csrf_exempt
@require_POST
def api_import_accounts(request):
    form = UploadMultipleFilesForm(request.POST, request.FILES)
    if form.is_valid():
        files = form.cleaned_data['files']
        group_ids = form.cleaned_data['groups']
        for file in files:
            handle_uploaded_file(file, group_ids)
        return JsonResponse({'status': 'success', 'message': '账号导入完成'})
    else:
        errors = form.errors.as_json()
        return JsonResponse({'status': 'error', 'errors': errors})


@csrf_exempt
@require_POST
def api_tggroup_create(request):
    form = TGGroupForm(request.POST, request.FILES)
    if form.is_valid():
        group_id = form.cleaned_data['group_id']
        group_id = clean_group_id(group_id)

        tg_group, created = TGGroup.objects.get_or_create(group_id=group_id)
        if created:
            # 如果是新创建的记录
            print(f'新建了TG群组: {group_id}')
        else:
            # 如果记录已经存在
            tg_group.save()
            print(f'刷新TG群组: {group_id}')

        return JsonResponse({'status': 'success', 'message': '创建完成'})
    else:
        errors = form.errors.as_json()
        return JsonResponse({'status': 'error', 'errors': errors})

@csrf_exempt
@require_POST
def api_tggroup_create_new(request):
    form = CreateTGGroupForm(request.POST)
    if form.is_valid():
        admin_account = form.cleaned_data.get('admin_account')
        group_title = form.cleaned_data['group_title']
        group_desc = form.cleaned_data['group_desc']

        account = Account.objects.get(pk=admin_account.pk)
        if not account or account.status != 1:
            print(f'取消账号异常')
            return HttpResponseServerError()

        gid, access_hash = async_to_sync(do_telegram_account)(account, 10, op_create_public_group, group_title, group_desc)
        if not gid or not access_hash:
            print(f'群组创建失败')
            return HttpResponseServerError()

        tg_group = TGGroup(gid=gid, access_hash=access_hash, group_title=group_title, group_desc=group_desc)
        tg_group.save(skip_fetch=True)

        tg_group.admins.add(account)
        tg_group.save(skip_fetch=True)

        return JsonResponse({'status': 'success', 'message': '创建完成'})
    else:
        errors = form.errors.as_json()
        return HttpResponseServerError()

@csrf_exempt
@require_POST
def api_tggroup_import(request):
    form = ImportGroupForm(request.POST, request.FILES)
    if form.is_valid():
        file = request.FILES['import_file']
        groups = file.read().decode('utf-8').splitlines()
        cleaned_groups = [clean_group_id(group) for group in groups]

        for group_id in cleaned_groups:
            tg_group, created = TGGroup.objects.get_or_create(group_id=group_id)
            if created:
                # 如果是新创建的记录
                print(f'新建了TG群组: {group_id}')
            else:
                # 如果记录已经存在
                tg_group.save()
                print(f'刷新TG群组: {group_id}')

        return JsonResponse({'status': 'success', 'message': '创建完成'})
    else:
        errors = form.errors.as_json()
        return JsonResponse({'status': 'error', 'errors': errors})

@csrf_exempt
@require_POST
def api_tggroup_create2(request):
    form = TGGroupCollectForm(request.POST, request.FILES)
    if form.is_valid():
        group_id = form.cleaned_data['group_id']
        group_id = clean_group_id(group_id)

        tg_group, created = TGGroupCollect.objects.get_or_create(group_id=group_id)
        if created:
            # 如果是新创建的记录
            print(f'新建了TG群组: {group_id}')
        else:
            # 如果记录已经存在
            tg_group.save()
            print(f'刷新TG群组: {group_id}')

        return JsonResponse({'status': 'success', 'message': '创建完成'})
    else:
        errors = form.errors.as_json()
        return JsonResponse({'status': 'error', 'errors': errors})

@csrf_exempt
@require_POST
def api_tggroup_import2(request):
    form = ImportGroupForm(request.POST, request.FILES)
    if form.is_valid():
        file = request.FILES['import_file']
        groups = file.read().decode('utf-8').splitlines()
        cleaned_groups = [clean_group_id(group) for group in groups]

        for group_id in cleaned_groups:
            tg_group, created = TGGroupCollect.objects.get_or_create(group_id=group_id)
            if created:
                # 如果是新创建的记录
                print(f'新建了TG群组: {group_id}')
            else:
                # 如果记录已经存在
                tg_group.save()
                print(f'刷新TG群组: {group_id}')

        return JsonResponse({'status': 'success', 'message': '创建完成'})
    else:
        errors = form.errors.as_json()
        return JsonResponse({'status': 'error', 'errors': errors})


@csrf_exempt
@require_POST
def api_get_users(request):
    if request.method == 'POST':
        user_dict_list = []
        online_sum  = 0
        offline_sum = 0
        data = json.loads(request.body.decode('utf-8'))
        username = data.get('username',None)
        status = data.get('status',None)
        off_online = data.get('off_online',None)
        phone =data.get('phone',None)
        type = data.get('type', None)
        page = data.get('page_num',1)
        num_limit = data.get('num_limit', 20)
        d_search = {}
        print(off_online)

        if username:
            d_search["username"] = username
        if status:
            d_search["status"] = status
        if phone:
            d_search["phone"] = phone
        if type:
            d_search["type"] = type
        all_data = Tguser.objects.filter(**d_search).all().order_by("-off_online")

        if off_online:
            all_data = all_data.filter(off_online__icontains=off_online)

        if page == "all":
            all_data = all_data.filter(type="0")
            objects =  all_data
            page = 1
            total_pages = 1
            total_count =1
        else:
            # 创建Paginator对象，每页显示10个对象
            paginator = Paginator(all_data, num_limit)
            try:
                # 获取指定页码的页面数据
                objects = paginator.page(page)
            except PageNotAnInteger:
                # 如果页码不是一个整数，展示第一页
                objects = paginator.page(1)
            except EmptyPage:
                # 如果页码超出范围(例如9999)，展示最后一页
                objects = paginator.page(paginator.num_pages)
            total_pages = paginator.num_pages
            # 总条数
            total_count = paginator.count
        for temp_user in objects:
            if temp_user.status == "online":
                online_sum += 1
            if temp_user.status == "offline":
                offline_sum += 1
            user_dict_list.append({'username': temp_user.username,
                                   "status": temp_user.status,
                                   "off_online": temp_user.off_online,
                                   'phone': temp_user.phone,
                                   'user_id': temp_user.user_id,
                                   'type': temp_user.type,
                                   'access_hash': temp_user.access_hash})
        if total_count == 1:
            total_count = len(user_dict_list)
    print(user_dict_list)
    print(total_count)
    return JsonResponse({'status': 'success', 'message': '校验用户完成',"number":page,"total_pages" : total_pages ,"total_count":total_count,"data":user_dict_list,"online_sum":online_sum,"offline_sum":offline_sum})

@csrf_exempt
# @require_POST
@require_http_methods(["POST"])
def api_check_user_import(request):
    form = ImportGroupForm(request.POST, request.FILES)
    if form.is_valid():
        file = request.FILES['import_file']
        users = file.read().decode('utf-8').splitlines()
        users_list = []
        for user in users:
            users_list.append(user.strip())
        temp_list = asyncio.run(client_task(users_list))
        for i in temp_list:
            account = Tguser.objects.filter(username=i["username"]).first()
            if account :
                continue
            print(i)
            if str(i["phone"]) == "None":
                i["phone"] = "空"
            tguser_obj = Tguser.objects.create(username=i["username"],status=i["status"],off_online=i["off_online"],phone=i["phone"],user_id=i["user_id"],access_hash=i["access_hash"],type="0")
            tguser_obj.save()

    return JsonResponse({'status': 'success', 'message': '校验用户完成',"data":temp_list})

async def client_task(users_list):
    days_ago = datetime.now(pytz.utc) - timedelta(days=7)
    user_dict_list = []
    region = 'us'
    ipproxy_name = '5Hj9Ks2Cv9He-res-US-sid-2545452|Xv2u76ZeYPia86V123a|z1.ipmart.io|9595'
    tg_obj = Telegram_Thread(region, ipproxy_name)
    tg_obj.get_tg_session('13348102882')  # 获取session文件
    client = await tg_obj.tg_login('13348102882', 0)
    # print(client)
    for temp_user_i in users_list:
        print(temp_user_i)
        tasks = [asyncio.create_task(client(ResolveUsernameRequest(temp_user_i)))]
        done, pending = await asyncio.wait(tasks)

        for task in done:
            try:
                user_dict =task.result().users
            except:
                print("用户不存在或受限制")
                continue
            temp_user = user_dict[0]
            # print(temp_user)
            if isinstance(temp_user.status, UserStatusOnline):
                # print(f"User is online. Last seen: {temp_user.status.expires}")
                temp_data = temp_user.status.expires
                temp_status = "online"

            elif isinstance(temp_user.status, UserStatusOffline):
                # print(f"User is offline. Last seen: {temp_user.status.was_online}")
                if temp_user.status.was_online < days_ago:
                    continue
                temp_data = temp_user.status.was_online
                temp_status = "offline"

            elif isinstance(temp_user.status, UserStatusRecently):
                # print("User was recently online.")
                continue

            else:
                # print("User status is unknown.")
                continue
            user_dict_list.append({'username': temp_user.username,
                                   "status": temp_status,
                                   "off_online": temp_data.strftime("%Y-%m-%d %H:%M:%S"),
                                   'phone': temp_user.phone,
                                   'user_id': temp_user.id,
                                   'access_hash': temp_user.access_hash})
            print(user_dict_list)
    return user_dict_list

def get_log_content(request):
    log_file_path = os.path.join(settings.BASE_DIR, 'logs', 'tg_control.log')
    lines = []
    try:
        with open(log_file_path, 'r', encoding='utf-8') as log_file:
            lines = log_file.readlines()[-1000:]  # 仅读取最后1000行
    except Exception as e:
        lines = [f"Error reading log file: {str(e)}"]

    return JsonResponse({'log': lines})



def handle_uploaded_file(file, group_ids):
    phone_number = os.path.splitext(file.name)[0]
    today = datetime.now().strftime('%Y%m%d')
    session_dir = os.path.join(settings.BASE_DIR, 'session_files', today)
    if not os.path.exists(session_dir):
        os.makedirs(session_dir)
    session_path = os.path.join(session_dir, file.name)

    with open(session_path, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)

    account, created = Account.objects.get_or_create(
        phone=phone_number,
        defaults={'session_path': session_path}
    )
    if not created:
        account.session_path = session_path
        account.save()

    if group_ids:
        account.groups.set(group_ids)

def upload_files(request):
    if request.method == 'POST':
        form = UploadMultipleFilesForm(request.POST, request.FILES)
        if form.is_valid():
            files = form.cleaned_data['files']
            group_ids = form.cleaned_data['groups']
            for file in files:
                handle_uploaded_file(file, group_ids)
            return redirect('account_list')
    else:
        form = UploadMultipleFilesForm()
    return render(request, 'main/upload_files.html', {'form': form})

def add_to_group(request):
    if request.method == 'POST':
        form = GroupSelectionForm(request.POST)
        if form.is_valid():
            group_ids = form.cleaned_data['groups']
            account_ids = request.session.get('selected_accounts', [])
            accounts = Account.objects.filter(id__in=account_ids)
            for account in accounts:
                account.groups.add(*group_ids)
            return redirect('account_list')
    else:
        form = GroupSelectionForm()
    return render(request, 'main/add_to_group.html', {'form': form})

def account_list(request):
    accounts = Account.objects.all()
    return render(request, 'main/account_list.html', {'accounts': accounts})

def download_log(request):
    file_path = os.path.join(settings.BASE_DIR, 'logs', 'tg_control.log')
    current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"tg_control_{current_time}.log"
    return FileResponse(open(file_path, 'rb'), as_attachment=True, filename=file_name)

def download_usernames(request, task_id, operation):
    # try:
    #     task_id = UUID(task_id)
    # except ValueError:
    #     return HttpResponseNotFound('Invalid task ID')

    task = get_object_or_404(TaskStatus, task_id=task_id)
    if task.temp_file_path and os.path.exists(task.temp_file_path):
        # 提取文件名
        original_filename = os.path.basename(task.temp_file_path)

        # 创建 FileResponse 对象
        # response = FileResponse(open(task.temp_file_path, 'rb'), as_attachment=True)
        # response['Content-Disposition'] = f'attachment; filename="{original_filename}"'
        return FileResponse(open(task.temp_file_path, 'rb'), as_attachment=True,
                            filename=original_filename)
        return response
    else:
        return HttpResponseNotFound('File not found')

def stop_all_tasks_view(request):
    # 获取所有状态为“正在执行”的任务
    running_tasks = TaskStatus.objects.filter(status=2)  # 假设 2 表示“正在执行”

    for task in running_tasks:
        task.status = 3  # 停止任务
        task.end_time = timezone.now()
        task.save()

        # 使用 celery current_app.control 停止任务
        app = current_app
        if task.celery_task_id:
            print(f'正在停止 celery 任务：{task.celery_task_id}')
            messages.success(request, f'正在停止 celery 任务：{task.celery_task_id}')
            app.control.revoke(task.celery_task_id, terminate=True, signal='SIGTERM')

    messages.success(request, "所有正在执行的任务已停止。")
    return redirect('..')

def index(request):
    if request.method == 'POST':
        form = MyForm(request.POST)
        if form.is_valid():
            # 处理表单数据
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            print(f'name: {name}, email: {email}')
            # 执行其他操作
            return redirect('index')  # 重定向到成功页面或其他页面
    else:
        form = MyForm()

    return render(request, 'main/index.html', {'form': form})

def collect_members_view(request):
    if request.method == 'POST':
        form = CollectMembersForm(request.POST)
        if form.is_valid():
            # 处理表单数据
            collect_data = form.cleaned_data['collect_data']
            last_seen = form.cleaned_data['last_seen']
            tg_group = form.cleaned_data['tg_group']
            print(f'collect_data: {collect_data}, last_seen: {last_seen}, tg_group: {tg_group}')
            # 执行其他操作
            return redirect('collect_members')  # 重定向到成功页面或其他页面
    else:
        form = CollectMembersForm()

    return render(request, 'admin/collect_members.html',
                  {'form': form, 'is_nav_sidebar_enabled': True, 'title': '群组成员采集'})


def group_list(request):
    groups = Group.objects.all().values('id', 'name', 'create_time')
    return JsonResponse(list(groups), safe=False)

@csrf_exempt
def add_group(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        group_name = data.get('name')
        if group_name:
            Group.objects.create(name=group_name)
            return HttpResponse(status=201)
        return HttpResponseBadRequest('Invalid group name')
    return HttpResponseBadRequest('Invalid method')

@csrf_exempt
def delete_group(request, group_id):
    if request.method == 'DELETE':
        try:
            group = Group.objects.get(id=group_id)
            group.delete()
            return HttpResponse(status=204)
        except Group.DoesNotExist:
            return HttpResponseBadRequest('Group not found')
    return HttpResponseBadRequest('Invalid method')

def tag_list(request):
    groups = GroupTag.objects.all().values('id', 'name', 'create_time')
    return JsonResponse(list(groups), safe=False)

@csrf_exempt
def add_tag(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        group_name = data.get('name')
        if group_name:
            GroupTag.objects.create(name=group_name)
            return HttpResponse(status=201)
        return HttpResponseBadRequest('Invalid group name')
    return HttpResponseBadRequest('Invalid method')

@csrf_exempt
def delete_tag(request, group_id):
    if request.method == 'DELETE':
        try:
            group = GroupTag.objects.get(id=group_id)
            group.delete()
            return HttpResponse(status=204)
        except GroupTag.DoesNotExist:
            return HttpResponseBadRequest('Group not found')
    return HttpResponseBadRequest('Invalid method')

def tag2_list(request):
    groups = GroupTag2.objects.all().values('id', 'name', 'create_time')
    return JsonResponse(list(groups), safe=False)

@csrf_exempt
def add_tag2(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        group_name = data.get('name')
        if group_name:
            GroupTag2.objects.create(name=group_name)
            return HttpResponse(status=201)
        return HttpResponseBadRequest('Invalid group name')
    return HttpResponseBadRequest('Invalid method')

@csrf_exempt
def delete_tag2(request, group_id):
    if request.method == 'DELETE':
        try:
            group = GroupTag2.objects.get(id=group_id)
            group.delete()
            return HttpResponse(status=204)
        except GroupTag2.DoesNotExist:
            return HttpResponseBadRequest('Group not found')
    return HttpResponseBadRequest('Invalid method')
