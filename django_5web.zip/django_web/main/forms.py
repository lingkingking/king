from django import forms
from django.forms import SelectMultiple

from .models import Group, TGGroup, GroupTag, GroupTag2, TGGroupCollect, Account
from ckeditor.widgets import CKEditorWidget
from .validators import validate_file_extension
from django.utils.safestring import mark_safe
from PIL import Image
from io import BytesIO
from django.core.files.uploadedfile import InMemoryUploadedFile
import sys

class MultipleFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True

class MultipleFileField(forms.FileField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("widget", MultipleFileInput())
        super().__init__(*args, **kwargs)

    def clean(self, data, initial=None):
        single_file_clean = super().clean
        if isinstance(data, (list, tuple)):
            result = [single_file_clean(d, initial) for d in data]
        else:
            result = [single_file_clean(data, initial)]
        return result

class UploadMultipleFilesForm(forms.Form):
    files = MultipleFileField(label='选择多个.session文件')
    groups = forms.ModelMultipleChoiceField(queryset=Group.objects.all(), widget=forms.CheckboxSelectMultiple, required=False, label="选择分组")

class GroupSelectionForm(forms.Form):
    groups = forms.ModelMultipleChoiceField(queryset=Group.objects.all(), widget=forms.CheckboxSelectMultiple, required=False, label="选择分组")

class JoinGroupForm(forms.Form):
    group_name = forms.CharField(label='群名', max_length=255)

class InviteGroupForm(forms.Form):
    group_name = forms.CharField(label='群名', max_length=255)
    invite_by = forms.ChoiceField(
        choices=[
            (0, '用户名'),
            (1, '手机号'),
            (2, '用户ID'),
        ],
        label="选择邀请方式",
        initial=0
    )
    invitees_file = forms.FileField(label='邀请名单文件', localize=True)
    max_invitees = forms.IntegerField(label='每个账号拉最多人数', max_value=100, min_value=1, initial=30)
    interval = forms.IntegerField(label='每次邀请间隔时间（秒）', max_value=1000, min_value=10, initial=30)
    active_only = forms.BooleanField(label='只拉活跃用户（7天内上线）', initial=True, required=False)

class TGGroupForm(forms.ModelForm):
    class Meta:
        model = TGGroup
        fields = ['group_id']

class TGGroupCollectForm(forms.ModelForm):
    class Meta:
        model = TGGroupCollect
        fields = ['group_id']

class PlatformChoiceForm(forms.Form):
    platform = forms.ChoiceField(
        choices=[
            (0, 'PC'),
            # (1, 'iOS'),
            # (2, 'Android'),
            # (3, 'AndroidX'),
        ],
        label="选择平台",
        initial=0
    )

class ExportUsernamesForm(forms.Form):
    invitees_file = forms.FileField(label='手机号列表', localize=True)
    max_users = forms.IntegerField(label='每个账号最多导出用户数', max_value=100, min_value=1, initial=50)

class TelegramMessageForm(forms.Form):
    group_file = forms.FileField(label='群列表', localize=True)
    media_file = forms.FileField(label='图片或视频文件', validators=[validate_file_extension], required=False, localize=True)
    message_content = forms.CharField(label='消息内容', widget=CKEditorWidget(config_name='default'))

    class Media:
        js = (
            '/static/ckeditor/ckeditor/ckeditor.js',
            'js/custom_ckeditor.js',  # 你的 custom_ckeditor.js 文件的路径
        )

class TelegramMessageUserForm(forms.Form):
    msg_file = forms.FileField(label='发送目标及内容', localize=True)
    max_msgs_per_account = forms.IntegerField(label='每个账号最多发送条数', max_value=50, min_value=1, initial=10)

class MyForm(forms.Form):
    name = forms.CharField(label='Your Name', max_length=100)
    email = forms.EmailField(label='Your Email')

class CollectMembersForm(forms.Form):
    account_group = forms.ModelChoiceField(
        queryset=Group.objects.all(),
        label="账号分组",
        empty_label="请选择一个分组",
        to_field_name='pk',
        widget=forms.Select
    )
    collect_data = forms.ChoiceField(
        choices=[
            (0, '用户名'),
            (1, '手机号'),
            (2, '用户名+手机号'),
        ],
        label="采集数据",
        initial=0
    )
    last_seen = forms.ChoiceField(
        choices=[
            (0, '3天'),
            (1, '7天'),
            (2, '30天'),
            (3, '90天'),
        ],
        label="活跃天数",
        initial=0
    )
    collect_admin = forms.BooleanField(label='是否采集管理员', initial=False, required=False)
    collect_group = forms.BooleanField(label='是否采集群组', initial=False, required=False)
class ImportGroupForm(forms.Form):
    import_file = forms.FileField(label='用户名文件', localize=True)

class TagSelectionForm(forms.Form):
    groups = forms.ModelMultipleChoiceField(queryset=GroupTag.objects.all(), widget=forms.CheckboxSelectMultiple, required=False, label="选择标签")

class Tag2SelectionForm(forms.Form):
    groups = forms.ModelMultipleChoiceField(queryset=GroupTag2.objects.all(), widget=forms.CheckboxSelectMultiple, required=False, label="选择标签")

class CreateTGGroupForm(forms.Form):
    admin_account = forms.ModelChoiceField(
        queryset=Account.objects.filter(status=1),
        label="管理员账号",
        empty_label="请选择一个账号",
        to_field_name='pk',
        widget=forms.Select
    )
    group_title = forms.CharField(label='群标题', max_length=255)
    group_desc = forms.CharField(label='简介', max_length=510, required=False)

class ImagePreviewWidget(forms.widgets.FileInput):
    def render(self, name, value, attrs=None, **kwargs):
        input_html = super().render(name, value, attrs=attrs, **kwargs)
        if value and hasattr(value, 'url'):
            img_url = value.url
        else:
            img_url = ""
        img_html = mark_safe(
            f'<br><img id="image-preview" src="{img_url}" style="display: none; max-width: 100px; max-height: 100px;"/>')
        return mark_safe(f'{input_html}{img_html}')

class UpdateGroupForm(forms.Form):
    title = forms.CharField(label='标题', max_length=255, required=False)
    about = forms.CharField(
        label='简介',
        max_length=510,
        required=False,
        widget=forms.Textarea(attrs={
            'rows': 4,
            'cols': 40,
        })
    )
    photo = forms.ImageField(widget=ImagePreviewWidget, label='头像', localize=True, required=False)
    admins = forms.ModelMultipleChoiceField(
        queryset=Account.objects.filter(status=1),
        widget=SelectMultiple(attrs={'size': '3'}),  # Adjust the size attribute as needed
        required=False,
        label='管理员'
    )
    ban_send_messages = forms.BooleanField(label='成员禁言', initial=False, required=False)
    username = forms.CharField(label='用户名', max_length=255, required=False)

    def photo_bytesio(self):
        photo = self.cleaned_data.get('photo', False)
        img_io = None
        if photo:
            img = Image.open(photo)
            max_width, max_height = 500, 500  # Set your desired max width and height

            if img.size[0] > max_width or img.size[1] > max_height:
                # Resize the image
                output_size = (max_width, max_height)
                img.thumbnail(output_size)

            # Save the resized image to a BytesIO object
            img_io = BytesIO()
            img.save(img_io, format='JPEG')
            img_io.seek(0)

        return img_io

    def clean_photo(self):
        photo = self.cleaned_data.get('photo', False)
        if photo:
            img = Image.open(photo)
            max_width, max_height = 500, 500  # Set your desired max width and height
            original_format = img.format  # Get the original format of the image

            if img.size[0] > max_width or img.size[1] > max_height:
                # Resize the image
                output_size = (max_width, max_height)
                img.thumbnail(output_size)

                # Save the resized image to a BytesIO object
                img_io = BytesIO()
                img.save(img_io, format=original_format)
                img_io.seek(0)

                # Create a new InMemoryUploadedFile
                photo = InMemoryUploadedFile(
                    img_io,
                    'ImageField',
                    f"{photo.name.split('.')[0]}.{original_format.lower()}",
                f'image/{original_format.lower()}',
                    sys.getsizeof(img_io),
                    None
                )

        return photo