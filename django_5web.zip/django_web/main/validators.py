import os
from django.core.exceptions import ValidationError

def validate_file_extension(value):
    ext = os.path.splitext(value.name)[1]  # 获取文件扩展名
    valid_extensions = ['.jpg', '.jpeg', '.mp4', '.gif']
    if ext.lower() not in valid_extensions:
        raise ValidationError('只支持上传如下格式: jpg, jpeg, mp4, gif.')
