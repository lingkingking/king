from django.core.management.base import BaseCommand
from django.contrib.auth.models import User, Group
from django.db import transaction

class Command(BaseCommand):
    help = 'Create a superuser and a staff user with specific permissions'

    def handle(self, *args, **kwargs):
        with transaction.atomic():
            # 创建超级用户
            if not User.objects.filter(username='admin').exists():
                User.objects.create_superuser('admin', 'admin@example.com', '159Aa159')
                self.stdout.write(self.style.SUCCESS('Successfully created superuser: admin'))
            else:
                self.stdout.write(self.style.WARNING('Superuser: admin already exists'))

            # 创建 staff 用户
            if not User.objects.filter(username='user01').exists():
                staff_user = User.objects.create_user('user01', 'user01@example.com', 'user159159')
                staff_user.is_staff = True
                staff_user.save()
                self.stdout.write(self.style.SUCCESS('Successfully created staff user: user01'))
            else:
                staff_user = User.objects.get(username='user01')
                self.stdout.write(self.style.WARNING('Staff user: user01 already exists'))

            # 获取或创建基础功能组
            basic_group, created = Group.objects.get_or_create(name='基础功能')

            # 将 user01 分配到基础功能组
            staff_user.groups.add(basic_group)
            staff_user.save()

            self.stdout.write(self.style.SUCCESS('Successfully assigned default permissions to user01'))
