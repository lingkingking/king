from django.core.management.base import BaseCommand
from django.contrib.auth.models import Group

class Command(BaseCommand):
    help = 'List all permissions for each group'

    def handle(self, *args, **kwargs):
        groups = Group.objects.all()
        for group in groups:
            permissions = group.permissions.all()
            permission_codenames = [f"{perm.content_type.app_label}.{perm.codename}" for perm in permissions]
            self.stdout.write(f"'{group.name}': [")
            for codename in permission_codenames:
                self.stdout.write(f"    '{codename}',")
            self.stdout.write("]")
