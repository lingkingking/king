from django.urls import path
from .views import download_log, download_usernames, index, api_import_accounts, collect_members_view, \
    api_tggroup_create, api_tggroup_import, group_list, add_group, delete_group, tag_list, add_tag, delete_tag, \
    tag2_list, add_tag2, delete_tag2, api_tggroup_create2, api_tggroup_import2, api_tggroup_create_new,api_check_user_import,api_get_users

urlpatterns = [
    # 其他 URL 模式
    path('download-log/', download_log, name='download_log'),
    # path('console/', web_console, name='web_console'),
    path('download_usernames/<uuid:task_id>/<int:operation>/', download_usernames, name='download_usernames'),
    path('import_accounts/', api_import_accounts, name='api_import_accounts'),
    path('', index, name='index'),
    path('collect_members', collect_members_view, name='collect_members'),
    path('create_tggroup/', api_tggroup_create, name='create_tggroup'),
    path('import_groups/', api_tggroup_import, name='import_groups'),
    path('create_tggroup2/', api_tggroup_create2, name='create_tggroup2'),
    # path('import_groups2/', api_tggroup_import2, name='import_groups2'),
    path('import_groups2/', api_check_user_import, name='import_groups2'),
    path('get_users/', api_get_users, name='get_users'),

    path('create_new_tggroup/', api_tggroup_create_new, name='create_new_tggroup'),

    path('group_list/', group_list, name='group_list'),
    path('add_group/', add_group, name='add_group'),
    path('delete_group/<int:group_id>/', delete_group, name='delete_group'),

    path('tag_list/', tag_list, name='tag_list'),
    path('add_tag/', add_tag, name='add_tag'),
    path('delete_tag/<int:group_id>/', delete_tag, name='delete_tag'),

    path('tag2_list/', tag2_list, name='tag2_list'),
    path('add_tag2/', add_tag2, name='add_tag2'),
    path('delete_tag2/<int:group_id>/', delete_tag2, name='delete_tag2'),
]