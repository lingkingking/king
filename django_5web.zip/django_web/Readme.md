# TG 群控
## 服务部署说明
1. 搭建宝塔
```shell
yum install -y wget && wget -O install.sh http://io.bt.sy/install/install_6.0.sh && sh install.sh
```
2. 修改宝塔端口
```shell
bt 8  8999
```
3. 宝塔安全菜单里放行端口：8888
4. 安装如下服务：
    * mysql 8.0
    * redis
    * python 3.8.12
5. 设置python 3.8 为默认 python，升级pip
```shell
sudo alternatives --install /usr/bin/python python /www/server/pyporject_evn/versions/3.8.12/bin/python3.8 1
python -m pip install --upgrade pip
python -m pip install celery --upgrade
# add python3.8 bin to PATH by adding following line in file .bash_profile
PATH=$PATH:/www/server/pyporject_evn/versions/3.8.12/bin
# use this celery on commandline
sudo ln -s /www/server/pyporject_evn/versions/3.8.12/bin/celery /usr/local/bin/celery
```
6. 安装 Telethon python 包，将 Telethon 项目的代码复制到 /www/wwwroot/Telethon
```shell
cd /www/wwwroot/
git clone http://43.153.14.251/laoxie/telegram_xx.git Telethon
cd Telethon
python -m pip install .
```
7. 新建数据库，用户名数据库：tg_control ，密码：YhsbnIsk@n8x
8. 初始化项目，tg_control 项目提交前，执行：git update-index --chmod=+x restart.sh 来确保 restart.sh 脚本在服务器上可执行
```shell
cd /www/wwwroot/
git clone http://43.153.14.251/laoxie/tg_control.git tgcontrol
cd tgcontrol
python manage.py makemigrations
python manage.py migrate
python manage.py init_settings
python manage.py create_users
python manage.py collectstatic
```
9. 运行项目
```shell
cd /www/wwwroot/tgcontrol
nohup python manage.py runserver 0.0.0.0:8888 &

#cp /www/wwwroot/tgcontrol/tgctrl.service /etc/systemd/system/
#sudo systemctl daemon-reload
#sudo systemctl start tgctrl
#sudo systemctl enable tgctrl
```
10. 运行celery
```shell
cd /www/wwwroot/tgcontrol
nohup celery -A tg_control worker --loglevel=info -f logs/tg_control.log &

#cp /www/wwwroot/tgcontrol/celery-tgctrl.service /etc/systemd/system/
#sudo systemctl daemon-reload
#sudo systemctl start celery-tgctrl
#sudo systemctl enable celery-tgctrl
```
11. 更新重启以上服务
```shell
# stop existing process
fuser -k 8888/tcp
ps -aux | grep 'celery -A tg_control' | grep -v grep | awk '{print $2}' | xargs sudo kill -9
# start new one
python manage.py makemigrations
python manage.py migrate
python manage.py collectstatic
nohup python manage.py runserver 0.0.0.0:8888 &
nohup celery -A tg_control worker --loglevel=info -f logs/tg_control.log &

#sudo systemctl restart tgctrl
#sudo systemctl restart celery-tgctrl
#sudo systemctl status tgctrl
#sudo systemctl status celery-tgctrl
```