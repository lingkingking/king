from fastapi import FastAPI, Request, HTTPException
from starlette.responses import FileResponse

from model import CreatPhone, VerificationCode
from utils import CreateTgAccountThread, AccountStatus
import uvicorn as uvicorn

phone_list = {}
global number_download
number_download = 0
app = FastAPI()


@app.post("/creat_phone")
async def creat_phone(item: CreatPhone):
    try:
        phone = item.phone
        region = item.region
        password = item.password
        ipproxy_name = item.ipproxy_name
        if phone_list.get(phone):
            return {"status": 400, "message": "手机号已存在"}
        account_task = CreateTgAccountThread(phone, password, region, ipproxy_name)
        account_task.start()
        phone_list[phone] = account_task #返回类对象
        return {"status": 200, "message": "成功"}
    except Exception as e :
        import traceback
        traceback.print_exc()
        return {"status": 400, "message": str(e)}


@app.post("/del_phone")
async def del_phone(item: CreatPhone):
    phone = item.phone
    print(phone_list)
    if phone_list.get(phone):
        phone_list[phone].set_kill_flag() #发送验证码
    if phone_list.get(phone):
        await phone_list[phone].close()
        del phone_list[phone]
    print(phone_list)
    return {"status": 200, "message": "成功"}


@app.get("/get_phone_status")
async def get_phone_status():
    return [{'phone': k, 'status': v.status} for k, v in phone_list.items()]


@app.get("/get_phone_file")
async def get_phone_file(phone: str):
    global number_download
    file_path = rf"./phone/{phone}.zip"
    try:
        # 如果文件不存在，FileResponse会抛出404错误
        number_download += 1
        return FileResponse(file_path ,filename=f"{phone}.zip")
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"File not found: {e}")

@app.get("/get_phone_session_file")
async def get_phone_file(phone: str):
    global number_download
    file_path = rf"./phone/{phone}/{phone}.session"
    try:
        # 如果文件不存在，FileResponse会抛出404错误
        number_download += 1
        return FileResponse(file_path ,filename=f"{phone}.session")
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"File not found: {e}")

@app.get("/get_number")
async def get_phone_file():
    global number_download
    return number_download

@app.post("/send_code_request")
async def send_code_request(request: Request):
    data = await request.json()
    phone = data.get('phone')
    if phone_list.get(phone):
        if phone_list[phone].status != AccountStatus.WAIT_VERIFICATION_CODE:
            return {"status": 400,
                    "message": f"状态错误，必须是{AccountStatus.WAIT_VERIFICATION_CODE} 才可以继续发送验证码",
                    "data": phone_list[phone].status}
        await phone_list[phone].send_code_request()
    return {"status": 200, "message": "成功"}


@app.post("/set_phone_code")
async def set_phone_code(item: VerificationCode):
    phone = item.phone
    if phone_list.get(phone):
        phone_list[phone].set_code(item.code) #发送验证码
    return {"status": 200, "message": "成功"}


if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=8888, log_level="info")
