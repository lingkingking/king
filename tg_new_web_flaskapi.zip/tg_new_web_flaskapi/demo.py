import time
from time import sleep

import requests
# IP = "127.0.0.1"
IP = "49.51.189.167"
def add_phone(phone):
    url = f'http://{IP}:18889/creat_phone'

    # for i in range(10):
    data = {
        'phone': phone,
        'region': 'us',
        'password': 'dem99998',
        #5Hj9Ks2Cv9He-res-US-sid-20383842|3Gy5Ne4Ba1Ru4Jx6Fj|z1.ipmart.io|9595
        'ipproxy_name': '5Hj9Ks2Cv9He-res-国家大写-sid-随机数字|Xv2u76ZeYPia86V123a|z1.ipmart.io|9595'
    }
    res = requests.post(url, json=data)
    print(res.text)
    sleep(0.1)


def set_phone_code(phone, code):
    url = f'http://{IP}:18889/set_phone_code'

    data = {
        'phone': phone,
        'code': code
    }
    res = requests.post(url, json=data)
    print(res.json())
    sleep(0.1)


def del_phone(phone):
    url = f'http://{IP}:8888/del_phone'

    data = {
        'phone': phone,
        'region': 'gb',
        'password': 'dem99998',
        'ipproxy_name': '5Hj9Ks2Cv9He-res-US-sid-20383242|3Gy5Ne4Ba1Ru4Jx6Fj|z1.ipmart.io|9595'
    }
    res = requests.post(url, json=data)
    print(res.json())
    sleep(0.1)


if __name__ == '__main__':
    # add_phone('15859903015')  ## 创建手机号
    # add_phone('12709473859')  ## 创建手机号
    # set_phone_code("17316006647","38474")
    #('447926783829')  ## 创建手机号
    #sleep(5)
    # res = requests.get(f'http://{IP}:18889/get_phone_status')
    # print(res.json())

    res = requests.get('http://49.51.189.167:18889/get_phone_file',params={"phone":"12709473859"})
    print(res.text)

   # del_phone("17125123721")
   #  time.sleep(2)
    # # set_phone_code('447926783824', '47144')  ## 发送验证码
    # # set_phone_code('447444619369', '46928')  ## 发送验证码
   # del_phone('447926783829')  ## 删除手机号

    # # sleep(2)
    # # res = requests.get('http://127.0.0.1:8888/get_phone_status')
    # # print(res.json())
