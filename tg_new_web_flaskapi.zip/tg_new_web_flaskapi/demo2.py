from pprint import pprint

text1 = ""
text2 = ""

with open("./1.txt") as f :
    text1 = f.read()
    f.close()


with open("./2.txt") as f :
    text2 = f.read()
    f.close()

print(text1)
print("=================================")
print(text2)
json_new = {}
split_text1 = text2.split(";")
for i in split_text1:
    key_value = i.split("=")
    key = key_value[0]
    value = key_value[1]
    json_new[key] = value

pprint(json_new)
