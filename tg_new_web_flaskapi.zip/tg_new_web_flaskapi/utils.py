import asyncio
import logging
import os
import random
import re
import secrets
import threading
import time
from asyncio import sleep
from enum import Enum
from time import sleep as time_sleep
import zipfile
import requests
import socks
from opentele.tl import TelegramClient
from opentele.api import UseCurrentSession


_path = os.path.dirname(__file__)
phone_path = os.path.join(_path, 'phone')
# api_id = 10840
# api_hash = "33c45224029d59cb3ad0c16134215aeb"
api_id = 2040
api_hash = "b18441a1ff607e10a989891a5462e627"


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


def get_proxy(region, ipproxy_name):
    #ipproxy_name = 'user-mier20242024-region-国家小写-sessid-随机字符串-sesstime-30-keep-true|mier20242024|79dc8131fb8aec4b.na.roxlabs.vip|4600'
    #print(ipproxy_name)
    count = 0
    while 1:
        try:
            session = secrets.token_hex(8)
            ipproxy_name = ipproxy_name.replace("随机字符串", session) \
                .replace("随机数字", str(random.randint(1, 99999999))) \
                .replace("国家小写", region.lower()) \
                .replace("国家大写", region.upper())
            user, password, addr, port = ipproxy_name.split("|")
            proxy = {
                'http': f'socks5://{user}:{password}@{addr}:{port}',
                'https': f'socks5://{user}:{password}@{addr}:{port}'}
            #print(proxy)
            rep = requests.get("https://ipinfo.io/json", proxies=proxy, timeout=10)
            if rep.status_code == 200 and rep.json().get("ip"):
                print(rep.json().get("ip"))
                print(rep.json().get("country"))
                count = 0
                # is_ok = False
                # for ii in range(0, 3):
                #     try:
                #         rep = requests.post(url=f"https://scamalytics.com/ip/{rep.json().get('ip')}", proxies=proxy)
                #         if rep.status_code == 200:
                #             ip_check_string = rep.text
                #             pattern = r"Fraud Score:(.*?)</div>"
                #             match = re.search(pattern, ip_check_string)
                #             if match:
                #                 middle_values = match.group(1)
                #                 if int(middle_values) > 30:
                #                     print("风险度", int(middle_values))
                #                     is_ok = False
                #                 else:
                #                     is_ok = True
                #                     print("风险度", int(middle_values))
                #                 break
                #     except:
                #         pass
                #     finally:
                #         time.sleep(1)
                # if is_ok:
                return {'proxy_type': socks.SOCKS5, 'addr': addr, 'port': int(port), 'username': user, 'password': password,
                        'rdns': True}
            else:
                count += 1
                print(f"代理不可用 status_code: {rep.status_code}")
                if count > 3:
                    print("超过3次")
                    random_int = random.randint(1,9999999)
                    ipproxy_name = f'5Hj9Ks2Cv9He-res-国家大写-sid-{random_int}|Xv2u76ZeYPia86V123a|z1.ipmart.io|9595'
                    count = 0
            time.sleep(1)
        except Exception as e:
            count += 1
            print(f"获取代理异常{e}")
            if count > 3:
                print("超过3次")
                random_int = random.randint(1, 9999999)
                ipproxy_name = f'5Hj9Ks2Cv9He-res-国家大写-sid-{random_int}|Xv2u76ZeYPia86V123a|z1.ipmart.io|9595'
                count = 0
            time.sleep(3)


# 枚举
class AccountStatus(Enum):
    NOT_STARTED = "未开始"
    START_ACCOUNT = "开始创建账号"
    WAIT_VERIFICATION_CODE = "等待验证码"
    VERIFICATION_CODE = "验证码已接收"
    VERIFICATION_CODE_ERROR = "验证码错误"
    ACCOUNT_CREATED_SUCCESS = "创建账号成功"
    TDATA_CREATED_SUCCESS = "生成 Tdata 成功"
    Error = "生成失败"


class CreateTgAccountThread(threading.Thread):

    def __init__(self, phone, password, region, ipproxy_name):
        super().__init__()
        self.phone = phone
        self.password = password
        self.code = False
        self.kill_flag = False
        self.proxy = {}
        self.status = AccountStatus.NOT_STARTED
        self.phone_path = os.path.join(phone_path, phone)
        if os.path.exists(self.phone_path):
            try:
                import shutil
                shutil.rmtree(self.phone_path)
            except:
                pass
        try:
            os.makedirs(self.phone_path)
        except:
            pass

        self.sessions_final_path = os.path.join(self.phone_path, phone + '.' + 'session')
        self.tdata_final_path = os.path.join(self.phone_path, 'tdata')
        self.ipproxy_name = ipproxy_name
        self.region = region
        self.create_client = None
        self.tdata_client = None
        self.loop = asyncio.new_event_loop()
        self.is_verify = False

    def set_code(self, code):
        self.code = code
    def set_kill_flag(self):
        self.kill_flag = True
    def verifyCode(self):
        if self.is_verify:
            print(f"{self.phone} 验证码错误从新验证验证码")
            self.status = AccountStatus.VERIFICATION_CODE_ERROR
        else:
            print(f"{self.phone} 需要接收验证码")
            self.status = AccountStatus.WAIT_VERIFICATION_CODE
        while not self.code :
            time_sleep(0.1)
            if self.kill_flag: #主动结束接受验证码
                print(f"{self.phone} 主动结束接受验证码")
                self.code = 1
            pass
        if self.code == 1:
            return 0
        else:
            print(f"{self.phone} 接收验证码成功")
            self.status = AccountStatus.VERIFICATION_CODE
            code = self.code
            self.code = False
            self.is_verify = True
            return code

    async def close(self):
        if self.create_client:
            await self.create_client.disconnect()
        # if self.tdata_client:
        #     self.tdata_client.disconnect()
        self.loop.call_soon_threadsafe(self.loop.stop)

    def run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self.create_account())
        self.loop.run_forever()

    async def send_code_request(self):
        if self.create_client:
            await self.create_client.send_code_request(self.phone, force_sms=False)

    async def create_account(self):
        #self.verifyCode()
        try:
            self.proxy = get_proxy(self.region, self.ipproxy_name)
            self.status = AccountStatus.START_ACCOUNT

            self.create_client = TelegramClient(self.sessions_final_path, None, api_id, api_hash,
                                                proxy=self.proxy, timeout=30)
            await sleep(8)
            await self.create_client._start(phone=self.phone, password=self.password, code_callback=self.verifyCode,
                                            bot_token=None,
                                            force_sms=False,
                                            first_name='New User',
                                            last_name='',
                                            max_attempts=10)
            await self.create_client.connect()
            await sleep(2)
            self.create_client.disconnect()
            self.status = AccountStatus.ACCOUNT_CREATED_SUCCESS
            await sleep(2)
            self.create_client = None
            await self.creatTdata()
            self.status = AccountStatus.TDATA_CREATED_SUCCESS

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.create_client.disconnect()
            self.create_client = None
            print(f"创建账号失败 {self.phone}{e}")
            self.status = AccountStatus.Error



    async def creatTdata(self):
        self.tdata_client = TelegramClient(self.sessions_final_path, api_id=api_id, api_hash=api_hash,
                                           proxy=self.proxy)
        tdesk = await self.tdata_client.ToTDesktop(flag=UseCurrentSession, password=self.password)
        print('save', self.tdata_final_path)
        tdesk.SaveTData(self.tdata_final_path)
        self.status = AccountStatus.TDATA_CREATED_SUCCESS
        self.tdata_client.disconnect()
        time.sleep(1)
        #删除 85560997978.session-journal
        #rm_path = rf"./phone/{self.phone}/{self.phone}.session-journal"
        #保存文件
        try:
            if os.path.exists(rf"./phone/{self.phone}"):
                with zipfile.ZipFile(rf"./phone/{self.phone}.zip", 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for root, _, files in os.walk(rf"./phone/{self.phone}"):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arc_name = os.path.relpath(file_path, os.path.dirname(rf"./phone/{self.phone}"))
                            zipf.write(file_path, arcname=arc_name)
                    zipf.close()
                os.remove(rf"./phone/{self.phone}")
        except Exception:
            pass
        finally:
            zipf.close()
        self.tdata_client = None


if __name__ == '__main__':
    get_proxy("us","5Hj9Ks2Cv9He-res-US-sid-rt3453|3Gy5Ne4Ba1Ru4Jx6Fj|z1.ipmart.io|9595")