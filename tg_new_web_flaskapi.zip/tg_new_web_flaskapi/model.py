from pydantic import BaseModel


class CreatPhone(BaseModel):
    phone: str
    region: str
    password: str
    ipproxy_name: str


class VerificationCode(BaseModel):
    phone: str
    code: str
